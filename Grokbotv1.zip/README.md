# Grok Bot desk

Two things live here:

- **`desk/`** — the real desk. Python, runs on your Windows laptop, talks to FOMO through
  your own Chrome session, and serves its own interface on real data.
- **`worker.js` + `wrangler.jsonc`** — the preview site only. Fixture data, PAPER badge,
  LIVE refused. It is not connected to FOMO and never trades. Safe to ignore or delete.

Your FOMO lessons live in `desk/fomo_web.md`. The lane refuses to click anything if that
file is missing or a label is not in it.

## First run (Windows, PowerShell)

    cd <this folder>
    .\desk\Desk.ps1 install

Install creates a Python environment, installs the packages, installs the Chromium the
browser lane drives, generates a desk token, and asks for two optional secrets:

- **Telegram bot token** — press Enter to skip and use only the app.
- **VAPID private key** — press Enter to skip web push.

Secrets are written to `%USERPROFILE%\.grokbot\desk.env` and locked to your Windows
account. They are never put in this folder and never printed in logs.

It ends by printing your link once, in yellow:

    http://localhost:8787/#t=<your token>

Keep that private — it is the key to the app.

## Everyday commands

    .\desk\Desk.ps1 start        start the desk
    .\desk\Desk.ps1 status       is it running, what mode, bot heartbeats
    .\desk\Desk.ps1 stop         stop it
    .\desk\Desk.ps1 restart      stop then start
    .\desk\Desk.ps1 logs         recent log lines

Install registers a Task Scheduler entry so the desk starts at logon and restarts if it
crashes. One process only: a second start is refused.

## The link

On the laptop: `http://localhost:8787/#t=<token>`

To use your phone on the same Wi-Fi:

    .\desk\Desk.ps1 start -Lan

then open `http://<laptop-ip>:8787/#t=<token>` on the phone. The token is still required —
being on the network is not enough.

To print the link again:

    $t = (Select-String -Path "$env:USERPROFILE\.grokbot\desk.env" -Pattern '^APP_TOKEN=').Line -replace '^APP_TOKEN=',''
    "http://localhost:8787/#t=$t"

## What is real and what is not

- The desk shows **real prices, real positions and real bot decisions** in PAPER mode.
  PAPER means it stops before pressing the real buy/sell button.
- **LIVE is off.** It needs `LIVE_GATE_OK=1` plus at least one full PAPER night, and the
  app asks you to type LIVE to confirm.
- The desk reads FOMO through your Chrome session. **Chrome must be logged into
  fomo.family** or there is nothing to read and the app shows the offline bar.
- `worker.js` is the hosted preview only — fixture numbers, no FOMO connection.

## Checks you can run yourself

    cd desk
    .\.venv\Scripts\python -m pytest -q          # 102 tests
    .\.venv\Scripts\python -m desk.main --selftest   # offline PAPER replay, no network

## Not yet proven

The Windows kit has **not been run on a real Windows machine** at the time of writing.
Treat the first install and start as a test. The browser lane also needs your logged-in
Chrome before it can do anything.

## Layout

    desk/
      Desk.ps1              install / start / stop / status / logs
      main.py               the desk itself, serves the app on :8787
      api.py                JSON API, every call needs APP_TOKEN
      browser.py            the only module that touches FOMO web
      fomo_web.md           your lessons, plus the labels the lane reads
      bots/                 Scanner Analyst Brain Executor Risk
      web/                  the iPhone interface
      tests/                102 tests
      requirements.txt
    docs/SPEC.md            the prompt of record
