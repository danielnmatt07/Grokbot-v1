# =============================================================================
# Grok Bot desk · Windows 11 host kit
#
#   Desk.ps1 install     one-time: Python, venv, packages, secrets prompt, autostart
#   Desk.ps1 start       start the desk in the background (idempotent)
#   Desk.ps1 stop        stop it cleanly
#   Desk.ps1 restart     stop + start
#   Desk.ps1 status      is it running, on what port, is the API answering
#   Desk.ps1 logs        tail the log
#   Desk.ps1 verify      run the acceptance tests on THIS machine
#   Desk.ps1 uninstall   remove the scheduled task and the venv (keeps data/)
#
# One process, one lock file, one scheduled task. Closing the browser, closing VS Code
# or clicking anything in the UI never touches the process: it is a detached child of
# Task Scheduler, not a child of your terminal.
# =============================================================================

[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [ValidateSet('install', 'start', 'stop', 'restart', 'status', 'logs', 'verify', 'uninstall', 'help')]
    [string]$Command = 'help',
    [int]$Port = 8787,
    [switch]$Lan
)

$ErrorActionPreference = 'Stop'
$DeskRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot = Split-Path -Parent $DeskRoot
$DataDir = Join-Path $RepoRoot 'data'
$LogDir = Join-Path $RepoRoot 'logs'
$VenvDir = Join-Path $RepoRoot '.venv'
$VenvPy = Join-Path $VenvDir 'Scripts\python.exe'
$PidFile = Join-Path $DataDir 'desk.pid'
$LockFile = Join-Path $DataDir 'desk.lock'
$TaskName = 'GrokBotDesk'
$SecretDir = Join-Path $env:USERPROFILE '.grokbot'
$SecretFile = Join-Path $SecretDir 'desk.env'

function Write-Step($m) { Write-Host "  $m" }
function Write-Head($m) { Write-Host ""; Write-Host $m -ForegroundColor Cyan }

function Ensure-Dirs {
    foreach ($d in @($DataDir, $LogDir)) {
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    }
}

# ---------------------------------------------------------------- python + deps
function Find-Python {
    foreach ($cmd in @('python', 'py')) {
        $exe = Get-Command $cmd -ErrorAction SilentlyContinue
        if ($exe) {
            try {
                $v = & $exe.Source -c "import sys;print('%d.%d'%sys.version_info[:2])" 2>$null
                if ($v -and [version]$v -ge [version]'3.11') { return $exe.Source }
            } catch { }
        }
    }
    return $null
}

function Install-Deps {
    if (-not (Test-Path $VenvPy)) {
        $py = Find-Python
        if (-not $py) {
            throw "Python 3.11+ was not found. Install it from python.org (tick 'Add python.exe to PATH'), then run: Desk.ps1 install"
        }
        Write-Step "creating a virtual environment in .venv"
        & $py -m venv $VenvDir
    }
    Write-Step "installing packages (this is the slow part, a few minutes)"
    & $VenvPy -m pip install --quiet --disable-pip-version-check --upgrade pip
    & $VenvPy -m pip install --quiet --disable-pip-version-check -r (Join-Path $DeskRoot 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw "package install failed. Run: .venv\Scripts\python -m pip install -r desk\requirements.txt" }
    Write-Step "installing the Chromium that the browser lane drives"
    & $VenvPy -m playwright install chromium 2>$null
}

function Test-Imports {
    if (-not (Test-Path $VenvPy)) { return $false }
    & $VenvPy -c "import fastapi, uvicorn, httpx, websockets" 2>$null
    return ($LASTEXITCODE -eq 0)
}

# ---------------------------------------------------------------- secrets
# Values live in %USERPROFILE%\.grokbot\desk.env, outside the repo, and are loaded into the
# process environment at start. They are never written to data/, logs/, web/ or the app.
function Initialize-Secrets {
    if (-not (Test-Path $SecretDir)) {
        New-Item -ItemType Directory -Path $SecretDir -Force | Out-Null
        $acl = New-Object System.Security.AccessControl.DirectorySecurity
        $acl.SetAccessRuleProtection($true, $false)
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,
            'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
        $acl.AddAccessRule($rule)
        Set-Acl -Path $SecretDir -AclObject $acl
    }
    if (Test-Path $SecretFile) { Write-Step "secrets already stored in $SecretFile"; return }

    Write-Head "Secrets (kept in $SecretFile, never in the repo or logs)"
    $appToken = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 48 | ForEach-Object { [char]$_ })
    Write-Step "generated a desk token for the phone"
    $tg = Read-Host "Telegram bot token (paste, or press Enter to skip and use only the app)"
    $vapid = Read-Host "VAPID private key (press Enter to skip web push)"
    $lines = @(
        "APP_TOKEN=$appToken",
        "TELEGRAM_BOT_TOKEN=$tg",
        "VAPID_PRIVATE_KEY=$vapid",
        "DESK_PORT=$Port"
    )
    Set-Content -Path $SecretFile -Value $lines -Encoding utf8
    Write-Host ""
    Write-Host "  Your phone link (keep it private, it contains the desk token):" -ForegroundColor Yellow
    Write-Host "    http://localhost:$Port/#t=$appToken" -ForegroundColor Yellow
}

function Import-Secrets {
    if (-not (Test-Path $SecretFile)) { return }
    Get-Content $SecretFile | ForEach-Object {
        if ($_ -match '^\s*([A-Z_]+)\s*=\s*(.*)$') {
            Set-Item -Path ("Env:" + $matches[1]) -Value $matches[2].Trim()
        }
    }
}

# ---------------------------------------------------------------- process control
function Get-DeskProcess {
    if (-not (Test-Path $PidFile)) { return $null }
    $raw = (Get-Content $PidFile -ErrorAction SilentlyContinue | Select-Object -First 1)
    if (-not $raw) { return $null }
    $procId = 0
    if (-not [int]::TryParse($raw.Trim(), [ref]$procId)) { return $null }
    $p = Get-Process -Id $procId -ErrorAction SilentlyContinue
    if (-not $p) { return $null }
    # guard against PID reuse: the command line must still be our desk
    try {
        $cmdline = (Get-CimInstance Win32_Process -Filter "ProcessId=$procId").CommandLine
        if ($cmdline -notmatch 'desk') { return $null }
    } catch { }
    return $p
}

function Test-Api {
    param([int]$p = $Port)
    try {
        $r = Invoke-WebRequest -Uri "http://127.0.0.1:$p/api/health" -TimeoutSec 4 -UseBasicParsing
        return ($r.StatusCode -eq 200)
    } catch { return $false }
}

function Start-Desk {
    Ensure-Dirs
    $existing = Get-DeskProcess
    if ($existing) { Write-Step "already running (pid $($existing.Id))"; Show-Status; return }

    # duplicate prevention: an exclusive lock file, released by the OS if the process dies
    if (Test-Path $LockFile) {
        try {
            $fs = [System.IO.File]::Open($LockFile, 'Open', 'ReadWrite', 'None')
            $fs.Close(); $fs.Dispose()
        } catch {
            Write-Host "  Another desk holds the lock ($LockFile). Refusing to start a second one." -ForegroundColor Red
            return
        }
    }

    Import-Secrets
    if (-not $env:APP_TOKEN) { throw "APP_TOKEN is missing. Run: Desk.ps1 install" }
    $env:DESK_PORT = "$Port"
    $args = @('-m', 'desk.main', '--serve')
    if ($Lan) { $args += '--lan' }

    $log = Join-Path $LogDir 'process.log'
    $err = Join-Path $LogDir 'process.err.log'
    # Start-Process detaches: the child survives closing this terminal, VS Code and the browser
    $p = Start-Process -FilePath $VenvPy -ArgumentList $args -WorkingDirectory $RepoRoot `
        -RedirectStandardOutput $log -RedirectStandardError $err `
        -WindowStyle Hidden -PassThru
    Set-Content -Path $PidFile -Value $p.Id -Encoding ascii
    Write-Step "started pid $($p.Id), waiting for the API"

    for ($i = 0; $i -lt 40; $i++) {
        Start-Sleep -Milliseconds 500
        if ($p.HasExited) { break }
        if (Test-Api) { Write-Step "API is up on http://127.0.0.1:$Port"; Show-Status; return }
    }
    Write-Host "  The desk did not answer. Last lines of $err :" -ForegroundColor Red
    if (Test-Path $err) { Get-Content $err -Tail 25 | ForEach-Object { Write-Host "    $_" } }
}

function Stop-Desk {
    $p = Get-DeskProcess
    if (-not $p) {
        Write-Step "not running"
        Remove-Item $PidFile -ErrorAction SilentlyContinue
        return
    }
    Write-Step "stopping pid $($p.Id)"
    try { $p.CloseMainWindow() | Out-Null } catch { }
    if (-not $p.WaitForExit(6000)) {
        Write-Step "no clean exit, terminating"
        Stop-Process -Id $p.Id -Force
    }
    Remove-Item $PidFile -ErrorAction SilentlyContinue
    Write-Step "stopped"
}

function Restart-Desk { Stop-Desk; Start-Sleep -Milliseconds 800; Start-Desk }

function Show-Status {
    $p = Get-DeskProcess
    $api = Test-Api
    Write-Head "Grok Bot desk"
    if ($p) {
        Write-Host ("  process   running, pid {0}, started {1}" -f $p.Id, $p.StartTime)
    } else {
        Write-Host "  process   not running" -ForegroundColor Yellow
    }
    Write-Host ("  api       {0}" -f ($(if ($api) { "ok  http://127.0.0.1:$Port" } else { "not answering" })))
    Write-Host ("  task      {0}" -f $(if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) { "registered (starts at logon, restarts on crash)" } else { "not registered" }))
    if ($api) {
        $h = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/health" -TimeoutSec 4
        Write-Host ("  mode      {0}" -f $h.mode)
        if ($h.beats) {
            $nowUtc = [datetime]::UtcNow
            foreach ($k in $h.beats.PSObject.Properties.Name) {
                $age = ($nowUtc - ([datetime]$h.beats.$k)).TotalSeconds
                Write-Host ("  beat      {0,-9} {1,5:N0}s ago" -f $k, $age)
            }
        }
    }
}

# ---------------------------------------------------------------- scheduled task
function Register-Autostart {
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $args = "-NoProfile -ExecutionPolicy Bypass -File `"$DeskRoot\Desk.ps1`" start -Port $Port"
    $action = New-ScheduledTaskAction -Execute $ps -Argument $args -WorkingDirectory $RepoRoot
    $triggerLogon = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
    $settings = New-ScheduledTaskSettingsSet `
        -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
        -StartWhenAvailable -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) `
        -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
    $principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" `
        -LogonType Interactive -RunLevel Limited
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $triggerLogon `
        -Settings $settings -Principal $principal `
        -Description "Grok Bot trading desk: one asyncio process, restarted on crash" | Out-Null
    Write-Step "registered the '$TaskName' task: starts at logon, restarts within a minute if it dies"
    Write-Step "it uses IgnoreNew, so a second copy is never launched"
}

function Invoke-Verify {
    Import-Secrets
    Write-Head "Acceptance tests (STEP 15, machine-local parts)"
    Push-Location $DeskRoot
    try {
        & $VenvPy -m pytest -q
        $code = $LASTEXITCODE
    } finally { Pop-Location }
    Write-Head "Offline PAPER replay"
    Push-Location $RepoRoot
    try { & $VenvPy -m desk.replay } finally { Pop-Location }
    if ($code -eq 0) { Write-Host "" ; Write-Host "  local checks passed" -ForegroundColor Green }
    else { Write-Host "" ; Write-Host "  some locally runnable checks failed (see above)" -ForegroundColor Red }
    Write-Host "  Not covered here: real Chrome clicks, FOMO login, a real swap, a LIVE order." -ForegroundColor Yellow
    Write-Host "  Those need the desk Chrome from STEP 2 and are run by hand." -ForegroundColor Yellow
}

# ---------------------------------------------------------------- entry point
switch ($Command) {
    'install' {
        Write-Head "Installing the Grok Bot desk on this machine"
        Ensure-Dirs
        Install-Deps
        Initialize-Secrets
        Register-Autostart
        Write-Head "Installed"
        Write-Step "start it now:      .\desk\Desk.ps1 start"
        Write-Step "or just reboot / log in: the scheduled task starts it"
        Write-Step "open the app:      .\desk\Desk.ps1 status   (prints the link your phone needs)"
    }
    'start' { Start-Desk }
    'stop' { Stop-Desk }
    'restart' { Restart-Desk }
    'status' { Show-Status }
    'logs' {
        $log = Join-Path $LogDir 'desk.log'
        if (Test-Path $log) { Get-Content $log -Tail 60 -Wait } else { Write-Host "no log yet at $log" }
    }
    'verify' { Invoke-Verify }
    'uninstall' {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
        Stop-Desk
        if (Test-Path $VenvDir) { Remove-Item $VenvDir -Recurse -Force }
        Write-Step "removed the task and the venv. data/ and logs/ are kept."
    }
    default {
        Write-Host @"
Grok Bot desk on Windows 11

  .\desk\Desk.ps1 install    Python + packages + secrets + autostart (run once)
  .\desk\Desk.ps1 start      start in the background
  .\desk\Desk.ps1 stop       stop it
  .\desk\Desk.ps1 restart    stop then start
  .\desk\Desk.ps1 status     process, API and bot heartbeats
  .\desk\Desk.ps1 logs       follow the log
  .\desk\Desk.ps1 verify     run the local acceptance tests
  .\desk\Desk.ps1 uninstall  remove the task and the venv

  -Port 8787    change the local port
  -Lan          also listen on your network so the phone can reach it over Wi-Fi
"@
    }
}
