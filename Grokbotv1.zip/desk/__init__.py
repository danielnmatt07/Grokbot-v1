"""Grok Bot desk — one always-on asyncio process for the five bots, the lane and the app."""

__version__ = "1.0.0"
