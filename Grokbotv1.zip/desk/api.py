"""api.py — the app's JSON API (STEP 8). Every call needs APP_TOKEN, else 401.

Plan B writes the same shapes as files under a secret /d/{DATA_PATH}/ path.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from fastapi.responses import JSONResponse, Response

from desk import config as cfgmod
from desk import deskstate, links

router = APIRouter()


def auth(authorization: str = Header(default="")) -> None:
    token = os.environ.get("APP_TOKEN", "")
    if not token:
        raise HTTPException(503, "APP_TOKEN is not set on the desk")
    if authorization != f"Bearer {token}":
        raise HTTPException(401, "unauthorized")


def _ctx(request: Request):
    return request.app.state.desk


@router.get("/state")
async def state(request: Request, _=Depends(auth)):
    d = _ctx(request)
    return JSONResponse(d.state_payload())


@router.get("/chart")
async def chart(request: Request, range: str = "LIVE", _=Depends(auth)):
    d = _ctx(request)
    return JSONResponse(d.chart_payload(range.upper()))


@router.get("/activity")
async def activity(request: Request, before: str | None = None, _=Depends(auth)):
    d = _ctx(request)
    rows = d.activity_payload(before)
    return JSONResponse({"rows": rows})


@router.get("/orders")
async def orders(request: Request, before: str | None = None, _=Depends(auth)):
    d = _ctx(request)
    return JSONResponse({"rows": d.orders_payload(before)})


@router.get("/coin/{mint}")
async def coin(mint: str, request: Request, _=Depends(auth)):
    d = _ctx(request)
    payload = d.coin_payload(mint)
    if payload is None:
        raise HTTPException(404, "no such coin tonight")
    return JSONResponse(payload)


@router.get("/audit/{mint}")
async def audit(mint: str, request: Request, _=Depends(auth)):
    d = _ctx(request)
    payload = d.audit_payload(mint)
    if payload is None:
        raise HTTPException(404, "no audit for this coin")
    return JSONResponse(payload)


@router.get("/bots/{name}/decisions")
async def decisions(name: str, request: Request, _=Depends(auth)):
    d = _ctx(request)
    return JSONResponse({"rows": d.decisions_payload(name)})


@router.post("/bots/{name}/pause")
async def pause(name: str, request: Request, _=Depends(auth)):
    d = _ctx(request)
    err = d.pause_bot(name, True)
    if err:
        raise HTTPException(409, err)
    return {"ok": True, "paused": True}


@router.post("/bots/{name}/resume")
async def resume(name: str, request: Request, _=Depends(auth)):
    d = _ctx(request)
    err = d.pause_bot(name, False)
    if err:
        raise HTTPException(409, err)
    return {"ok": True, "paused": False}


@router.get("/account")
async def account(request: Request, _=Depends(auth)):
    d = _ctx(request)
    return JSONResponse(d.account_payload())


@router.post("/settings")
async def settings(request: Request, _=Depends(auth)):
    d = _ctx(request)
    body = await request.json()
    key, value = body.get("key"), body.get("value")
    if not key:
        raise HTTPException(400, "key required")
    try:
        res = d.cfg.set(key, value, who="owner")
    except ValueError as e:
        raise HTTPException(422, str(e))
    except KeyError:
        raise HTTPException(404, "unknown setting")
    return JSONResponse(res)


@router.post("/mode")
async def mode(request: Request, _=Depends(auth)):
    d = _ctx(request)
    body = await request.json()
    target = str(body.get("mode", "")).upper()
    if target not in ("PAPER", "LIVE"):
        raise HTTPException(422, "mode must be PAPER or LIVE")
    if target == "LIVE":
        if body.get("confirm") != "LIVE":
            raise HTTPException(422, "type LIVE to confirm")
        ok, why = d.live_allowed()
        if not ok:
            raise HTTPException(409, why)
    d.cfg.set("mode", target, who="owner")
    return {"mode": target}


@router.post("/sell/{mint}")
async def sell(mint: str, request: Request, _=Depends(auth)):
    d = _ctx(request)
    body = await request.json()
    if body.get("confirm") is not True:
        raise HTTPException(422, "confirm required")
    pct = int(body.get("pct", 100))
    if pct not in (25, 50, 100):
        raise HTTPException(422, "pct must be 25, 50 or 100")
    err = d.queue_sell(mint, pct)
    if err:
        raise HTTPException(409, err)
    return {"ok": True, "queued": {"mint": mint, "pct": pct}}


@router.get("/screen.jpg")
async def screen(request: Request, _=Depends(auth)):
    d = _ctx(request)
    path = d.screen_path()
    if not os.path.exists(path):
        raise HTTPException(404, "no frame yet")
    with open(path, "rb") as f:
        data = f.read()
    return Response(data, media_type="image/jpeg",
                    headers={"Cache-Control": "no-store, max-age=0"})


@router.post("/push")
async def push(request: Request, _=Depends(auth)):
    d = _ctx(request)
    body = await request.json()
    if body.get("test"):
        ok = await d.notify.test_push()
        return {"sent": bool(ok)}
    endpoint = body.get("endpoint")
    if not endpoint:
        raise HTTPException(422, "endpoint required")
    d.db.exec(
        "INSERT INTO push_subs (endpoint, p256dh, auth) VALUES (?,?,?) "
        "ON CONFLICT(endpoint) DO UPDATE SET p256dh=excluded.p256dh, auth=excluded.auth",
        (endpoint, body.get("keys", {}).get("p256dh"), body.get("keys", {}).get("auth")),
    )
    return {"ok": True}


@router.get("/search")
async def search(request: Request, q: str = "", _=Depends(auth)):
    d = _ctx(request)
    return JSONResponse({"rows": d.search_payload(q)})


@router.get("/stream")
async def stream(request: Request, _=Depends(auth)):
    """SSE of scan, audit_layer, score, size, order, fill, exit, balance."""
    from fastapi.responses import StreamingResponse
    d = _ctx(request)

    async def gen():
        import asyncio
        while True:
            try:
                ev = await asyncio.wait_for(d.bus.events.get(), timeout=15)
                yield f"event: {ev.get('kind','message')}\ndata: {json.dumps(ev, default=str)}\n\n"
            except asyncio.TimeoutError:
                yield ": keepalive\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-store"})


@router.get("/health")
async def health(request: Request):
    d = _ctx(request)
    return JSONResponse(d.health_payload())
