"""The five bots. Each module owns one bot and talks only through bus.py and db."""
