"""bots/analyst.py — Bot 2. 8 layers in order, then the score.

`run_layers` and `score` are pure: they take a plain snapshot dict so tests can drive every
layer red without a network. The async worker fills the snapshot from RPC / RugCheck /
DexScreener / FOMO through fields.py.
"""

from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger("analyst")

NAME = "Analyst"
COLOR = "#ffd60a"

LAYERS = [
    (1, "Mint authority"),
    (2, "Freeze authority"),
    (3, "Dev wallet"),
    (4, "Top 10"),
    (5, "Liquidity"),
    (6, "Pool age"),
    (7, "Bundles"),
    (8, "Delegations"),
]


def _layer(n: int, name: str, ok: bool, value: str, source: str) -> dict:
    return {"n": n, "name": name, "pass": ok, "value": value, "source": source}


def run_layers(s: dict, cfg: dict) -> list[dict]:
    """Stop at the first red; the rest are greyed as 'not checked'."""
    cfg = {**{"min_pool_age_min": 10}, **(cfg or {})}
    out: list[dict] = []

    def add(n: int, name: str, ok: bool, value: str, source: str) -> bool:
        out.append(_layer(n, name, ok, value, source))
        return ok

    if not add(1, "Mint authority", s.get("mint_authority") is None,
               "Revoked" if s.get("mint_authority") is None else "mint not revoked", "rpc"):
        return out
    if not add(2, "Freeze authority", s.get("freeze_authority") is None,
               "Revoked" if s.get("freeze_authority") is None else "freeze not revoked", "rpc"):
        return out

    dev_pct = s.get("dev_pct")
    dev_sold = bool(s.get("dev_sold"))
    if dev_pct is None:
        add(3, "Dev wallet", False, "no data: dev", "rugcheck")
        return out
    if s.get("creator_rugged"):
        add(3, "Dev wallet", False,
            f"dev rugged {s['creator_rugged']} before", "rugs")
        return out
    if dev_sold:
        add(3, "Dev wallet", False, "dev sold", "rugcheck")
        return out
    if dev_pct >= cfg["max_dev_pct"]:
        add(3, "Dev wallet", False, f"dev holds {dev_pct:g}%", "rugcheck")
        return out
    add(3, "Dev wallet", True, f"{dev_pct:g}% · sold 0", "rugcheck")

    top10 = s.get("top10_pct")
    if top10 is None:
        add(4, "Top 10", False, "no data: top holders", "rpc")
        return out
    if not add(4, "Top 10", top10 < cfg["analyst_max_top10_pct"],
               f"{top10:g}%", "rpc"):
        out[-1]["value"] = f"top 10 hold {top10:g}%"
        return out

    lp = s.get("lp_locked_pct")
    liq_drop = s.get("liq_drop_pct") or 0
    if lp is None:
        add(5, "Liquidity", False, "no data: liquidity", "rugcheck")
        return out
    if lp < cfg["min_lp_locked_pct"]:
        add(5, "Liquidity", False, "liquidity unlocked", "rugcheck")
        return out
    if liq_drop > 50:
        add(5, "Liquidity", False, f"liquidity {liq_drop:.0f}% down since scan", "dexscreener")
        return out
    add(5, "Liquidity", True, f"{lp:g}% burned", "rugcheck")

    age = s.get("age_min")
    if age is None:
        add(6, "Pool age", False, "no data: age", "dexscreener")
        return out
    if not add(6, "Pool age", age >= cfg["min_pool_age_min"], f"{age:.0f}m", "dexscreener"):
        out[-1]["value"] = "pool too young"
        return out

    biggest = s.get("biggest_bundle")
    if biggest is None:
        add(7, "Bundles", False, "no data: bundles", "rugcheck")
        return out
    insiders = s.get("insider_pct") or 0.0
    if biggest >= cfg["max_bundled"]:
        add(7, "Bundles", False, f"{biggest} bundled wallets", "rugcheck")
        return out
    if insiders >= 15:
        add(7, "Bundles", False, f"insiders hold {insiders:g}%", "rugcheck")
        return out
    add(7, "Bundles", True, f"{biggest} bundled · insiders {insiders:g}%", "rugcheck")

    delegates = s.get("max_delegate_holders")
    if delegates is None:
        add(8, "Delegations", False, "no data: delegations", "rpc")
        return out
    if delegates > cfg["max_delegated_accounts"]:
        add(8, "Delegations", False,
            f"{delegates} wallets → {s.get('worst_delegate', '?')}", "rpc")
        return out
    add(8, "Delegations", True, "None", "rpc")
    return out


def fresh_pct(pairs: list[dict]) -> float | None:
    """Share of the top-20 holder owners with under 10 signatures."""
    vals = [p.get("fresh") for p in pairs]
    vals = [v for v in vals if v is not None]
    if not vals:
        return None
    return round(100.0 * sum(1 for v in vals if v) / len(vals), 2)


def score(s: dict, cfg: dict, social: float | None) -> dict:
    a = cfg["analyst"]
    b = cfg["brain"]
    alive = min(1.0, max(0.0, (s.get("volume_h1") or 0) / a["alive_volume_h1"]))

    if s.get("unique_buys_1") is not None:
        organic = min(1.0, max(0.0, s["unique_buys_1"] / a["organic_unique_h1"]))
        basis = "unique"
    else:
        organic = min(1.0, max(0.0, (s.get("buys_h1") or 0) / a["organic_buys_h1"]))
        basis = "txns"
    if (s.get("unique_sells_1") or 0) > (s.get("unique_buys_1") or 0):
        organic *= a["bundled_penalty"]
    if (s.get("bundled_wallets") or 0) >= 3:
        organic *= a["bundled_penalty"]
    if s.get("curve_min") is not None and s["curve_min"] < a["fast_curve_min"]:
        organic *= a["bundled_penalty"]
    fp = s.get("fresh_pct")
    if fp is not None and fp >= a["max_fresh_pct"]:
        organic *= a["bundled_penalty"]

    ratio = a["flush_sell_ratio"]
    us5, ub5 = s.get("unique_sells_5m"), s.get("unique_buys_5m")
    if us5 is not None and ub5 is not None:
        flush = 1.0 if us5 <= ub5 else (0.5 if us5 <= ratio * ub5 else 0.0)
    else:
        ts5, tb5 = s.get("sells_m5"), s.get("buys_m5")
        flush = 0.0
        if ts5 is not None and tb5 is not None:
            flush = 1.0 if ts5 <= tb5 else (0.5 if ts5 <= ratio * tb5 else 0.0)

    chase = min(1.0, max(0.0, (s.get("h1_change_pct") or 0) / a["chase_h1_pct"]))
    core = alive + organic + flush + (1 - chase)

    w = cfg["social"]["social_weight"] if social is not None else 0.0
    total = round(100 * (core + w * (social or 0)) / (4 + w))
    core_pts = round(100 * core / 4)
    social_pts = total - core_pts

    passed = total >= a["min_score"]
    reason = None
    if not passed:
        parts = []
        if alive < 0.5:
            parts.append("thin volume")
        if organic < 0.5:
            parts.append("looks bundled" if basis == "unique" else "few buyers")
        if flush == 0:
            parts.append("sellers in control")
        if chase > 0.6:
            parts.append("already ran")
        reason = ", ".join(parts) or f"score {total}"
    return {
        "alive": round(alive, 3), "organic": round(organic, 3), "flush": flush,
        "chase": round(chase, 3), "social": social, "fresh_pct": fp,
        "social_pts": social_pts, "score": total, "pass": passed, "reason": reason,
        "organic_basis": basis,
    }


def social_flag(cfg: dict, social: float | None) -> str:
    if social is None:
        return "social: off"
    return f"social {social:.2f} · weight {cfg['social']['social_weight']:g}"


class Analyst:
    def __init__(self, bus, cfg, db, sources=None, selftest=False):
        self.bus, self.cfg, self.db, self.sources = bus, cfg, db, sources
        self.selftest = selftest
        self.seen_tonight: set[str] = set()
        self.count = 0

    def audit(self, mint: str, snapshot: dict) -> dict:
        layers = run_layers(snapshot, self.cfg.group("analyst"))
        green = len(layers) == 8 and all(l["pass"] for l in layers)
        social = snapshot.get("social") if green else None
        sc = score(snapshot, {"analyst": self.cfg.group("analyst"),
                              "brain": self.cfg.group("brain"),
                              "social": self.cfg.group("social")}, social)
        with self.db.tx() as cur:
            for l in layers:
                cur.execute(
                    "INSERT INTO audits (mint, ts, layer, name, value_text, pass, source) "
                    "VALUES (?,strftime('%Y-%m-%dT%H:%M:%fZ','now'),?,?,?,?,?)",
                    (mint, l["n"], l["name"], l["value"], 1 if l["pass"] else 0, l["source"]),
                )
            cur.execute(
                "INSERT INTO scores (mint, ts, alive, organic, flush, chase, social, social_pts,"
                " fresh_pct, score, pass, reason) "
                "VALUES (?,strftime('%Y-%m-%dT%H:%M:%fZ','now'),?,?,?,?,?,?,?,?,?,?)",
                (mint, sc["alive"], sc["organic"], sc["flush"], sc["chase"], sc["social"],
                 sc["social_pts"], sc["fresh_pct"], sc["score"], 1 if sc["pass"] else 0,
                 sc["reason"]),
            )
        passed = green and sc["pass"]
        reason = sc["reason"]
        if not green:
            red = next((l for l in layers if not l["pass"]), None)
            reason = f"layer {red['n']}: {red['value']}" if red else "not all layers checked"
        out = {
            "bot": "analyst", "mint": mint, "layers": layers,
            "holders": snapshot.get("holders"), "score": sc["score"], "social": sc["social"],
            "socialPts": sc["social_pts"], "passed": passed, "reason": reason,
            "flag": social_flag({"social": self.cfg.group("social")}, sc["social"]),
            "organic_basis": sc["organic_basis"],
        }
        self.count += 1
        self.db.decide("analyst", mint, out)
        if not passed:
            self.db.log_activity("rejected", mint, "Analyst",
                                 f"Rejected {snapshot.get('symbol') or mint[:6]}",
                                 f"Analyst · {reason}", "Skipped")
        return out
