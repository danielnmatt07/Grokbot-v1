"""bots/brain.py — Bot 3. Sizes. Never picks a coin, never clicks.

size() is pure: cash, score, liquidity and the flags go in, a decision comes out, so the
defaults are checkable by hand ($100 cash, score 80 -> $12; 79 -> $6; <$2 -> skip).
"""

from __future__ import annotations

import logging

log = logging.getLogger("brain")

NAME = "Brain"
COLOR = "#bf5af2"


def size(cash: float, score_value: float, liquidity_usd: float | None, cfg: dict,
         shill_ring: bool = False, trades_tonight: int = 0,
         night_loss_pct: float = 0.0) -> dict:
    b = cfg["brain"]
    r = cfg["risk"]
    if night_loss_pct >= r["night_loss_stop_pct"]:
        return {"sizeUsd": 0, "pctOfCash": 0, "capHit": "none",
                "reason": f"night loss stop {night_loss_pct:g}%",
                "raw": 0, "skip": True}
    if trades_tonight >= b["max_trades_night"]:
        return {"sizeUsd": 0, "pctOfCash": 0, "capHit": "none",
                "reason": "max trades tonight", "raw": 0, "skip": True}

    raw = cash * b["risk_per_trade_pct"] / 100.0 / (r["stop_pct"] / 100.0)
    if score_value >= b["full_size_score"]:
        after_score = raw
    else:
        after_score = raw * b["below_full_pct"] / 100.0
    # a ticket is never bigger than the cash that is actually free
    after_score = min(after_score, cash)
    if round(after_score, 2) == round(cash, 2) and cash > 0:
        cash_bound = True
    else:
        cash_bound = False

    caps: list[tuple[str, float, str]] = []
    if shill_ring:
        caps.append(("shill", after_score / 2.0, "shill ring"))
    if liquidity_usd:
        pool_cap = liquidity_usd * b["max_pool_pct"] / 100.0
        caps.append(("pool", pool_cap, f"{b['max_pool_pct']:g}% of pool"))
    caps.append(("ticket", float(b["max_ticket_usd"]), f"max ticket ${b['max_ticket_usd']:g}"))

    final = after_score
    binding = min(caps, key=lambda c: c[1])
    cap_hit = "none"
    reason = ("80+ = full size" if score_value >= b["full_size_score"] else "under 80 = half size")
    if binding[1] < after_score:
        final, cap_hit, reason = binding[1], binding[0], binding[2]
    elif cash_bound:
        final, cap_hit, reason = cash, "cash", "all of the free cash"

    final = round(final, 2)
    if cash <= 0:
        return {"sizeUsd": 0, "pctOfCash": 0, "capHit": "none", "reason": "no free cash",
                "raw": 0, "skip": True}
    if final < b["min_ticket_usd"]:
        return {"sizeUsd": 0, "pctOfCash": 0, "capHit": cap_hit,
                "reason": f"under ${b['min_ticket_usd']:g}", "raw": round(after_score, 2),
                "skip": True}

    return {
        "sizeUsd": final, "pctOfCash": round(100.0 * final / cash, 1), "capHit": cap_hit,
        "reason": reason, "raw": round(after_score, 2), "skip": False,
    }


class Brain:
    def __init__(self, bus, cfg, db):
        self.bus, self.cfg, self.db = bus, cfg, db
        self.count = 0

    async def size_for(self, mint: str, score_value: float, liquidity_usd: float | None,
                       cash: float, *, shill_ring=False, trades_tonight=0,
                       night_loss_pct=0.0, symbol: str | None = None) -> dict:
        cfg = {"brain": self.cfg.group("brain"), "risk": self.cfg.group("risk")}
        d = size(cash, score_value, liquidity_usd, cfg, shill_ring, trades_tonight,
                 night_loss_pct)
        out = {"bot": "brain", "mint": mint, "symbol": symbol, "score": score_value,
               "sizeUsd": d["sizeUsd"], "pctOfCash": d["pctOfCash"],
               "capHit": d["capHit"], "reason": d["reason"], "skip": d["skip"]}
        self.count += 1
        self.db.decide("brain", mint, out)
        if d["skip"]:
            self.db.log_activity("rejected", mint, "Brain", f"Skipped {symbol or mint[:6]}",
                                 f"Brain · {d['reason']}", "Skipped")
        return out
