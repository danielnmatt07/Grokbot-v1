"""bots/executor.py — Bot 4. Clicks Buy and takes profit, only through browser.py.

The rules are functions (dip_ok, recheck, take_profit) so tests and the PAPER replay drive
the same code the live lane uses. The click itself is delegated to the lane interface, which
in PAPER stops before the primary button.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

log = logging.getLogger("executor")

NAME = "Executor"
COLOR = "#00d35a"


def high10(series: list[tuple[str, float]], window_min: float = 10.0) -> float | None:
    """Top price of the last N minutes. series is [(iso_ts, price)] oldest first."""
    if not series:
        return None
    now = datetime.now(timezone.utc)
    prices = []
    for ts, price in series:
        try:
            t = datetime.strptime(ts.replace("Z", "+0000"), "%Y-%m-%dT%H:%M:%S.%f%z")
        except ValueError:
            try:
                t = datetime.strptime(ts.replace("Z", "+0000"), "%Y-%m-%dT%H:%M:%S%z")
            except ValueError:
                continue
        if (now - t).total_seconds() <= window_min * 60 and price:
            prices.append(price)
    return max(prices) if prices else None


def dip_state(price: float, high: float | None, cfg: dict,
              unique_sells_5m: float | None, unique_buys_5m: float | None,
              sells_m5: float | None = None, buys_m5: float | None = None) -> tuple[str, str | None]:
    """('buy'|'wait'|'crash', reason)"""
    if high is None or not price:
        return "wait", None
    drop = 1 - price / high
    if drop * 100 > cfg["crash_pct"]:
        return "crash", f"crash -{drop * 100:.0f}%"
    if drop * 100 < cfg["dip_pct"]:
        return "wait", None
    us, ub = unique_sells_5m, unique_buys_5m
    if us is None or ub is None:
        us, ub = sells_m5, buys_m5
    if us is None or ub is None:
        return "buy", None
    if us <= cfg.get("flush_sell_ratio", 1.5) * ub:
        return "buy", None
    return "wait", None


def recheck(ctx: dict, cfg: dict) -> str | None:
    """Return a skip reason, or None to proceed."""
    liq0 = ctx.get("liquidity_at_scan")
    liq = ctx.get("liquidity_usd")
    if liq0 and liq is not None:
        if (1 - liq / liq0) * 100 > cfg["recheck_liq_drop_pct"]:
            return "liquidity dropping"
    p0 = ctx.get("price_at_analyst")
    p = ctx.get("price_usd")
    if p0 and p:
        if (p / p0 - 1) * 100 > cfg["recheck_price_up_pct"]:
            return "ran before the click"
    if ctx.get("free_cash", 0) < ctx.get("size_usd", 0):
        return "no free cash"
    if ctx.get("disable_selling") or ctx.get("disable_buying"):
        return "FOMO: selling off"
    dev0, dev = ctx.get("creator_balance_at_analyst"), ctx.get("creator_balance")
    if dev0 is not None and dev is not None and dev < dev0:
        return "dev sold while we waited"
    return None


def take_profit(entry: float, price: float, peak: float, tp_done: bool,
                trail_active: bool, cfg: dict) -> tuple[int, str] | None:
    """Return (pct, reason) to sell, or None."""
    if not entry or not price:
        return None
    if not tp_done and price >= entry * cfg["tp_x"]:
        return int(cfg["tp_sell_pct"]), "take profit"
    if (tp_done or trail_active) and peak:
        if price <= peak * (1 - cfg["trail_pct"] / 100.0):
            return 100, "trail"
    return None


class Executor:
    def __init__(self, bus, cfg, db, lane=None, market=None):
        self.bus, self.cfg, self.db, self.lane, self.market = bus, cfg, db, lane, market
        self.count = 0

    def free_cash(self) -> float:
        """PAPER: simulated cash. LIVE: the last /balances read."""
        from desk import deskstate
        return deskstate.free_cash(self.db, self.cfg)

    async def buy(self, mint: str, size_usd: float, symbol: str, ctx: dict,
                  *, paper: bool = True, bot_owner: str = "Executor") -> dict:
        cfg = self.cfg.group("executor")
        skip = recheck(ctx, cfg)
        order_id = self.db.exec(
            "INSERT INTO orders (ts, mint, side, usd, pct, bot, reason, status) "
            "VALUES (strftime('%Y-%m-%dT%H:%M:%fZ','now'),?,?,?,?,?,?,?)",
            (mint, "buy", size_usd, None, bot_owner, ctx.get("reason"), "queued"),
        )
        self.db.exec("UPDATE orders SET id=? WHERE rowid=?",
                     (order_id, self.db.scalar("SELECT max(rowid) FROM orders")))
        if skip:
            self._fail(order_id, "skipped", skip)
            return {"bot": "executor", "order": order_id, "mint": mint, "side": "buy",
                    "usd": size_usd, "pct": None, "status": "skipped", "reason": skip,
                    "checks": {"screen": False, "api": False, "chain": False}}

        result = await self.lane.buy(mint=mint, usd=size_usd, symbol=symbol, paper=paper,
                                    owner=bot_owner)
        self._settle(order_id, result, mint, "buy", size_usd, symbol, paper,
                     ctx.get("price_usd"))
        return {"bot": "executor", "order": order_id, "mint": mint, "side": "buy",
                "usd": size_usd, "pct": None, "status": result["status"],
                "reason": result.get("reason"),
                "checks": result.get("checks", {}), "link": None}

    async def sell(self, mint: str, pct: int, symbol: str, *, reason: str,
                   paper: bool = True, owner: str = "Executor", price: float | None = None) -> dict:
        pos = self.db.one(
            "SELECT * FROM positions WHERE mint=? AND closed_at IS NULL ORDER BY id DESC LIMIT 1",
            (mint,),
        )
        usd = None
        if pos:
            usd = round(pos["size_usd"] * pct / 100.0, 2)
        order_id = self.db.exec(
            "INSERT INTO orders (ts, mint, side, usd, pct, bot, reason, status) "
            "VALUES (strftime('%Y-%m-%dT%H:%M:%fZ','now'),?,?,?,?,?,?,?)",
            (mint, "sell", usd, pct, owner, reason, "queued"),
        )
        result = await self.lane.sell(mint=mint, pct=pct, symbol=symbol, paper=paper,
                                     owner=owner, price=price)
        self._settle(order_id, result, mint, "sell", usd, symbol, paper, price, pct=pct,
                     reason=reason)
        return {"bot": "executor", "order": order_id, "mint": mint, "side": "sell",
                "usd": usd, "pct": pct, "status": result["status"],
                "reason": result.get("reason"), "checks": result.get("checks", {})}

    # ---------------------------------------------------------------- internals
    def _fail(self, order_id: int, status: str, reason: str) -> None:
        self.db.exec("UPDATE orders SET status=?, error=? WHERE rowid=?",
                     (status, reason, order_id))
        log.info("order %s %s: %s", order_id, status, reason)

    def _settle(self, order_id: int, result: dict, mint: str, side: str, usd: float | None,
                symbol: str, paper: bool, price: float | None, pct: int | None = None,
                reason: str | None = None) -> None:
        checks = result.get("checks", {})
        self.db.exec(
            "UPDATE orders SET status=?, quote_text=?, fee_text=?, screen_ok=?, api_ok=?, "
            "chain_ok=?, fill_usd=?, error=?, shot_path=? WHERE rowid=?",
            (result["status"], result.get("quote_text"), result.get("fee_text"),
             1 if checks.get("screen") else 0, 1 if checks.get("api") else 0,
             1 if checks.get("chain") else 0, result.get("fill_usd"),
             result.get("reason"), result.get("shot_path"), order_id),
        )
        if result["status"] not in ("done", "paper_done"):
            return
        from desk import deskstate
        if side == "buy":
            deskstate.open_position(self.db, self.cfg, mint, symbol, result, usd, paper)
        else:
            deskstate.close_position(self.db, self.cfg, mint, symbol, result, pct or 100,
                                     reason or "sell", paper)
