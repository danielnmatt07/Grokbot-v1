"""bots/risk.py — Bot 5. Cuts losers with its own cursor.

`check()` is the whole rule set in order, pure and testable. `poll()` runs it against the
live price feed every risk_poll_s and hands sells to the Executor (which jumps the lane).
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

log = logging.getLogger("risk")

NAME = "Risk"
COLOR = "#ff6b9a"


def check(pos: dict, price: float | None, now_iso: str, cfg: dict,
          *, liquidity_usd: float | None = None, liquidity_prev: float | None = None,
          creator_balance: float | None = None, creator_balance_at_buy: float | None = None,
          disable_selling: bool = False, warnings: list[str] | None = None,
          misses: int = 0, lane_plan: str = "A") -> dict | None:
    """Return an exit dict {'pct','reason','price'} or None."""
    entry = pos.get("entry_price") or 0
    if not entry:
        return None

    if misses >= 12:
        return {"pct": 100, "reason": "no price", "price": price}

    stop_pct = fire_stop_pct(cfg, lane_plan)
    stop_line_ = pos.get("stop_price") or entry * (1 - cfg["stop_pct"] / 100.0)
    if price is not None:
        if price <= entry * (1 - stop_pct / 100.0) or price <= stop_line_:
            return {"pct": 100, "reason": "stop", "price": price}

    if liquidity_prev and liquidity_usd is not None:
        if liquidity_usd <= 0 or (1 - liquidity_usd / liquidity_prev) * 100 > 80:
            return {"pct": 100, "reason": "pulled", "price": price}

    if creator_balance_at_buy and creator_balance is not None:
        if creator_balance < creator_balance_at_buy * 0.5:
            return {"pct": 100, "reason": "dev dumping", "price": price}

    if warnings or disable_selling:
        return {"pct": 100, "reason": "FOMO warns", "price": price}

    opened = pos.get("opened_at")
    if opened and price is not None:
        try:
            t = datetime.strptime(opened.replace("Z", "+0000"), "%Y-%m-%dT%H:%M:%S.%f%z")
        except ValueError:
            t = None
        if t:
            hours = (datetime.now(timezone.utc) - t).total_seconds() / 3600.0
            if hours >= cfg["timeout_h"] and price < entry * (1 + cfg["timeout_min_gain_pct"] / 100.0):
                return {"pct": 100, "reason": "dead money", "price": price}
    return None


def stop_line(entry: float, cfg: dict) -> float:
    return round(entry * (1 - cfg["stop_pct"] / 100.0), 12)


def fire_stop_pct(cfg: dict, lane_plan: str = "A") -> float:
    """Plan B clicks are slower: fire at -22% instead of -25% to leave room."""
    if lane_plan == "B":
        return max(0.0, float(cfg["stop_pct"]) - 3)
    return float(cfg["stop_pct"])


def tighten(current_stop: float | None, entry: float, cfg: dict) -> float:
    """The stop only ever tightens; a looser setting never moves an open stop down."""
    line = stop_line(entry, cfg)
    if current_stop is None:
        return line
    return max(current_stop, line)


class Risk:
    def __init__(self, bus, cfg, db, executor=None, market=None):
        self.bus, self.cfg, self.db, self.executor, self.market = bus, cfg, db, executor, market
        self.pending_call = False
        self.misses: dict[str, int] = {}

    def open_positions(self) -> list[dict]:
        rows = self.db.q("SELECT * FROM positions WHERE closed_at IS NULL ORDER BY id")
        return [dict(r) for r in rows]

    def evaluate(self, pos: dict, price: float | None, extra: dict | None = None) -> dict | None:
        cfg = self.cfg.group("risk")
        extra = extra or {}
        ex = check(pos, price, "", cfg,
                   liquidity_usd=extra.get("liquidity_usd"),
                   liquidity_prev=extra.get("liquidity_prev"),
                   creator_balance=extra.get("creator_balance"),
                   creator_balance_at_buy=pos.get("creator_balance_at_buy"),
                   disable_selling=extra.get("disable_selling", False),
                   warnings=extra.get("warnings") or [],
                   misses=self.misses.get(pos["mint"], 0),
                   lane_plan=self.cfg.get("lane_plan"))
        return ex

    def night_loss_pct(self) -> float:
        start = self.cfg.get("night_start_cash") or 0
        if not start:
            return 0.0
        cash = self.db.scalar(
            "SELECT value FROM balance ORDER BY rowid DESC LIMIT 1", default=start)
        if not cash:
            return 0.0
        return max(0.0, (start - cash) / start * 100.0)

    def paused(self) -> bool:
        row = self.db.one("SELECT value FROM settings WHERE key='risk_paused'")
        return bool(row and row["value"] == "true")

    async def poll_once(self, prices: dict[str, float], extras: dict | None = None) -> list[dict]:
        extras = extras or {}
        exits = []
        for pos in self.open_positions():
            mint = pos["mint"]
            price = prices.get(mint)
            if price is None:
                self.misses[mint] = self.misses.get(mint, 0) + 1
            else:
                self.misses[mint] = 0
                if price > (pos.get("peak_price") or 0):
                    self.db.exec("UPDATE positions SET peak_price=? WHERE id=?", (price, pos["id"]))
                    pos["peak_price"] = price
            ex = self.evaluate(pos, price, extras.get(mint))
            if ex:
                exits.append({**ex, "mint": mint, "pos": pos})
        return exits
