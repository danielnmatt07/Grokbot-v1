"""bots/scanner.py — Bot 1. Counts and cuts. Never judges quality.

Pure decision function first (`judge`) so tests can prove the kills, then the async worker
that feeds it from PumpPortal / DexScreener / FOMO.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger("scanner")

NAME = "Scanner"
COLOR = "#64d2ff"


@dataclass
class Pool:
    mint: str
    name: str = ""
    symbol: str = ""
    pool: str | None = None
    creator: str | None = None
    migrated_at: str | None = None
    age_min: float | None = None
    liquidity_usd: float | None = None
    top10_pct: float | None = None
    h1_change_pct: float | None = None
    holders: int | None = None
    holders_growth: float | None = None
    volume_m5: float | None = None
    volume_h1: float | None = None
    market_cap: float | None = None
    curve_min: float | None = None
    warnings: list[str] = field(default_factory=list)
    disable_buying: bool = False
    disable_selling: bool = False
    known_pair: bool = True


def copycat(symbol: str | None, runners: list[str]) -> str | None:
    """lowercase, no spaces/digits/emoji, then exact or one name inside the other."""
    def norm(s: str) -> str:
        return "".join(ch for ch in (s or "").lower() if ch.isalpha())

    me = norm(symbol or "")
    if not me:
        return None
    for r in runners:
        other = norm(r)
        if not other:
            continue
        if me == other or me in other or other in me:
            return r
    return None


def judge(p: Pool, cfg: dict, runners: list[str] | None = None) -> tuple[str, str | None, dict]:
    """Return (verdict, reason, metrics). First hit kills; pass only at min pool age."""
    min_age = cfg.get("min_pool_age_min", 10)
    max_wait = cfg.get("max_wait_min", 60)
    # a coin is never a copycat of itself
    peers = [r for r in (runners or []) if (r or "").strip().lower() !=
             (p.symbol or "").strip().lower()]
    liq_mcap = None
    if p.liquidity_usd and p.market_cap:
        liq_mcap = round(p.liquidity_usd / p.market_cap, 4)
    accel = None
    if p.volume_m5 is not None and p.volume_h1:
        accel = round(p.volume_m5 * 12 / p.volume_h1, 3)
    metrics = {"liq_mcap": liq_mcap, "accel": accel}

    if not p.known_pair:
        return "kill", "no pair on DexScreener", metrics
    if p.disable_selling or p.disable_buying:
        return "kill", "FOMO: selling off", metrics
    if p.warnings:
        return "kill", f"FOMO warns: {p.warnings[0]}", metrics
    if p.liquidity_usd is not None and p.liquidity_usd < cfg["min_liquidity_usd"]:
        return "kill", f"liq ${p.liquidity_usd / 1000:,.1f}K", metrics
    if p.top10_pct is not None and p.top10_pct > cfg["max_top10_pct"]:
        return "kill", f"top 10 hold {p.top10_pct:g}%", metrics
    if p.h1_change_pct is not None and p.h1_change_pct > cfg["max_h1_change_pct"]:
        return "kill", f"+{p.h1_change_pct:g}% in 1h", metrics
    twin = copycat(p.symbol, peers)
    if twin:
        return "kill", f"copycat of {twin}", metrics

    if p.age_min is None:
        return "wait", None, metrics
    if p.age_min < min_age:
        return "wait", None, metrics
    if p.holders_growth is not None and p.holders_growth * 100 < cfg["min_holders_growth_pct"]:
        return "kill", f"holders leaving {p.holders_growth * 100:+.0f}% in 10m", metrics
    if p.age_min > max_wait:
        return "kill", "too old for the room", metrics
    return "pass", None, metrics


class Scanner:
    """Async worker. selftest=True never touches the network: it replays fixtures."""

    def __init__(self, bus, cfg, db, market=None, selftest=False):
        self.bus, self.cfg, self.db, self.market = bus, cfg, db, market
        self.selftest = selftest
        self.stats = {"seen": 0, "pass": 0, "kill": 0}

    async def consider(self, p: Pool, runners: list[str]) -> dict:
        cfg = self.cfg.group("scanner")
        verdict, reason, metrics = judge(p, cfg, runners)
        self.db.exec(
            "INSERT INTO scans (mint, ts, liquidity_usd, top10_pct, h1_change_pct, age_min, "
            "liq_mcap, accel, holders_growth, verdict, reason) "
            "VALUES (?,strftime('%Y-%m-%dT%H:%M:%fZ','now'),?,?,?,?,?,?,?,?,?)",
            (p.mint, p.liquidity_usd, p.top10_pct, p.h1_change_pct, p.age_min,
             metrics["liq_mcap"], metrics["accel"], p.holders_growth, verdict, reason),
        )
        out = {
            "bot": "scanner", "mint": p.mint, "name": p.name, "symbol": p.symbol,
            "pool": p.pool, "liquidityUsd": p.liquidity_usd, "top10Pct": p.top10_pct,
            "h1ChangePct": p.h1_change_pct, "ageMin": p.age_min,
            "liqMcap": metrics["liq_mcap"], "accel": metrics["accel"],
            "holdersGrowth": p.holders_growth, "verdict": verdict, "reason": reason,
            "holders": p.holders,
        }
        self.stats["seen"] += 1
        self.stats[verdict if verdict != "wait" else "kill"] = (
            self.stats.get(verdict, 0) + 0 if verdict == "wait" else self.stats[verdict] + 1
        )
        self.db.decide("scanner", p.mint, out)
        if verdict == "kill":
            self.db.log_activity("rejected", p.mint, "Scanner", f"Killed {p.symbol}",
                                 f"Scanner · {reason}", "Cut")
        if verdict == "pass" and self.bus:
            await self.bus.to_analyst(out)
        return out

    async def run(self, stop_event) -> None:
        if self.selftest or self.market is None:
            # no network in this environment: heartbeat only, fixtures drive consider()
            import asyncio
            while not stop_event.is_set():
                self.db.beat("scanner")
                await asyncio.sleep(5)
            return
        async for pools in self.market.migrations():
            if stop_event.is_set():
                break
            self.db.beat("scanner")
            runners = await self.market.runners()
            for p in pools:
                await self.consider(p, runners)
