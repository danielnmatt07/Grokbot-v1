"""browser.py — THE ONLY module that touches FOMO web.

Everything that can be decided without a browser is decided here and tested: the page
allow-list, the clickable allow-list, the never-click list, the amount read-back and the
cursor positions. The actual clicking is a thin layer on top, so the rules hold whether the
lane runs against a real Chrome (plan A) or a webhook routine (plan B).

Selectors come from fomo_web.md. Nothing here guesses a selector: `Lesson` raises
LaneBlocked if a needed lesson is missing, so a PAPER night cannot start on guesses.
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from desk import links

log = logging.getLogger("browser")

BOTS = {"Scanner": "#64d2ff", "Analyst": "#ffd60a", "Brain": "#bf5af2",
        "Executor": "#00d35a", "Risk": "#ff6b9a"}

ALLOWED_PAGES = re.compile(
    r"^https://fomo\.family/(coin\?|profile/[A-Za-z0-9_.-]+\?|search)")
NEVER_TEXT = (
    "withdraw", "deposit", "deposit more", "buy with apple pay", "orders", "perps", "send",
    "settings", "export", "private key", "seed", "swap settings", "slippage", "discover",
    "thesis", "confirm withdraw", "review withdraw",
)
# Labels that mean "a box to tick" or "a fee you must accept". A box to tick = skip.
CHECKBOX_TEXT = (
    "high network fee", "i understand", "i agree", "custom fee", "priority fee",
    "safety warning", "advanced",
)
ALLOWED_TEXT = (
    "buy", "sell", "paste", "max", "trending", "search",
)
PRESETS = ("$10", "$100", "$500", "$1000", "10%", "25%", "50%", "100%")


class LaneBlocked(RuntimeError):
    """The lane refuses to act. Surfaced to the owner, never retried silently."""


@dataclass
class Cursor:
    bot: str
    color: str
    x: float = 0.0
    y: float = 0.0

    def css(self) -> str:
        return (f"#{self.color.replace('#', '')}")


@dataclass
class LaneResult:
    status: str                     # done | paper_done | failed | unverified | skipped
    reason: str | None = None
    checks: dict = field(default_factory=dict)
    quote_text: str | None = None
    fee_text: str | None = None
    fill_usd: float | None = None
    price: float | None = None
    tokens: float | None = None
    shot_path: str | None = None


# ------------------------------------------------------------------ rules
def page_allowed(url: str) -> bool:
    return bool(ALLOWED_PAGES.match(url or ""))


def require_fomo_url(url: str) -> None:
    """A coin page must be exactly what links.py returns, or the lane refuses."""
    if not url.startswith(links.COIN_PREFIX):
        raise LaneBlocked(f"refusing to open {url!r}: not a links.py coin url")
    if any(p not in url for p in links.COIN_PARAMS):
        raise LaneBlocked(f"refusing to open {url!r}: parameters missing")


def coin_page(mint: str) -> str:
    return links.coin_url(mint, "solana")


def is_preset(text: str) -> bool:
    return text.strip() in PRESETS


def may_click(text: str, *, side: str, symbol: str | None) -> bool:
    """The clickable allow-list, including the never list and the checkbox rule."""
    t = (text or "").strip()
    low = t.lower()
    if not t:
        return False
    if any(bad in low for bad in NEVER_TEXT):
        return False
    if any(bad in low for bad in CHECKBOX_TEXT):
        return False
    if side == "buy" and symbol and low == f"buy {symbol}".lower():
        return True
    if side == "sell" and symbol and low == f"sell {symbol}".lower():
        return True
    if low in ("paste", "max", "trending", "search", "buy", "sell"):
        return True
    if is_preset(t):
        return True
    return False


def refuses(text: str) -> bool:
    """A box to tick, a destructive control, or a fee you must accept = skip."""
    low = (text or "").lower()
    return any(bad in low for bad in NEVER_TEXT + CHECKBOX_TEXT)


def amount_matches(typed: str, expected: float) -> bool:
    cleaned = (typed or "").replace("$", "").replace(",", "").strip()
    try:
        return abs(float(cleaned) - round(float(expected), 2)) < 0.005
    except ValueError:
        return False


def quote_ready(quote_text: str | None) -> bool:
    if not quote_text:
        return False
    t = quote_text.strip().lower()
    return bool(t) and "loading" not in t and "—" not in t and t not in ("-", "n/a")


def cursor_css() -> str:
    parts = []
    for bot, color in BOTS.items():
        parts.append(
            f".cursor-{bot.lower()} {{ --c: {color}; }}"
        )
    return "\n".join(parts)


def cursor_js() -> str:
    """Injected once into the desk tab. Draws one arrow per bot; never covers a button."""
    return """
(() => {
  if (window.__deskCursors) return;
  const bots = {
    Scanner: '#64d2ff', Analyst: '#ffd60a', Brain: '#bf5af2',
    Executor: '#00d35a', Risk: '#ff6b9a'
  };
  const root = document.createElement('div');
  root.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483000';
  document.documentElement.appendChild(root);
  const make = (name, color) => {
    const wrap = document.createElement('div');
    wrap.style.cssText = 'position:absolute;left:0;top:0;transform:translate(-50%,-50%);' +
      'transition:transform 300ms cubic-bezier(.2,.8,.2,1);will-change:transform';
    wrap.innerHTML =
      `<svg width="22" height="22" viewBox="0 0 22 22" style="display:block;filter:drop-shadow(0 1px 2px rgba(0,0,0,.5))">
         <path d="M3 2 L18 10.5 L11 11.6 L8.2 18.5 Z" fill="${color}" stroke="#000" stroke-width="1"/>
       </svg>
       <div style="font:600 11px -apple-system,system-ui;color:${color};text-shadow:0 1px 2px #000;
                   margin-top:-2px;white-space:nowrap">${name}</div>`;
    root.appendChild(wrap);
    return wrap;
  };
  window.__deskCursors = {};
  for (const [n, c] of Object.entries(bots)) window.__deskCursors[n] = make(n, c);
  window.__deskMove = (name, x, y) => {
    const el = window.__deskCursors[name];
    if (!el) return;
    el.style.transform = `translate(${x}px, ${y}px) translate(-50%,-50%)`;
  };
  window.__deskDip = (name) => {
    const el = window.__deskCursors[name];
    if (!el) return;
    el.animate([{filter:'brightness(1)'},{filter:'brightness(1.6)'},{filter:'brightness(1)'}],
               {duration:180});
  };
})();
"""


class Lesson:
    """Selectors for one interaction flow, read from fomo_web.md."""

    def __init__(self, table: dict[str, Any]):
        self.table = table

    @classmethod
    def load(cls, path: str | Path) -> "Lesson":  # pragma: no cover - needs the owner's file
        text = Path(path).read_text(encoding="utf-8")
        table: dict[str, str] = {}
        for line in text.splitlines():
            m = re.match(r"^\s*([a-z_]+)\s*[:=]\s*(.+?)\s*$", line)
            if m:
                table[m.group(1)] = m.group(2)
        return cls(table)

    def need(self, *keys: str) -> dict[str, str]:
        missing = [k for k in keys if not self.table.get(k)]
        if missing:
            raise LaneBlocked(
                "fomo_web.md is missing: " + ", ".join(missing) +
                ". Paste the FOMO web lessons before a PAPER night.")
        return {k: self.table[k] for k in keys}


# ------------------------------------------------------------------ lane
class Lane:
    """Plan A: Playwright over CDP to the owner's Chrome. One order at a time."""

    def __init__(self, cfg, db, lesson: Lesson | None = None, cdp: str = "http://127.0.0.1:9222",
                 pages=None, shots_dir: str = "data/frames"):
        self.cfg, self.db, self.lesson, self.cdp = cfg, db, lesson, cdp
        self.pages = pages
        self.shots_dir = shots_dir
        self.lock = asyncio.Lock()
        self.frames_on = True
        self.last_frame: bytes | None = None
        self.holder: str | None = None

    def ready(self) -> bool:
        return self.lesson is not None and self.pages is not None

    async def _with_lock(self, coro):
        async with self.lock:
            return await coro

    async def buy(self, *, mint: str, usd: float, symbol: str, paper: bool,
                  owner: str) -> LaneResult:
        url = coin_page(mint)
        require_fomo_url(url)
        if not self.ready():
            return LaneResult("failed", "lane offline: Chrome not connected")
        return await self._with_lock(self._buy(mint, usd, symbol, paper, owner, url))

    async def _buy(self, mint, usd, symbol, paper, owner, url) -> LaneResult:
        cfg = self.cfg.group("executor")
        sel = self.lesson.need("buy_tab", "amount_field", "quote_line", "buy_button_template")
        try:
            await self.pages.open(url)
            self.holder = owner
            await self.pages.click_text(sel["buy_tab"], owner)
            typed = await self.pages.fill_amount(sel["amount_field"], f"{usd:.2f}")
            if not amount_matches(typed, usd):
                typed = await self.pages.fill_amount(sel["amount_field"], f"{usd:.2f}")
                if not amount_matches(typed, usd):
                    return LaneResult("failed", "amount mismatch")
            quote = await self.pages.quote_ready(sel["quote_line"], cfg["quote_timeout_s"])
            if not quote_ready(quote):
                await self.pages.reload()
                quote = await self.pages.quote_ready(sel["quote_line"], cfg["quote_timeout_s"])
                if not quote_ready(quote):
                    return LaneResult("failed", "no quote")
            blocked = await self.pages.needs_checkbox()
            if blocked:
                return LaneResult("skipped", "a box to tick")
            if paper:
                shot = await self.pages.screenshot(self.shots_dir, "paper-buy")
                return LaneResult("paper_done", "PAPER: stopped before the button",
                                  {"screen": True, "api": False, "chain": False},
                                  quote_text=quote, shot_path=shot, fill_usd=usd)
            label = sel["buy_button_template"].format(symbol=symbol)
            if not may_click(label, side="buy", symbol=symbol):
                return LaneResult("failed", f"button {label!r} is not on the allow-list")
            await self.pages.click_text(label, owner)
            return await self.pages.wait_end_state("Bought", cfg["verify_timeout_s"])
        finally:
            self.holder = None

    async def sell(self, *, mint: str, pct: int, symbol: str, paper: bool, owner: str,
                   price: float | None) -> LaneResult:
        if not self.ready():
            return LaneResult("failed", "lane offline: Chrome not connected")
        async def run():
            sel = self.lesson.need("sell_tab", "sell_button_template")
            await self.pages.open(coin_page(mint))
            await self.pages.click_text(sel["sell_tab"], owner)
            label = sel["sell_button_template"].format(symbol=symbol)
            if not may_click(label, side="sell", symbol=symbol):
                return LaneResult("failed", f"button {label!r} is not on the allow-list")
            if paper:
                shot = await self.pages.screenshot(self.shots_dir, "paper-sell")
                return LaneResult("paper_done", "PAPER: sell tab only", {}, price=price,
                                  shot_path=shot)
            await self.pages.click_text(label, owner)
            return await self.pages.wait_end_state("Sold", self.cfg.get("verify_timeout_s"))
        return await self._with_lock(run())

    # plan B: the process POSTs to a webhook routine, same rules, same checks
    async def post_webhook(self, payload: dict, url: str, token: str) -> LaneResult:
        import httpx
        try:
            async with httpx.AsyncClient(timeout=20) as c:
                r = await c.post(url, json=payload,
                                 headers={"Authorization": f"Bearer {token}"})
        except httpx.HTTPError as e:
            return LaneResult("failed", f"webhook: {e.__class__.__name__}")
        if r.status_code != 200:
            return LaneResult("failed", f"webhook {r.status_code}")
        return LaneResult("clicking", "webhook started, waiting for the order row")


def owner_of(order_bot: str) -> str:
    return order_bot if order_bot in BOTS else "Executor"
