"""bus.py — scanner -> analyst -> brain -> executor; risk watches positions.

One asyncio pipeline. Every hop is a queue of size 1 per stage so a slow stage never grows
memory. Risk is not in the chain: it polls positions and jumps the click lane.
"""

from __future__ import annotations

import asyncio
import logging

log = logging.getLogger("bus")


class Bus:
    def __init__(self, scanner=None, analyst=None, brain=None, executor=None, risk=None):
        self.scanner = scanner
        self.analyst = analyst
        self.brain = brain
        self.executor = executor
        self.risk = risk
        self.events: asyncio.Queue = asyncio.Queue(maxsize=500)
        self.paused: set[str] = set()
        self.lane_holder: str | None = None

    # ------------------------------------------------------------- fan-out
    async def emit(self, kind: str, payload: dict) -> None:
        try:
            self.events.put_nowait({"kind": kind, **payload})
        except asyncio.QueueFull:
            log.warning("event queue full, dropping %s", kind)

    async def to_analyst(self, scan: dict) -> None:
        await self.emit("scan", scan)
        if "scanner" in self.paused or "analyst" in self.paused:
            return
        mint = scan["mint"]
        snapshot = await self.analyst_snapshot(mint, scan)
        audit = self.analyst.audit(mint, snapshot)
        for layer in audit["layers"]:
            await self.emit("audit_layer", {"mint": mint, **layer})
        await self.emit("score", {k: v for k, v in audit.items() if k != "layers"})
        if not audit["passed"]:
            return
        await self.to_brain(mint, audit, snapshot)

    async def analyst_snapshot(self, mint: str, scan: dict) -> dict:
        """Filled from sources when the run has a network; the replay harness passes a fixture."""
        if self.analyst and getattr(self.analyst, "sources", None):
            return await self.analyst.sources.snapshot(mint, scan)
        return {"symbol": scan.get("symbol"), "holders": scan.get("holders"),
                "liquidity_usd": scan.get("liquidityUsd"), "h1_change_pct": scan.get("h1ChangePct"),
                "social": None}

    async def to_brain(self, mint: str, audit: dict, snapshot: dict) -> None:
        if "brain" in self.paused or "executor" in self.paused:
            return
        from desk import deskstate
        cash = deskstate.free_cash(self.analyst.db, self.analyst.cfg)
        trades = self.analyst.db.scalar(
            "SELECT COUNT(*) FROM orders WHERE side='buy' AND status IN ('done','paper_done') "
            "AND ts >= COALESCE((SELECT value FROM settings WHERE key='night_started_at'),'')",
            default=0)
        night_loss = self.risk.night_loss_pct() if self.risk else 0.0
        shill = (audit.get("social") is not None and audit["social"] is not None
                 and (1 - audit["social"]) >= 0.5)
        decision = await self.brain.size_for(
            mint, audit["score"], snapshot.get("liquidity_usd"), cash,
            shill_ring=bool(shill), trades_tonight=int(trades or 0),
            night_loss_pct=night_loss, symbol=snapshot.get("symbol"))
        await self.emit("size", decision)
        if decision["skip"]:
            return
        await self.emit("order", {**decision, "status": "queued"})

    # ------------------------------------------------------------- lane state
    def lane_busy(self) -> bool:
        return self.lane_holder is not None

    def hold_lane(self, who: str) -> None:
        self.lane_holder = who

    def release_lane(self) -> None:
        self.lane_holder = None
