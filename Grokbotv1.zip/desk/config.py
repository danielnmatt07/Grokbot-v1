"""config.py — settings (STEP 12) with sane min/max, plus the change log.

Settings live in SQLite (table settings) so the phone, Telegram and the bots all read one
copy. Defaults are inserted on first run. Out of range = refuse and say the range; every
accepted change is written to change_log.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Callable

log = logging.getLogger("config")


@dataclass(frozen=True)
class Spec:
    key: str
    default: Any
    kind: str          # num | int | str | bool | enum
    lo: float | None = None
    hi: float | None = None
    choices: tuple[str, ...] = ()
    group: str = "desk"
    label: str = ""
    unit: str = ""

    def coerce(self, value: Any) -> Any:
        if self.kind == "bool":
            if isinstance(value, bool):
                return value
            if isinstance(value, str) and value.lower() in ("true", "1", "on", "yes"):
                return True
            if isinstance(value, str) and value.lower() in ("false", "0", "off", "no"):
                return False
            raise ValueError(f"{self.key} must be true or false")
        if self.kind == "enum":
            v = str(value).strip()
            if v not in self.choices:
                raise ValueError(f"{self.key} must be one of {', '.join(self.choices)}")
            return v
        if self.kind == "str":
            return str(value).strip()
        try:
            n = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{self.key} must be a number") from None
        if self.kind == "int":
            if abs(n - round(n)) > 1e-9:
                raise ValueError(f"{self.key} must be a whole number")
            n = int(round(n))
        if self.lo is not None and n < self.lo:
            raise ValueError(f"{self.key} must be at least {self.fmt(self.lo)}")
        if self.hi is not None and n > self.hi:
            raise ValueError(f"{self.key} must be at most {self.fmt(self.hi)}")
        return n

    @staticmethod
    def fmt(v: float | None) -> str:
        if v is None:
            return "?"
        return str(int(v)) if float(v).is_integer() else str(round(float(v), 4))


SPECS: tuple[Spec, ...] = (
    # scanner
    Spec("min_liquidity_usd", 20000, "num", 1000, 5_000_000, group="scanner",
         label="Minimum liquidity", unit="$"),
    Spec("max_top10_pct", 25, "num", 1, 100, group="scanner", label="Max top 10", unit="%"),
    Spec("max_h1_change_pct", 200, "num", 10, 5000, group="scanner",
         label="Max 1h change", unit="%"),
    Spec("poll_s", 60, "int", 10, 600, group="scanner", label="Poll every", unit="s"),
    Spec("min_pool_age_min", 10, "num", 1, 240, group="scanner", label="Min pool age",
         unit="min"),
    Spec("max_wait_min", 60, "num", 5, 720, group="scanner", label="Drop after", unit="min"),
    Spec("runner_h24_pct", 300, "num", 50, 10000, group="scanner",
         label="Runner (24h)", unit="%"),
    Spec("min_holders_growth_pct", 0, "num", -100, 200, group="scanner",
         label="Min holders growth", unit="%"),
    # analyst
    Spec("max_dev_pct", 5, "num", 0, 50, group="analyst", label="Max dev hold", unit="%"),
    Spec("analyst_max_top10_pct", 25, "num", 1, 100, group="analyst",
         label="Max top 10", unit="%"),
    Spec("min_lp_locked_pct", 99, "num", 50, 100, group="analyst", label="Min LP burned",
         unit="%"),
    Spec("max_bundled", 5, "num", 0, 100, group="analyst", label="Max bundled wallets"),
    Spec("max_delegated_accounts", 10, "num", 0, 1000, group="analyst",
         label="Max delegate accounts"),
    Spec("retries", 3, "int", 1, 10, group="analyst", label="Source retries"),
    Spec("min_score", 70, "num", 0, 100, group="analyst", label="Min score"),
    Spec("alive_volume_h1", 25000, "num", 100, 10_000_000, group="analyst",
         label="Alive volume (1h)", unit="$"),
    Spec("fast_curve_min", 10, "num", 0, 240, group="analyst", label="Fast curve", unit="min"),
    Spec("max_fresh_pct", 50, "num", 0, 100, group="analyst", label="Max fresh wallets",
         unit="%"),
    Spec("organic_unique_h1", 80, "num", 1, 10000, group="analyst",
         label="Organic unique buyers (1h)"),
    Spec("organic_buys_h1", 150, "num", 1, 100000, group="analyst",
         label="Organic buys fallback (1h)"),
    Spec("bundled_penalty", 0.5, "num", 0, 1, group="analyst", label="Bundled penalty"),
    Spec("flush_sell_ratio", 1.5, "num", 0.1, 10, group="analyst", label="Flush sell ratio"),
    Spec("chase_h1_pct", 200, "num", 10, 5000, group="analyst", label="Chase reference",
         unit="%"),
    # social
    Spec("social_weight", 0.5, "num", 0, 3, group="social", label="Social weight"),
    Spec("social_max_per_h", 20, "int", 0, 200, group="social", label="Social checks / hour"),
    Spec("social_timeout_s", 120, "int", 10, 600, group="social", label="Social timeout",
         unit="s"),
    Spec("shill_cut", 0.5, "num", 0, 1, group="social", label="Shill ring cut"),
    # brain
    Spec("risk_per_trade_pct", 3, "num", 0.1, 20, group="brain", label="Risk per trade",
         unit="%"),
    Spec("full_size_score", 80, "num", 0, 100, group="brain", label="Full size at score"),
    Spec("below_full_pct", 50, "num", 5, 100, group="brain", label="Below full size", unit="%"),
    Spec("max_pool_pct", 2, "num", 0.1, 20, group="brain", label="Max pool share", unit="%"),
    Spec("min_ticket_usd", 2, "num", 1, 100, group="brain", label="Min ticket", unit="$"),
    Spec("max_ticket_usd", 50, "num", 2, 100000, group="brain", label="Max ticket", unit="$"),
    Spec("max_trades_night", 30, "int", 1, 500, group="brain", label="Max trades a night"),
    # executor
    Spec("dip_pct", 15, "num", 1, 90, group="executor", label="Dip entry", unit="%"),
    Spec("dip_window_min", 10, "num", 1, 60, group="executor", label="Dip window", unit="min"),
    Spec("dip_wait_min", 30, "num", 1, 240, group="executor", label="Wait for dip", unit="min"),
    Spec("crash_pct", 35, "num", 5, 95, group="executor", label="Crash cut", unit="%"),
    Spec("tp_x", 2.0, "num", 1.1, 20, group="executor", label="Take profit at", unit="×"),
    Spec("tp_sell_pct", 50, "num", 1, 100, group="executor", label="Sell at take profit",
         unit="%"),
    Spec("trail_pct", 40, "num", 5, 90, group="executor", label="Trail from peak", unit="%"),
    Spec("recheck_liq_drop_pct", 20, "num", 0, 100, group="executor",
         label="Skip if liquidity drops", unit="%"),
    Spec("recheck_price_up_pct", 15, "num", 0, 500, group="executor",
         label="Skip if price ran", unit="%"),
    Spec("quote_timeout_s", 10, "int", 2, 120, group="executor", label="Quote timeout",
         unit="s"),
    Spec("verify_timeout_s", 30, "int", 5, 300, group="executor", label="Verify timeout",
         unit="s"),
    # risk
    Spec("risk_poll_s", 5, "int", 1, 120, group="risk", label="Poll every", unit="s"),
    Spec("stop_pct", 25, "num", 1, 95, group="risk", label="Stop", unit="%"),
    Spec("timeout_h", 3, "num", 0.1, 48, group="risk", label="Dead money after", unit="h"),
    Spec("timeout_min_gain_pct", 5, "num", 0, 200, group="risk",
         label="Dead money if under", unit="%"),
    Spec("night_loss_stop_pct", 30, "num", 1, 100, group="risk",
         label="Night loss stop", unit="%"),
    # desk
    Spec("mode", "PAPER", "enum", choices=("PAPER", "LIVE"), group="desk", label="Mode"),
    Spec("paper_start_cash", 36, "num", 1, 100000, group="desk", label="PAPER start cash",
         unit="$"),
    Spec("night_start", "22:00", "str", group="desk", label="Night start"),
    Spec("lock_time", "06:30", "str", group="desk", label="Lock time"),
    Spec("report_time", "08:00", "str", group="desk", label="Report time"),
    Spec("notifier", "telegram", "enum", choices=("telegram", "webpush"), group="desk",
         label="Notifier"),
    Spec("fomo_handle", "", "str", group="desk", label="FOMO username"),
    Spec("withdraw_address", "", "str", group="desk", label="Withdraw address"),
    Spec("rpc_url", "https://api.mainnet-beta.solana.com", "str", group="desk",
         label="RPC URL"),
    Spec("push_rejects", False, "bool", group="desk", label="Push rejects"),
    Spec("fee_pct", 0.45, "num", 0, 5, group="desk", label="Fee above $190", unit="%"),
    Spec("data_path", "", "str", group="desk", label="Data path (secret)"),
    Spec("owner_chat_id", "", "str", group="desk", label="Telegram owner"),
    Spec("night_started_at", "", "str", group="desk", label="Night start (stamp)"),
    Spec("night_start_cash", 0, "num", 0, 100000000, group="desk", label="Night start cash"),
    Spec("lane_plan", "A", "enum", choices=("A", "B"), group="desk", label="Browser lane"),
)

BY_KEY: dict[str, Spec] = {s.key: s for s in SPECS}


class Settings:
    def __init__(self, db):
        self.db = db
        self._cache: dict[str, Any] = {}
        self.seeds = self._read_seeds()
        self._seed()
        self.reload()
        self._backfill()

    @staticmethod
    def _read_seeds() -> dict:
        """Owner answers collected during setup (the FOMO handle) live in seeds.json."""
        import pathlib
        p = pathlib.Path(__file__).with_name("seeds.json")
        if not p.exists():
            return {}
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return data if isinstance(data, dict) else {}

    def _seed(self) -> None:
        with self.db.tx() as cur:
            for spec in SPECS:
                value = self.seeds.get(spec.key, spec.default)
                cur.execute(
                    "INSERT OR IGNORE INTO settings (key, value, updated_at) "
                    "VALUES (?, ?, strftime('%Y-%m-%dT%H:%M:%fZ','now'))",
                    (spec.key, json.dumps(value)),
                )

    def _backfill(self) -> None:
        """A seed fills an empty setting once; the owner's later edits always win."""
        for key, value in self.seeds.items():
            if key in BY_KEY and not self.get(key):
                with self.db.tx() as cur:
                    cur.execute("UPDATE settings SET value=? WHERE key=?",
                                (json.dumps(value), key))
                self._cache[key] = value

    def reload(self) -> None:
        rows = self.db.q("SELECT key, value FROM settings")
        self._cache = {}
        for row in rows:
            key, raw = row["key"], row["value"]
            spec = BY_KEY.get(key)
            try:
                value = json.loads(raw)
            except (TypeError, ValueError):
                value = raw
            if spec is None:
                self._cache[key] = value
                continue
            try:
                self._cache[key] = spec.coerce(value)
            except ValueError:
                log.warning("setting %s has invalid stored value %r, using default", key, raw)
                self._cache[key] = spec.default

    def get(self, key: str, default: Any = None) -> Any:
        if key in self._cache:
            return self._cache[key]
        spec = BY_KEY.get(key)
        return spec.default if spec is not None else default

    def __getitem__(self, key: str) -> Any:
        return self.get(key)

    def group(self, name: str) -> dict[str, Any]:
        return {s.key: self.get(s.key) for s in SPECS if s.group == name}

    def all(self) -> dict[str, Any]:
        return dict(self._cache)

    def set(self, key: str, value: Any, who: str = "owner") -> dict:
        spec = BY_KEY.get(key)
        if spec is None:
            raise KeyError(f"unknown setting {key}")
        clean = spec.coerce(value)
        old = self.get(key)
        with self.db.tx() as cur:
            cur.execute(
                "UPDATE settings SET value=?, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') "
                "WHERE key=?",
                (json.dumps(clean), key),
            )
            cur.execute(
                "INSERT INTO change_log (ts, key, old, new, who) "
                "VALUES (strftime('%Y-%m-%dT%H:%M:%fZ','now'), ?, ?, ?, ?)",
                (key, json.dumps(old), json.dumps(clean), who),
            )
        self._cache[key] = clean
        log.info("setting %s: %r -> %r by %s", key, old, clean, who)
        return {"key": key, "old": old, "new": clean, "label": spec.label}

    def human(self, key: str) -> str:
        spec = BY_KEY.get(key)
        if spec is None:
            return key
        return f"{spec.label}: {self.get(key)}{spec.unit}"


def describe() -> list[dict]:
    out = []
    for s in SPECS:
        if s.key in ("data_path", "owner_chat_id", "night_started_at", "night_start_cash"):
            continue
        out.append({
            "key": s.key, "group": s.group, "label": s.label, "kind": s.kind,
            "default": s.default, "min": s.lo, "max": s.hi, "unit": s.unit,
            "choices": list(s.choices),
        })
    return out


def parse_set_command(text: str) -> tuple[str, str] | None:
    """'set stop to -20%' -> ('stop_pct', '-20'). Returns None if it is not a set command."""
    t = (text or "").strip().lower()
    if not t.startswith("set ") or " to " not in t:
        return None
    body = t[4:]
    name, _, raw = body.partition(" to ")
    key = alias(name.strip())
    if key is None:
        return None
    return key, raw.strip().rstrip("%").strip()


def alias(name: str) -> str | None:
    n = name.strip().lower().replace("-", " ").replace("_", " ")
    table = {
        "stop": "stop_pct", "stop loss": "stop_pct", "stop loss pct": "stop_pct",
        "trail": "trail_pct", "take profit": "tp_x", "tp": "tp_x",
        "max ticket": "max_ticket_usd", "ticket": "max_ticket_usd",
        "min ticket": "min_ticket_usd", "dip": "dip_pct", "dip pct": "dip_pct",
        "night loss": "night_loss_stop_pct", "night loss stop": "night_loss_stop_pct",
        "min score": "min_score", "risk per trade": "risk_per_trade_pct",
        "full size score": "full_size_score", "max trades": "max_trades_night",
        "social weight": "social_weight", "reward": None,
    }
    if n in table:
        return table[n]
    direct = n.replace(" ", "_")
    for spec in SPECS:
        if spec.key == direct:
            return spec.key
        if spec.label.lower() == name.strip().lower():
            return spec.key
    return None
