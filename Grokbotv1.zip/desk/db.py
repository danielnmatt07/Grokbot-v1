"""db.py — SQLite schema (STEP 5), WAL, one writer connection per process.

All timestamps are UTC ISO-8601 with milliseconds. money is USD floats rounded to cents
at the edges (never accumulate floats blindly; values are computed and rounded per row).
"""

from __future__ import annotations

import logging
import os
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Iterable

log = logging.getLogger("db")

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS coins (
  mint TEXT PRIMARY KEY, name TEXT, symbol TEXT, pool TEXT, created_at TEXT,
  migrated_at TEXT, curve_min REAL, creator TEXT, creator_balance_at_migration REAL,
  holders INTEGER
);

CREATE TABLE IF NOT EXISTS scans (
  id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT, ts TEXT, liquidity_usd REAL,
  top10_pct REAL, h1_change_pct REAL, age_min REAL, liq_mcap REAL, accel REAL,
  holders_growth REAL, verdict TEXT, reason TEXT
);
CREATE INDEX IF NOT EXISTS scans_mint ON scans(mint);

CREATE TABLE IF NOT EXISTS audits (
  id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT, ts TEXT, layer INTEGER, name TEXT,
  value_text TEXT, pass INTEGER, source TEXT
);
CREATE INDEX IF NOT EXISTS audits_mint ON audits(mint);

CREATE TABLE IF NOT EXISTS scores (
  id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT, ts TEXT, alive REAL, organic REAL,
  flush REAL, chase REAL, social REAL, social_pts REAL, fresh_pct REAL, score REAL,
  pass INTEGER, reason TEXT
);
CREATE INDEX IF NOT EXISTS scores_mint ON scores(mint);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, mint TEXT, side TEXT, usd REAL, pct REAL,
  bot TEXT, reason TEXT, status TEXT, quote_text TEXT, fee_text TEXT, screen_ok INTEGER,
  api_ok INTEGER, chain_ok INTEGER, fill_usd REAL, error TEXT, shot_path TEXT
);
CREATE INDEX IF NOT EXISTS orders_mint ON orders(mint);

CREATE TABLE IF NOT EXISTS positions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, mint TEXT, opened_at TEXT, entry_price REAL,
  size_usd REAL, tokens REAL, peak_price REAL, stop_price REAL, tp_done INTEGER,
  trail_active INTEGER, closed_at TEXT, exit_price REAL, exit_reason TEXT,
  pnl_usd REAL, fees_usd REAL, mode TEXT
);
CREATE INDEX IF NOT EXISTS positions_open ON positions(mint, closed_at);

CREATE TABLE IF NOT EXISTS activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, kind TEXT, mint TEXT, bot TEXT,
  title TEXT, subtitle TEXT, value TEXT
);

CREATE TABLE IF NOT EXISTS prices (
  mint TEXT, ts TEXT, price REAL, volume_m5 REAL, holders INTEGER
);
CREATE INDEX IF NOT EXISTS prices_mint_ts ON prices(mint, ts);

CREATE TABLE IF NOT EXISTS balance (ts TEXT, value REAL);

CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT, updated_at TEXT);

CREATE TABLE IF NOT EXISTS rugs (mint TEXT PRIMARY KEY, ts TEXT, pulled_usd REAL);

CREATE TABLE IF NOT EXISTS change_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, key TEXT, old TEXT, new TEXT, who TEXT
);

CREATE TABLE IF NOT EXISTS heartbeats (bot TEXT PRIMARY KEY, ts TEXT);

CREATE TABLE IF NOT EXISTS push_subs (
  endpoint TEXT PRIMARY KEY, p256dh TEXT, auth TEXT
);

CREATE TABLE IF NOT EXISTS waiting (
  mint TEXT PRIMARY KEY, first_seen TEXT, migrated_at TEXT, pool TEXT, creator TEXT,
  name TEXT, symbol TEXT, curve_min REAL, state TEXT, passed_at TEXT, kill_reason TEXT,
  last_check TEXT
);

CREATE TABLE IF NOT EXISTS decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, bot TEXT, mint TEXT, data TEXT
);
CREATE INDEX IF NOT EXISTS decisions_bot ON decisions(bot, id DESC);

CREATE TABLE IF NOT EXISTS swaps_seen (
  sig TEXT PRIMARY KEY, ts TEXT, mint TEXT, side TEXT, usd REAL
);
"""


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + \
        f"{datetime.now(timezone.utc).microsecond // 1000:03d}Z"


def parse_ts(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.strptime(value.replace("Z", "+0000"), "%Y-%m-%dT%H:%M:%S.%f%z")
    except ValueError:
        try:
            return datetime.strptime(value.replace("Z", "+0000"), "%Y-%m-%dT%H:%M:%S%z")
        except ValueError:
            return None


def age_min(value: str | None) -> float | None:
    t = parse_ts(value)
    if t is None:
        return None
    return round((datetime.now(timezone.utc) - t).total_seconds() / 60.0, 3)


class DB:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.conn.executescript(SCHEMA)

    @contextmanager
    def tx(self):
        with self.lock:
            cur = self.conn.cursor()
            try:
                cur.execute("BEGIN IMMEDIATE")
                yield cur
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
            finally:
                cur.close()

    def q(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        with self.lock:
            cur = self.conn.execute(sql, tuple(params))
            rows = cur.fetchall()
            cur.close()
            return rows

    def one(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        rows = self.q(sql, params)
        return rows[0] if rows else None

    def scalar(self, sql: str, params: Iterable[Any] = (), default: Any = None) -> Any:
        row = self.one(sql, params)
        if row is None:
            return default
        return row[0] if row[0] is not None else default

    def exec(self, sql: str, params: Iterable[Any] = ()) -> int:
        with self.tx() as cur:
            cur.execute(sql, tuple(params))
            return cur.rowcount

    # ---- small helpers used by many modules
    def beat(self, bot: str) -> None:
        self.exec(
            "INSERT INTO heartbeats (bot, ts) VALUES (?, ?) "
            "ON CONFLICT(bot) DO UPDATE SET ts=excluded.ts",
            (bot, now()),
        )

    def heartbeat_age(self, bot: str) -> float | None:
        ts = self.scalar("SELECT ts FROM heartbeats WHERE bot=?", (bot,))
        a = age_min(ts) if ts else None
        return None if a is None else a * 60.0

    def log_activity(self, kind: str, mint: str | None, bot: str, title: str,
                     subtitle: str, value: str) -> int:
        return self.exec(
            "INSERT INTO activity (ts, kind, mint, bot, title, subtitle, value) "
            "VALUES (?,?,?,?,?,?,?)",
            (now(), kind, mint, bot, title, subtitle, value),
        )

    def decide(self, bot: str, mint: str, data: dict) -> None:
        import json
        self.exec("INSERT INTO decisions (ts, bot, mint, data) VALUES (?,?,?,?)",
                  (now(), bot, mint, json.dumps(data, default=str)))

    def close(self) -> None:
        with self.lock:
            self.conn.close()
