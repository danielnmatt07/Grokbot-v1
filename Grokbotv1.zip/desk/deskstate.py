"""deskstate.py — the small shared writers other modules call.

Keeps money maths in one place so PAPER and LIVE differ only in where prices come from.
"""

from __future__ import annotations

import logging

from desk import fees as feemod
from desk.db import now

log = logging.getLogger("deskstate")


def free_cash(db, cfg) -> float:
    if cfg.get("mode") == "PAPER":
        start = float(cfg.get("paper_start_cash") or 36)
        realised = db.scalar(
            "SELECT COALESCE(SUM(pnl_usd),0) FROM positions WHERE closed_at IS NOT NULL", default=0)
        committed = db.scalar(
            "SELECT COALESCE(SUM(size_usd),0) FROM positions WHERE closed_at IS NULL", default=0)
        waiting = db.scalar(
            "SELECT COALESCE(SUM(usd),0) FROM orders WHERE side='buy' AND status IN "
            "('queued','clicking')", default=0)
        return round(max(0.0, start + realised - committed - waiting), 2)
    row = db.scalar("SELECT value FROM balance ORDER BY rowid DESC LIMIT 1", default=None)
    return float(row or 0)


def night_start_cash(db, cfg) -> float:
    return float(cfg.get("night_start_cash") or 0) or free_cash(db, cfg)


def open_position(db, cfg, mint: str, symbol: str | None, result: dict, usd: float,
                  paper: bool) -> int | None:
    if db.one("SELECT id FROM positions WHERE mint=? AND closed_at IS NULL", (mint,)):
        log.warning("refusing a 2nd position on %s", mint)
        return None
    fill = float(result.get("fill_usd") or usd)
    tokens = result.get("tokens")
    price = result.get("price") or result.get("entry_price")
    if not price and fill:
        price = fill
    entry = round(float(price or 0), 12)
    if not tokens and entry:
        tokens = round(fill / entry, 6)
    fee = feemod.side_fee(fill, cfg.get("fee_pct", 0.45))
    pid = db.exec(
        "INSERT INTO positions (mint, opened_at, entry_price, size_usd, tokens, peak_price,"
        " stop_price, tp_done, trail_active, mode) VALUES (?,?,?,?,?,?,?,0,0,?)",
        (mint, now(), entry, fill, tokens, entry,
         round(entry * (1 - chain_stop(cfg) / 100.0), 12), cfg.get("mode")),
    )
    db.log_activity("bought", mint, "Executor", f"Bought {symbol or mint[:6]}",
                    f"Executor · {now()[11:16]}", f"${fill:,.2f}")
    db.exec("INSERT INTO balance (ts, value) VALUES (?, ?)", (now(), free_cash(db, cfg)))
    log.info("position %s %s entry %.12g size %.2f fee %.2f", pid, mint, entry, fill, fee)
    return pid


def chain_stop(cfg) -> float:
    return float(cfg.get("stop_pct") or 25)


def close_position(db, cfg, mint: str, symbol: str | None, result: dict, pct: int,
                   reason: str, paper: bool) -> float | None:
    pos = db.one("SELECT * FROM positions WHERE mint=? AND closed_at IS NULL ORDER BY id DESC",
                 (mint,))
    if not pos:
        return None
    exit_price = result.get("price") or result.get("fill_price")
    if not exit_price:
        return None
    portion = pct / 100.0
    tokens_out = (pos["tokens"] or 0) * portion
    gross_in = (pos["size_usd"] or 0) * portion
    gross_out = tokens_out * float(exit_price)
    fees = feemod.side_fee(gross_out, cfg.get("fee_pct", 0.45))
    pnl = round(gross_out - gross_in - fees, 4)

    if pct >= 100:
        db.exec(
            "UPDATE positions SET closed_at=?, exit_price=?, exit_reason=?, pnl_usd=?, "
            "fees_usd=? WHERE id=?",
            (now(), float(exit_price), reason, pnl, fees, pos["id"]),
        )
    else:
        left = 1 - portion
        db.exec(
            "UPDATE positions SET size_usd=?, tokens=?, tp_done=1, trail_active=1, "
            "fees_usd=COALESCE(fees_usd,0)+? WHERE id=?",
            (round(gross_in * left, 4), round((pos["tokens"] or 0) * left, 6), fees, pos["id"]),
        )
    pct_move = (float(exit_price) / pos["entry_price"] - 1) * 100 if pos["entry_price"] else 0
    verb = "Stopped" if reason in ("stop", "pulled", "dev dumping", "FOMO warns", "no price") \
        else "Sold"
    db.log_activity(verb.lower(), mint, "Risk" if verb == "Stopped" else "Executor",
                    f"{verb} {symbol or mint[:6]}",
                    f"{'Risk · ' + reason if verb == 'Stopped' else 'Executor · ' + reason}",
                    f"{pnl:+,.2f}")
    db.exec("INSERT INTO balance (ts, value) VALUES (?, ?)", (now(), free_cash(db, cfg)))
    return pnl
