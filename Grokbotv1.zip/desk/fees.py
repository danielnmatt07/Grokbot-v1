"""fees.py — FOMO fee model for PAPER (STEP 13).

FOMO on Solana, per side, lowest-fee route:
  under $5            -> $0.10
  $5 to $47.50        -> 2%
  $47.50 to $190      -> $0.95
  above $190          -> settings.fee_pct (0.45%)
Other routes take 0.50% with a $0.95 minimum, so PAPER is a bit kind.
FOMO pays the Solana gas. LIVE uses the fee row FOMO shows on the quote.
"""

from __future__ import annotations

EPS = 1e-9


def side_fee(usd: float, fee_pct: float = 0.45) -> float:
    usd = float(usd)
    if usd < 5 - EPS:
        return 0.10
    if usd < 47.50 - EPS:
        return round(usd * 0.02, 4)
    if usd <= 190 + EPS:
        return 0.95
    return round(usd * fee_pct / 100.0, 4)


def round_trip(usd: float, fee_pct: float = 0.45) -> float:
    return round(side_fee(usd, fee_pct) + side_fee(usd, fee_pct), 4)


def paper_pnl(entry_usd: float, exit_usd: float, fee_pct: float = 0.45) -> dict:
    """Gross and net result of a PAPER round trip."""
    fees = round_trip(entry_usd, fee_pct)
    gross = round(exit_usd - entry_usd, 4)
    return {"gross_usd": gross, "fees_usd": fees, "pnl_usd": round(gross - fees, 4)}
