"""fields.py — raw key mapping (STEP 3).

The bots read only through this mapping. A key that is not in the raw JSON stays null and
the reason is logged. Every mapping below was written from the documented shape of the
response; `unverified()` marks keys that must be confirmed against a real raw sample before
a LIVE night (STEP 3 shows the table to the owner).
"""

from __future__ import annotations

from typing import Any


def pick(raw: Any, path: str, default: Any = None) -> Any:
    """Dotted path lookup that tolerates missing keys and list indices."""
    cur = raw
    for part in path.split("."):
        if cur is None:
            return default
        if isinstance(cur, list):
            try:
                cur = cur[int(part)]
                continue
            except (ValueError, IndexError):
                return default
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return default if cur is None else cur


def num(raw: Any, path: str) -> float | None:
    v = pick(raw, path)
    if isinstance(v, bool) or v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------- DexScreener
# GET https://api.dexscreener.com/tokens/v1/solana/{mints} -> list of pairs
DEX = {
    "price_usd": "priceUsd",
    "price_native": "priceNative",
    "liquidity_usd": "liquidity.usd",
    "fdv": "fdv",
    "market_cap": "marketCap",
    "volume_m5": "volume.m5",
    "volume_h1": "volume.h1",
    "volume_h24": "volume.h24",
    "change_m5": "priceChange.m5",
    "change_h1": "priceChange.h1",
    "change_h24": "priceChange.h24",
    "txns_m5_buys": "txns.m5.buys",
    "txns_m5_sells": "txns.m5.sells",
    "txns_h1_buys": "txns.h1.buys",
    "txns_h1_sells": "txns.h1.sells",
    "pair_created_at": "pairCreatedAt",     # epoch ms
    "base_address": "baseToken.address",
    "base_symbol": "baseToken.symbol",
    "base_name": "baseToken.name",
    "dex_id": "dexId",
    "pair_address": "pairAddress",
    "twitter": "info.socials.0.url",
}


def dexscreener_pair(pairs: list, pools: set[str] | None = None) -> dict | None:
    """The pumpswap pair with the most liquidity (falls back to the best pair)."""
    if not pairs:
        return None
    pools = pools or set()
    cand = [p for p in pairs if p.get("dexId") == "pumpswap"] or list(pairs)
    if pools:
        named = [p for p in cand if p.get("pairAddress") in pools]
        cand = named or cand
    return max(cand, key=lambda p: (p.get("liquidity") or {}).get("usd") or 0)


# ---------------------------------------------------------------- RugCheck
# GET https://api.rugcheck.xyz/v1/tokens/{mint}/report
RUG = {
    "mint_authority": "token.mintAuthority",
    "freeze_authority": "token.freezeAuthority",
    "supply": "token.supply",
    "creator": "creator",
    "creator_balance": "creatorBalance",
    "detected_at": "detectedAt",
    "creator_tokens": "creatorTokens",
    "top_holders": "topHolders",
    "total_holders": "totalHolders",
    "insider_networks": "insiderNetworks",
    "markets": "markets",
    "risks": "risks",
    "score_normalised": "score_normalised",
}

# GET https://api.rugcheck.xyz/v1/tokens/{mint}/insiders/graph
RUG_GRAPH = {"nodes": "nodes", "edges": "edges", "node_id": "id", "edge_from": "from",
             "edge_to": "to", "current_holding": "currentHolding"}


def market_for_pool(report: dict, pool: str) -> dict | None:
    for m in report.get("markets") or []:
        if (m.get("pubkey") == pool or m.get("pool") == pool
                or (m.get("market") or {}).get("pubkey") == pool):
            return m
    if pool:
        return None
    markets = report.get("markets") or []
    return markets[0] if markets else None


def lp_locked_pct(market: dict | None) -> float | None:
    if not market:
        return None
    for key in ("lp", "liquidity"):
        block = market.get(key)
        if isinstance(block, dict) and "lpLockedPct" in block:
            return num(block, "lpLockedPct")
    if "lpLockedPct" in market:
        return num(market, "lpLockedPct")
    locked = num(market, "lp.lpLockedPct")
    return locked


# ---------------------------------------------------------------- FOMO API
FOMO = {
    "user_id": "id",
    "handle": "handle",
    "solana_address": "solanaAddress",
    "swaps": "swaps",
    "swap_id": "id",
    "swap_mint": "tokenAddress",
    "swap_side": "side",
    "swap_usd": "valueUsd",
    "swap_ts": "createdAt",
    "balances_cash": "cash",
    "balances_positions": "positions",
    "token_details": "token",
    "unique_buys_5m": "token.uniqueBuys5m",
    "unique_sells_5m": "token.uniqueSells5m",
    "unique_buys_1h": "token.uniqueBuys1",
    "unique_sells_1h": "token.uniqueSells1",
    "holders": "token.holders",
    "top10_pct": "token.top10HoldersPercent",
    "filter_tokens": "tokens",
    "warnings": "warnings",
    "disable_buying": "disableBuying",
    "disable_selling": "disableSelling",
    "holders_top": "holders",
    "holder_user_id": "id",
    "holder_twitter": "twitter",
}

QUOTE_ASSETS = {"USDC", "USDT", "SOL", "WSOL", "WETH"}


def swap_side(swap: dict) -> str | None:
    """Its side key if there is one. Else into USDC/USDT/SOL/WETH is a sell, out is a buy."""
    side = (pick(swap, "side") or "") or ""
    s = str(side).lower()
    if s in ("buy", "sell"):
        return s
    if s in ("in", "out"):
        # FOMO reports the side of the user's token leg
        return "sell" if s == "in" else "buy"
    to_sym = str(pick(swap, "toToken.symbol") or pick(swap, "to.symbol") or "").upper()
    from_sym = str(pick(swap, "fromToken.symbol") or pick(swap, "from.symbol") or "").upper()
    if to_sym in QUOTE_ASSETS and from_sym not in QUOTE_ASSETS:
        return "sell"
    if from_sym in QUOTE_ASSETS and to_sym not in QUOTE_ASSETS:
        return "buy"
    return None


# ---------------------------------------------------------------- RPC
RPC = {
    "value": "result.value",
    "amount": "result.value.amount",
    "decimals": "result.value.decimals",
    "ui_amount": "result.value.uiAmount",
    "mint_authority": "result.value.data.parsed.info.mintAuthority",
    "freeze_authority": "result.value.data.parsed.info.freezeAuthority",
    "supply": "result.value.data.parsed.info.supply",
    "token_accounts": "result.value",
    "sol_lamports": "result.value",
}

# ---------------------------------------------------------------- PumpPortal
PUMPPORTAL = {"mint": "mint", "pool": "pool", "tx": "signature", "name": "name",
              "symbol": "symbol", "trader": "traderPublicKey", "method": "txType"}


def map_dex(pair: dict) -> dict:
    return {k: pick(pair, path) for k, path in DEX.items()}


UNVERIFIED = {
    "FOMO": ["swap_side (side key spelling)", "valueUsd (name of the $ key)",
             "solanaAddress (may be nested under wallets)"],
    "RugCheck": ["markets[].lp.lpLockedPct (nested under liquidity on some reports)",
                 "insiderNetworks (absent on many tokens)"],
    "PumpPortal": ["pool (absent on some migration messages; falls back to DexScreener)"],
}
