"""fomo_api.py — read-only FOMO calls + token refresh (STEP 3).

Unofficial API, can break any day. The bearer token is read from the desk Chrome's own
requests over CDP and never stored, printed or logged: it lives in memory only. One queue,
max 1 call per 1.2 s in total, 429 doubles the gap up to 20 s and backs down on success.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any

import httpx

from desk import fields

log = logging.getLogger("fomo_api")

BASE = "https://prod-api.fomo.family"
TOKEN_TTL_S = 60 * 60


class RateLimiter:
    def __init__(self, gap_s: float = 1.2, max_gap_s: float = 20.0):
        self.gap = gap_s
        self.base = gap_s
        self.max_gap = max_gap_s
        self._last = 0.0
        self._lock = asyncio.Lock()

    async def wait(self) -> None:
        async with self._lock:
            now = time.monotonic()
            delay = self.gap - (now - self._last)
            if delay > 0:
                await asyncio.sleep(delay)
            self._last = time.monotonic()

    def ok(self) -> None:
        if self.gap > self.base:
            self.gap = max(self.base, self.gap * 0.85)

    def throttled(self) -> None:
        self.gap = min(self.max_gap, self.gap * 2)


class Priority:
    VERIFY = 0
    EXECUTOR = 1
    ANALYST = 2
    SCANNER = 3


class FomoAPI:
    def __init__(self, token_source=None, client: httpx.AsyncClient | None = None):
        self.token_source = token_source      # callable -> bearer str, from CDP
        self.client = client
        self.limiter = RateLimiter()
        self._token: str | None = None
        self._token_at = 0.0
        self._queue: asyncio.Queue = asyncio.Queue()
        self.calls = 0
        self.raw_dir = "logs/raw"

    # ------------------------------------------------------------- token
    def _bearer(self) -> str:
        now = time.monotonic()
        if self._token is None or now - self._token_at > TOKEN_TTL_S - 300:
            if self.token_source is None:
                raise RuntimeError("no token source: connect the desk Chrome first")
            token = self.token_source()
            if not token:
                raise RuntimeError("no bearer token in the desk Chrome yet")
            self._token = token
            self._token_at = now
        return self._token

    def invalidate(self) -> None:
        self._token = None

    def __repr__(self) -> str:      # keep the token out of every repr/print
        return f"FomoAPI(calls={self.calls}, throttled_gap={self.limiter.gap:.2f}s)"

    # ------------------------------------------------------------- calls
    async def call(self, method: str, path: str, *, body: dict | None = None,
                   priority: int = Priority.ANALYST) -> Any:
        self._queue.put_nowait((priority, method, path, body))
        while True:
            item = await self._queue.get()
            if item[0] == priority and item[2] == path:
                break
            self._queue.put_nowait(item)
            await asyncio.sleep(0.05)
        return await self._execute(method, path, body, retry=True)

    async def _execute(self, method: str, path: str, body: dict | None, retry: bool) -> Any:
        await self.limiter.wait()
        url = BASE + path
        headers = {"Authorization": f"Bearer {self._bearer()}", "Accept": "application/json"}
        client = self.client or httpx.AsyncClient(timeout=15)
        try:
            r = await client.request(method, url, json=body, headers=headers)
        finally:
            if self.client is None:
                await client.aclose()
        self.calls += 1
        if r.status_code == 429:
            self.limiter.throttled()
            if retry:
                return await self._execute(method, path, body, False)
            raise RuntimeError("FOMO 429 again")
        if r.status_code == 401:
            self.invalidate()
            if retry:
                return await self._execute(method, path, body, False)
            raise RuntimeError("FOMO 401: session lost")
        self.limiter.ok()
        r.raise_for_status()
        data = r.json()
        self._save_raw(path, data)
        return data

    def _save_raw(self, path: str, data: Any) -> None:  # pragma: no cover - disk side effect
        import os
        try:
            os.makedirs(self.raw_dir, exist_ok=True)
            name = path.strip("/").replace("/", "_").replace("?", "_")[:80]
            with open(os.path.join(self.raw_dir, f"fomo_{name}.json"), "w", encoding="utf-8") as f:
                json.dump(data, f, indent=1)
        except OSError as e:
            log.warning("could not save raw %s: %s", path, e)

    # ------------------------------------------------------------- endpoints
    async def user(self, handle: str) -> dict:
        return await self.call("GET", f"/v2/users/userHandle/{handle.lstrip('@')}")

    async def swaps(self, user_id: str, limit: int = 25) -> list:
        return fields.pick(await self.call("GET", f"/v2/users/{user_id}/swaps"), "swaps", []) or []

    async def balances(self, user_id: str) -> dict:
        return await self.call("GET", f"/v2/users/{user_id}/balances")

    async def leaderboard(self, window: str = "30d") -> list:
        return await self.call("GET", f"/v2/leaderboard/{window}") or []

    async def filter_tokens(self, mints: list[str]) -> list:
        body = [f"{m}:1399811149" for m in mints[:20]]
        return fields.pick(await self.call("POST", "/proxy/filterTokens", body=body), "tokens", []) or []

    async def token_details(self, mint: str) -> dict:
        return await self.call("POST", "/proxy/tokenDetails", body={"tokenAddress": mint,
                                                                    "chainId": 1399811149})

    async def holders_top(self, mints: list[str]) -> list:
        return await self.call("GET", f"/hodlers/top?tokens=[{','.join(mints[:20])}]") or []

    async def token_warnings(self, mint: str) -> dict:
        return await self.call("POST", "/proxy/tokenWarnings", body={"tokenAddress": mint,
                                                                     "chainId": 1399811149})
