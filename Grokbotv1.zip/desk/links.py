"""links.py — THE ONLY place FOMO URLs are built (STEP 7).

Every FOMO link the desk produces (browser lane, app buttons, pushes, activity rows,
coin/audit screens, account tab, copy picks, reports, Telegram replies) must come from
here. Nothing anywhere else may format a fomo.family URL.
"""

from __future__ import annotations

import logging

log = logging.getLogger("links")

CHAIN_ID = {"solana": 1399811149, "robinhood": 4663, "base": 8453, "bnb": 56}
SIGNUP_URL = "https://fomo.family/r/savipww"
COIN_PREFIX = "https://fomo.family/coin?"
COIN_PARAMS = ("&chainId=", "&r=savipww", "&source=share_link")


def coin_url(address: str, chain: str = "solana") -> str:
    if chain not in CHAIN_ID:
        log.warning("unknown chain %r for mint %r, returning signup url", chain, address)
        return SIGNUP_URL
    return (
        f"https://fomo.family/coin?address={address}&chainId={CHAIN_ID[chain]}"
        f"&r=savipww&source=share_link"
    )


def profile_url(handle: str) -> str:
    h = (handle or "").lstrip("@")
    return f"https://fomo.family/profile/{h}?source=share_link&r=savipww"


def is_fomo_url(url: str) -> bool:
    return isinstance(url, str) and url.startswith("https://fomo.family/")


def link_line(text: str, url: str) -> str:
    """A channel without buttons gets the full URL as a line."""
    return f"{text}\n{url}"
