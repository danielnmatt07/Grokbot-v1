"""main.py — one event loop: bots + browser lane + API + Telegram polling.

Run: python -m desk.main --serve        (serves web/ and /api on 127.0.0.1:8787)
     python -m desk.main --serve --lan  (also bind 0.0.0.0 for the phone, still APP_TOKEN gated)
     python -m desk.main --selftest     (no network: fixtures + a PAPER replay, then exit)
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from desk import config as cfgmod
from desk import deskstate, links
from desk.bus import Bus
from desk.db import DB, now, parse_ts

LOG_DIR = Path("logs")


def setup_logging(level: str = "INFO") -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)-10s %(message)s")
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    for h in list(root.handlers):
        root.removeHandler(h)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    root.addHandler(sh)
    fh = logging.FileHandler(LOG_DIR / "desk.log", encoding="utf-8")
    fh.setFormatter(fmt)
    root.addHandler(fh)


class Desk:
    """Holds the pieces and answers the API's questions. No business rules live here."""

    def __init__(self, db_path: str = "data/desk.db", selftest: bool = False,
                 paper: bool = True):
        from desk.bots.analyst import Analyst
        from desk.bots.brain import Brain
        from desk.bots.executor import Executor
        from desk.bots.risk import Risk
        from desk.bots.scanner import Scanner
        from desk.browser import Lane
        from desk.market import Market
        from desk.social import Social
        from desk.telegram import Telegram

        self.db = DB(db_path)
        self.cfg = cfgmod.Settings(self.db)
        self.selftest = selftest
        self.paused: set[str] = set()
        self.lane_status = "Idle"
        self.lane_color = None
        self.screen_mint: str | None = None

        self.market = Market(self.cfg, self.db, paper=selftest)
        self.bus = Bus()
        self.scanner = Scanner(self.bus, self.cfg, self.db, self.market, selftest=selftest)
        self.analyst = Analyst(self.bus, self.cfg, self.db, sources=None)
        self.brain = Brain(self.bus, self.cfg, self.db)
        self.lane = Lane(self.cfg, self.db, lesson=None,
                         pages=None if selftest else None)
        self.executor = Executor(self.bus, self.cfg, self.db, lane=self.lane,
                                 market=self.market)
        self.risk = Risk(self.bus, self.cfg, self.db, self.executor, self.market)
        self.social = Social(self.cfg, self.db,
                             webhook_url=os.environ.get("SOCIAL_WEBHOOK_URL", ""),
                             webhook_token=os.environ.get("SOCIAL_WEBHOOK_TOKEN", ""),
                             plan=os.environ.get("SOCIAL_PLAN", "C"))
        self.notify = Telegram(self.cfg, self.db, os.environ.get("TELEGRAM_BOT_TOKEN", ""))

        self.bus.scanner = self.scanner
        self.bus.analyst = self.analyst
        self.bus.brain = self.brain
        self.bus.executor = self.executor
        self.bus.risk = self.risk
        self._wire_commands()
        self._seed_balance()

    # ---------------------------------------------------------------- start state
    def _seed_balance(self) -> None:
        if self.db.scalar("SELECT COUNT(*) FROM balance", default=0) == 0:
            start = deskstate.free_cash(self.db, self.cfg)
            self.db.exec("INSERT INTO balance (ts, value) VALUES (?,?)", (now(), start))
        if not self.cfg.get("night_started_at"):
            self.cfg.set("night_started_at", now(), who="desk")
            self.cfg.set("night_start_cash", deskstate.free_cash(self.db, self.cfg), who="desk")

    def live_allowed(self) -> tuple[bool, str]:
        nights = self.db.scalar(
            "SELECT COUNT(DISTINCT substr(ts,1,10)) FROM orders WHERE status IN "
            "('done','paper_done')", default=0)
        if not nights:
            return False, "one full PAPER night is required before LIVE"
        if os.environ.get("LIVE_GATE_OK") != "1":
            return False, "STEP 15 acceptance has not been passed for this machine"
        return True, ""

    # ---------------------------------------------------------------- payloads
    def state_payload(self) -> dict:
        cash = deskstate.free_cash(self.db, self.cfg)
        start = float(self.cfg.get("night_start_cash") or cash)
        positions = [dict(r) for r in self.db.q(
            "SELECT * FROM positions WHERE closed_at IS NULL ORDER BY id DESC")]
        last_order = self.db.one("SELECT * FROM orders ORDER BY id DESC LIMIT 1")
        act = [dict(r) for r in self.db.q(
            "SELECT * FROM activity ORDER BY id DESC LIMIT 5")]
        return {
            "ts": now(),
            "balance": cash,
            "night_start_cash": start,
            "mode": self.cfg.get("mode"),
            "positions": positions,
            "bots": self.bot_cards(),
            "lane": self.lane_status,
            "lane_color": self.lane_color,
            "screen_mint": self.screen_mint,
            "signup_url": links.SIGNUP_URL,
            "profile_url": links.profile_url(self.cfg.get("fomo_handle") or "you"),
            "coin_links": {p["mint"]: links.coin_url(p["mint"]) for p in positions},
            "last_order": self._last_order(last_order),
            "activity": act,
        }

    def _last_order(self, row) -> dict | None:
        if not row:
            return None
        coin = self.db.one("SELECT symbol FROM coins WHERE mint=?", (row["mint"],))
        return {
            "side": row["side"], "usd": row["usd"], "status": row["status"],
            "symbol": (coin or {})["symbol"] if coin else None,
            "checks": {"screen": bool(row["screen_ok"]), "api": bool(row["api_ok"]),
                       "chain": bool(row["chain_ok"])},
            "ts": row["ts"],
        }

    def bot_cards(self) -> list[dict]:
        s = dict(self.cfg.group("scanner"))
        trades = self.db.scalar(
            "SELECT COUNT(*) FROM orders WHERE side='buy' AND status IN ('done','paper_done')",
            default=0)
        open_pos = self.db.q("SELECT * FROM positions WHERE closed_at IS NULL")
        held = len(open_pos)
        kills = self.db.scalar(
            "SELECT COUNT(*) FROM scans WHERE verdict='kill'", default=0)
        last_scan = self.db.one("SELECT * FROM scans ORDER BY id DESC LIMIT 1")
        last_analyst = self.db.one("SELECT * FROM scores ORDER BY id DESC LIMIT 1")
        last_audit = self.db.one("SELECT * FROM audits ORDER BY id DESC LIMIT 1")
        last_layers = self._layer_strips(last_audit["mint"]) if last_audit else []
        last_brain = self.db.one("SELECT * FROM decisions WHERE bot='brain' ORDER BY id DESC LIMIT 1")
        last_risk_line = self.db.one(
            "SELECT * FROM activity WHERE kind='stopped' ORDER BY id DESC LIMIT 1")

        boots = []
        for name, color in (("Scanner", "#64d2ff"), ("Analyst", "#ffd60a"),
                            ("Brain", "#bf5af2"), ("Executor", "#00d35a"),
                            ("Risk", "#ff6b9a")):
            lb = self.db.heartbeat_age(name.lower())
            boots.append({"name": name, "color": color, "paused": name in self.paused,
                          "beat": lb, "down": lb is None or lb > 120})

        held_symbol = None
        if open_pos:
            row = self.db.one("SELECT symbol FROM coins WHERE mint=?", (open_pos[0]["mint"],))
            held_symbol = row["symbol"] if row else None

        return [
            {**boots[0], "count": self.db.scalar("SELECT COUNT(*) FROM scans", default=0),
             "unit": "pools", "countLabel": f"{kills} killed",
             "line": (last_scan["reason"] if last_scan and last_scan["verdict"] == "kill"
                      else f"{s['min_liquidity_usd']:,.0f}$ floor"),
             "foot": f"min age {s['min_pool_age_min']:g}m",
             "killed": bool(last_scan and last_scan["verdict"] == "kill"),
             "reason": last_scan["reason"] if last_scan else None},
            {**boots[1], "count": self.db.scalar("SELECT COUNT(*) FROM audits", default=0) // 8,
             "unit": "taken apart", "countLabel": f"{len(last_layers)} layers" if last_layers else "idle",
             "layers": last_layers,
             "score": last_analyst["score"] if last_analyst else 0,
             "line": f"{len(last_layers)}/8" if last_layers else "8 layers",
             "foot": (signed_pts(last_analyst["social_pts"])
                      if last_analyst and last_analyst["social"] is not None else "Social: off")},
            {**boots[2], "count": self.db.scalar(
                "SELECT COUNT(*) FROM decisions WHERE bot='brain'", default=0),
             "unit": "sizing", "countLabel": "",
             "line": (f"${json.loads(last_brain['data'])['sizeUsd']:,.2f}" if last_brain else "—"),
             "foot": (json.loads(last_brain["data"])["reason"] if last_brain else
                      "80+ = full size"),
             "bar": float(self.cfg.get("risk_per_trade_pct", 3)) * 10},
            {**boots[3], "count": trades, "unit": "trades", "countLabel": f"{held} open",
             "line": (f"{held_symbol} · holding" if held_symbol else "Waiting for a dip −15%"),
             "foot": f"max {self.cfg.get('max_ticket_usd')}$ · {self.cfg.get('max_trades_night')} a night",
             "bar": min(100, trades / max(1, int(self.cfg.get("max_trades_night", 30))) * 100)},
            {**boots[4], "count": self.db.scalar(
                "SELECT COUNT(*) FROM activity WHERE kind='stopped'", default=0),
             "unit": "guarding", "countLabel": "guarding" if held else "idle",
             "line": "Guarding" if held else "Nothing open",
             "stop": self.cfg.get("stop_pct"), "trail": self.cfg.get("trail_pct"),
             "locked": bool(held), "foot": (last_risk_line["value"] if last_risk_line else "")},
        ]

    def _layer_strips(self, mint: str) -> list[int]:
        rows = self.db.q("SELECT layer, pass FROM audits WHERE mint=? ORDER BY id DESC LIMIT 8",
                         (mint,))
        seen = {}
        for r in rows:
            seen.setdefault(r["layer"], 1 if r["pass"] else 0)
        return [seen.get(i, -1) for i in range(1, 9)]

    def chart_payload(self, rng: str) -> dict:
        cutoff = {
            "LIVE": timedelta(hours=12), "1H": timedelta(hours=1), "4H": timedelta(hours=4),
            "1D": timedelta(days=1), "1W": timedelta(days=7), "ALL": timedelta(days=3650),
        }.get(rng, timedelta(hours=12))
        start = datetime.now(timezone.utc) - cutoff
        rows = self.db.q("SELECT ts, value FROM balance ORDER BY rowid")
        points = [{"ts": r["ts"], "value": r["value"]} for r in rows
                  if (parse_ts(r["ts"]) or start) >= start]
        if not points:
            base = deskstate.free_cash(self.db, self.cfg)
            points = [{"ts": now(), "value": base}]
        marks = []
        entries = self.db.q(
            "SELECT a.kind, a.ts, a.value, a.mint FROM activity a WHERE a.kind='bought' "
            "ORDER BY a.id")
        for e in entries:
            idx = sum(1 for p in points if p["ts"] <= e["ts"])
            marks.append({"index": max(0, idx - 1), "text": e["value"], "color": "#0a84ff"})
        return {"range": rng, "points": points,
                "start": float(self.cfg.get("night_start_cash") or 0), "marks": marks}

    def activity_payload(self, before: str | None) -> list[dict]:
        sql = "SELECT * FROM activity"
        params: list = []
        if before:
            sql += " WHERE ts < ?"
            params.append(before)
        sql += " ORDER BY id DESC LIMIT 30"
        return [dict(r) for r in self.db.q(sql, params)]

    def orders_payload(self, before: str | None) -> list[dict]:
        sql = "SELECT * FROM orders"
        params: list = []
        if before:
            sql += " WHERE ts < ?"
            params.append(before)
        sql += " ORDER BY id DESC LIMIT 30"
        out = []
        for r in self.db.q(sql, params):
            d = dict(r)
            d["checks"] = {"screen": bool(r["screen_ok"]), "api": bool(r["api_ok"]),
                           "chain": bool(r["chain_ok"])}
            out.append(d)
        return out

    def coin_payload(self, mint: str) -> dict | None:
        coin = self.db.one("SELECT * FROM coins WHERE mint=?", (mint,))
        if not coin:
            return None
        pos = self.db.one(
            "SELECT * FROM positions WHERE mint=? AND closed_at IS NULL ORDER BY id DESC",
            (mint,))
        last_price = self.db.scalar(
            "SELECT price FROM prices WHERE mint=? ORDER BY rowid DESC LIMIT 1", (mint,))
        scores = self.db.one("SELECT * FROM scores WHERE mint=? ORDER BY id DESC", (mint,))
        audited = self.db.scalar("SELECT COUNT(*) FROM audits WHERE mint=? AND pass=1", (mint,),
                                 default=0)
        entry = pos["entry_price"] if pos else last_price
        pnl_pct = ((last_price / entry - 1) * 100) if (pos and last_price and entry) else None
        created = parse_ts(coin["migrated_at"] or coin["created_at"])
        age_text = ""
        if created:
            mins = int((datetime.now(timezone.utc) - created).total_seconds() / 60)
            age_text = f"{mins // 60}h {mins % 60}m old" if mins >= 60 else f"{mins}m old"
        return {
            "coin": {**dict(coin), "age_text": age_text, "layers_passed": min(audited, 8),
                     "holders": coin["holders"]},
            "price": last_price, "link": links.coin_url(mint),
            "candles": self._candles(mint),
            "position": ({**dict(pos), "owner": "Executor", "pnl_pct": pnl_pct} if pos else None),
            "score": scores["score"] if scores else None,
        }

    def _candles(self, mint: str) -> list[dict]:
        from datetime import datetime as dt
        rows = self.db.q("SELECT ts, price FROM prices WHERE mint=? ORDER BY rowid DESC LIMIT 180",
                         (mint,))
        rows = list(reversed(rows))
        buckets: dict[str, list[float]] = {}
        for r in rows:
            t = parse_ts(r["ts"])
            if not t:
                continue
            key = t.replace(second=0, microsecond=0).strftime("%Y-%m-%dT%H:%M")
            buckets.setdefault(key, []).append(r["price"])
        out = []
        for key, vals in sorted(buckets.items()):
            out.append({"ts": key, "open": vals[0], "high": max(vals),
                        "low": min(vals), "price": vals[-1]})
        return out[-120:]

    def audit_payload(self, mint: str) -> dict | None:
        rows = self.db.q("SELECT * FROM audits WHERE mint=? ORDER BY id", (mint,))
        if not rows:
            return None
        latest: dict[int, dict] = {}
        for r in rows:
            latest[r["layer"]] = dict(r)
        layers = []
        stopped = False
        for n in range(1, 9):
            row = latest.get(n)
            if row is None:
                layers.append({"n": n, "name": cfgmod_name(n), "pass": None,
                               "value": "not checked", "not_checked": True})
                continue
            if stopped:
                layers.append({"n": n, "name": row["name"], "pass": None,
                               "value": "not checked", "not_checked": True})
                continue
            layers.append({"n": n, "name": row["name"], "pass": bool(row["pass"]),
                           "value": row["value_text"]})
            if not row["pass"]:
                stopped = True
        score = self.db.one("SELECT * FROM scores WHERE mint=? ORDER BY id DESC", (mint,))
        coin = self.db.one("SELECT symbol FROM coins WHERE mint=?", (mint,))
        return {"mint": mint, "symbol": (coin or {})["symbol"], "layers": layers,
                "score": score["score"] if score else None,
                "social_text": ("Social: off" if not score or score["social"] is None else
                                f"{signed_pts(score['social_pts'])} · weight "
                                f"{self.cfg.get('social_weight'):g}")}

    def decisions_payload(self, bot: str) -> list[dict]:
        name = bot.capitalize()
        rows = self.db.q("SELECT * FROM decisions WHERE bot=? ORDER BY id DESC LIMIT 20",
                         (name.lower(),))
        out = []
        for r in rows:
            d = json.loads(r["data"])
            head, text = r["mint"][:6] + "…", d.get("reason") or ""
            if name == "Scanner":
                head = d.get("symbol") or head
                text = f"{d.get('verdict')} · {d.get('reason') or 'in the room'}"
            elif name == "Analyst":
                head = d.get("symbol") or head
                text = f"{d.get('score')} · {'pass' if d.get('passed') else d.get('reason')}"
            elif name == "Brain":
                head = d.get("symbol") or head
                text = f"${d.get('sizeUsd')} · {d.get('capHit')}"
            elif name == "Executor":
                head = d.get("symbol") or head
                text = f"{d.get('status')} {d.get('reason') or ''}".strip()
            elif name == "Risk":
                text = f"{d.get('reason')} {d.get('pct')}%"
            out.append({"ts": r["ts"], "head": head, "text": text, "mint": r["mint"]})
        return out

    def search_payload(self, q: str) -> list[dict]:
        if not q:
            return []
        like = f"%{q}%"
        rows = self.db.q(
            "SELECT mint, name, symbol FROM coins WHERE mint LIKE ? OR name LIKE ? "
            "OR symbol LIKE ? ORDER BY rowid DESC LIMIT 20", (like, like, like))
        return [dict(r) for r in rows]

    def account_payload(self) -> dict:
        return {
            "cash": deskstate.free_cash(self.db, self.cfg),
            "mode": self.cfg.get("mode"),
            "settings": {k: v for k, v in self.cfg.all().items()
                         if k not in ("data_path", "owner_chat_id")},
            "specs": cfgmod.describe(),
            "profile_url": links.profile_url(self.cfg.get("fomo_handle") or "you"),
            "signup_url": links.SIGNUP_URL,
        }

    def health_payload(self) -> dict:
        beats = {r["bot"]: r["ts"] for r in self.db.q("SELECT * FROM heartbeats")}
        return {"ok": True, "ts": now(), "beats": beats,
                "mode": self.cfg.get("mode"), "paused": sorted(self.paused),
                "lane": self.lane_status}

    # ---------------------------------------------------------------- actions
    def pause_bot(self, name: str, paused: bool) -> str | None:
        n = name.capitalize()
        if n not in ("Scanner", "Analyst", "Brain", "Executor", "Risk"):
            return "unknown bot"
        if n == "Risk" and paused:
            if self.db.scalar("SELECT COUNT(*) FROM positions WHERE closed_at IS NULL",
                              default=0):
                return "Risk cannot be paused while a position is open"
        if paused:
            self.paused.add(n)
            self.bus.paused.add(n.lower())
        else:
            self.paused.discard(n)
            self.bus.paused.discard(n.lower())
        return None

    def queue_sell(self, mint: str, pct: int) -> str | None:
        pos = self.db.one("SELECT * FROM positions WHERE mint=? AND closed_at IS NULL", (mint,))
        if not pos:
            return "no open position on that mint"
        self._pending_sells = getattr(self, "_pending_sells", [])
        self._pending_sells.append((mint, pct))
        return None

    def screen_path(self) -> str:
        return os.path.join("data", "screen.jpg")

    # ---------------------------------------------------------------- telegram
    def _wire_commands(self) -> None:
        t = self.notify

        async def status(_cmd: str, _arg: str) -> str:
            cash = deskstate.free_cash(self.db, self.cfg)
            pos = self.db.q("SELECT * FROM positions WHERE closed_at IS NULL")
            lines = [f"Mode: {self.cfg.get('mode')}", f"Cash: ${cash:,.2f}"]
            if not pos:
                lines.append("No open positions")
            for p in pos:
                coin = self.db.one("SELECT symbol FROM coins WHERE mint=?", (p["mint"],))
                lines.append(f"{coin['symbol'] if coin else p['mint'][:6]} · "
                             f"${p['size_usd']:,.2f}\n{links.coin_url(p['mint'])}")
            return "\n".join(lines)

        async def why(_cmd: str, arg: str) -> str:
            mint = self.find_mint(arg)
            if not mint:
                return "Which coin? Send its mint."
            row = self.db.one("SELECT * FROM activity WHERE mint=? AND kind IN "
                              "('rejected','stopped') ORDER BY id DESC", (mint,))
            if not row:
                return f"No refusal or stop for that coin tonight.\n{links.coin_url(mint)}"
            return f"{row['title']} · {row['subtitle']} · {row['value'][:16]}\n{links.coin_url(mint)}"

        async def sell(_cmd: str, arg: str) -> str:
            parts = arg.split()
            mint = self.find_mint(" ".join(parts[:-1]) or arg)
            pct = int(parts[-1]) if parts and parts[-1].isdigit() else 100
            if pct not in (25, 50, 100):
                return "Percent must be 25, 50 or 100."
            if not mint:
                return "Which coin? Send its mint."
            err = self.queue_sell(mint, pct)
            if err:
                return err
            return f"Sell {pct}% now? Reply yes.\n{links.coin_url(mint)}"

        async def buy(_cmd: str, arg: str) -> str:
            mint = self.find_mint(arg)
            if not mint:
                return ("Which coin? Send the mint. New coins are audited first: "
                        "8 layers, then the size.")
            return f"Queued for an audit: {mint}\n{links.coin_url(mint)}"

        async def pause(_cmd: str, arg: str) -> str:
            who = arg.strip().capitalize() or "Scanner"
            err = self.pause_bot(who, not (who in self.paused))
            if err:
                return err
            return f"{who} is {'paused' if who in self.paused else 'running'}."

        async def paper(_cmd: str, _arg: str) -> str:
            self.cfg.set("mode", "PAPER", who="owner")
            return "PAPER mode."

        async def live(_cmd: str, arg: str) -> str:
            if arg.strip() != "LIVE":
                return "Type: live LIVE"
            ok, why_ = self.live_allowed()
            if not ok:
                return why_
            self.cfg.set("mode", "LIVE", who="owner")
            return "LIVE enabled."

        async def withdraw(_cmd: str, arg: str) -> str:
            amt = arg.replace("$", "").strip()
            addr = self.cfg.get("withdraw_address")
            if not addr:
                return "Set your withdraw address in Account first. I never see a seed or key."
            return (f"Withdraw ${amt}: I open Profile → Withdraw and type ${amt} with your saved "
                    f"address, then stop at Review withdraw. You press Confirm and do 2FA.")

        async def invite(_cmd: str, _arg: str) -> str:
            return f"New to FOMO? {links.SIGNUP_URL}"

        async def picks(_cmd: str, _arg: str) -> str:
            return "Copy picks arrive with the chapter 3 prompt."

        async def report(_cmd: str, _arg: str) -> str:
            return "The morning Page is rebuilt at report_time."

        for name, fn in (("status", status), ("why", why), ("sell", sell), ("buy", buy),
                         ("pause", pause), ("paper", paper), ("live", live),
                         ("withdraw", withdraw), ("invite", invite), ("picks", picks),
                         ("report", report), ("start", status), ("help", status)):
            t.register(name, fn)

    def find_mint(self, text: str) -> str | None:
        t = (text or "").strip().lstrip("@")
        if not t:
            return None
        row = self.db.one(
            "SELECT mint FROM coins WHERE mint=? OR lower(symbol)=? OR lower(name)=?",
            (t, t.lower(), t.lower()))
        if row:
            return row["mint"]
        rows = self.db.q("SELECT mint FROM coins WHERE symbol LIKE ? OR name LIKE ? LIMIT 2",
                         (f"%{t}%", f"%{t}%"))
        return rows[0]["mint"] if len(rows) == 1 else None

    # ---------------------------------------------------------------- loops
    async def risk_loop(self, stop: asyncio.Event) -> None:
        while not stop.is_set():
            self.db.beat("risk")
            mints = [r["mint"] for r in self.db.q(
                "SELECT mint FROM positions WHERE closed_at IS NULL")]
            if mints and not self.selftest:
                prices = await self.market.prices(mints)
                for m, p in prices.items():
                    self.db.exec("INSERT INTO prices (mint, ts, price, volume_m5, holders) "
                                 "VALUES (?,?,?,NULL,NULL)", (m, now(), p))
                exits = await self.risk.poll_once(prices)
                for ex in exits:
                    await self._execute_exit(ex)
            elif self.selftest:
                exits = await self.risk.poll_once(self._selftest_prices())
                for ex in exits:
                    await self._execute_exit(ex)
            pending = getattr(self, "_pending_sells", [])
            while pending:
                mint, pct = pending.pop(0)
                await self._sell(mint, pct, "owner")
            await asyncio.sleep(int(self.cfg.get("risk_poll_s", 5)))

    async def _execute_exit(self, ex: dict) -> None:
        pos = ex["pos"]
        coin = self.db.one("SELECT symbol FROM coins WHERE mint=?", (ex["mint"],))
        await self._sell(ex["mint"], ex["pct"], "Risk", reason=ex["reason"],
                         price=ex.get("price"), symbol=(coin or {})["symbol"])

    async def _sell(self, mint: str, pct: int, owner: str, reason: str = "owner sell",
                    price: float | None = None, symbol: str | None = None) -> None:
        if not symbol:
            coin = self.db.one("SELECT symbol FROM coins WHERE mint=?", (mint,))
            symbol = (coin or {})["symbol"]
        res = await self.executor.sell(mint, pct, symbol or mint[:6], reason=reason,
                                       paper=self.cfg.get("mode") == "PAPER",
                                       owner=owner, price=price)
        await self.bus.emit("exit", res)

    def _selftest_prices(self) -> dict[str, float]:
        out = {}
        for r in self.db.q("SELECT mint FROM positions WHERE closed_at IS NULL"):
            p = self.db.scalar("SELECT price FROM prices WHERE mint=? ORDER BY rowid DESC LIMIT 1",
                               (r["mint"],))
            if p:
                out[r["mint"]] = p
        return out

    async def heartbeat_loop(self, stop: asyncio.Event) -> None:
        while not stop.is_set():
            for name in ("scanner", "analyst", "brain", "executor"):
                self.db.beat(name)
            await asyncio.sleep(20)

    async def scheduler_loop(self, stop: asyncio.Event) -> None:
        while not stop.is_set():
            await self._routines_once()
            await asyncio.sleep(60)

    async def _routines_once(self) -> None:
        f = lambda k: self.cfg.get(k)
        hhmm = datetime.now().strftime("%H:%M")
        if hhmm == f("night_start") and self.cfg.get("night_started_at", "")[:10] != \
                datetime.now().date().isoformat():
            self.cfg.set("night_started_at", now(), who="desk")
            self.cfg.set("night_start_cash", deskstate.free_cash(self.db, self.cfg), who="desk")
        if hhmm == f("lock_time"):
            for pos in self.db.q("SELECT mint FROM positions WHERE closed_at IS NULL"):
                self.queue_sell(pos["mint"], 100)
            await self.notify.push_night_over(deskstate.free_cash(self.db, self.cfg))

    async def screen_loop(self, stop: asyncio.Event) -> None:
        """One JPEG a second for the Home card, from the lane when it is live."""
        while not stop.is_set():
            if self.lane.frames_on and self.lane.pages is not None:
                try:
                    await self.lane.pages.capture(self.screen_path())
                except Exception:
                    pass
            await asyncio.sleep(1)


def signed_pts(v: float | None) -> str:
    if v is None:
        return ""
    n = round(v)
    if n == 0:
        return "Social +0"
    return f"Social {'+' if n > 0 else '−'}{abs(n)}"

    names = {1: "Mint authority", 2: "Freeze authority", 3: "Dev wallet", 4: "Top 10",
             5: "Liquidity", 6: "Pool age", 7: "Bundles", 8: "Delegations"}
    return names.get(n, f"Layer {n}")


def create_app(desk: Desk):
    from fastapi import FastAPI
    from fastapi.responses import FileResponse, JSONResponse
    from fastapi.staticfiles import StaticFiles
    from desk.api import router

    app = FastAPI(title="Grok Bot desk", docs_url=None, redoc_url=None)
    app.state.desk = desk
    app.include_router(router, prefix="/api")
    web = Path(__file__).parent / "web"
    app.mount("/static", StaticFiles(directory=str(web)), name="static")

    @app.get("/")
    async def root():
        return FileResponse(str(web / "index.html"))

    @app.get("/app.js")
    async def appjs():
        return FileResponse(str(web / "app.js"), media_type="text/javascript")

    @app.get("/app.css")
    async def appcss():
        return FileResponse(str(web / "app.css"), media_type="text/css")

    @app.get("/chart.js")
    async def chartjs():
        return FileResponse(str(web / "chart.js"), media_type="text/javascript")

    @app.get("/sw.js")
    async def swjs():
        return FileResponse(str(web / "sw.js"), media_type="text/javascript",
                            headers={"Service-Worker-Allowed": "/"})

    @app.get("/manifest.json")
    async def manifest():
        return FileResponse(str(web / "manifest.json"), media_type="application/manifest+json")

    @app.get("/icons/{name}")
    async def icon(name: str):
        p = web / "icons" / name
        if not p.exists():
            return JSONResponse({"error": "no icon"}, status_code=404)
        return FileResponse(str(p))

    return app


async def serve(desk: Desk, lan: bool = False) -> None:
    import uvicorn
    app = create_app(desk)
    host = "0.0.0.0" if lan else "127.0.0.1"
    port = int(os.environ.get("DESK_PORT", "8787"))
    server = uvicorn.Server(uvicorn.Config(app, host=host, port=port, log_level="warning",
                                           access_log=False))
    stop = asyncio.Event()
    tasks = [
        asyncio.create_task(desk.scheduler_loop(stop)),
        asyncio.create_task(desk.risk_loop(stop)),
        asyncio.create_task(desk.heartbeat_loop(stop)),
        asyncio.create_task(desk.notify.run(stop)),
        asyncio.create_task(desk.screen_loop(stop)),
    ]
    if not desk.selftest:
        tasks.append(asyncio.create_task(desk.scanner.run(stop)))
    logging.getLogger("desk").info("serving on http://%s:%s (APP_TOKEN %s)", host, port,
                                   "set" if os.environ.get("APP_TOKEN") else "MISSING")
    try:
        await server.serve()
    finally:
        stop.set()
        for t in tasks:
            t.cancel()


def selftest(db_path: str = ":memory:") -> int:
    """No network. Wires a fixture coin through every bot and reports what it did."""
    from desk import replay
    desk = Desk(db_path=db_path, selftest=True)
    ok = replay.run_paper_replay(desk)
    return 0 if ok else 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Grok Bot desk")
    ap.add_argument("--serve", action="store_true", help="run the always-on process")
    ap.add_argument("--lan", action="store_true", help="bind 0.0.0.0 for the phone")
    ap.add_argument("--selftest", action="store_true", help="offline fixture replay, then exit")
    ap.add_argument("--db", default=os.environ.get("DESK_DB", "data/desk.db"))
    ap.add_argument("--log", default=os.environ.get("DESK_LOG", "INFO"))
    args = ap.parse_args(argv)
    setup_logging(args.log)

    if args.selftest:
        return selftest(":memory:")
    if not args.serve:
        ap.print_help()
        return 0
    desk = Desk(db_path=args.db)
    asyncio.run(serve(desk, lan=args.lan))
    return 0


if __name__ == "__main__":
    sys.exit(main())
