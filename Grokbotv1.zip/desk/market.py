"""market.py — the outside world, one place: PumpPortal, DexScreener, RPC, RugCheck.

Every response is saved once under logs/raw/ (STEP 3) and read through fields.py. Nothing in
here decides anything: it fetches and normalises, the bots judge.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from datetime import datetime, timezone

import httpx

from desk import fields
from desk.bots.scanner import Pool

log = logging.getLogger("market")

PUMPPORTAL = "wss://pumpportal.fun/api/data"
DEX = "https://api.dexscreener.com/tokens/v1/solana/"
RUGCHECK = "https://api.rugcheck.xyz/v1/tokens/"


def _raw(name: str, data) -> None:  # pragma: no cover - disk side effect
    try:
        os.makedirs("logs/raw", exist_ok=True)
        with open(os.path.join("logs/raw", name), "w", encoding="utf-8") as f:
            json.dump(data, f, indent=1)[:0] if False else json.dump(data, f, indent=1)
    except OSError as e:
        log.warning("raw save failed for %s: %s", name, e)


class Market:
    """Read-only market data. `paper` forces the offline fixtures used by the replay."""

    def __init__(self, cfg, db, client: httpx.AsyncClient | None = None, paper: bool = False):
        self.cfg, self.db = cfg, db
        self.client = client
        self.paper = paper
        self._dex_calls: list[float] = []
        self.last_poll = 0.0

    async def _get(self, url: str, **kw):
        c = self.client or httpx.AsyncClient(timeout=15)
        try:
            r = await c.get(url, **kw)
        finally:
            if self.client is None:
                await c.aclose()
        if r.status_code == 429:
            await asyncio.sleep(30)          # DexScreener is asked to wait 30 s
            raise RuntimeError("429")
        r.raise_for_status()
        return r.json()

    # ---------------------------------------------------------------- DexScreener
    async def pairs(self, mints: list[str]) -> dict[str, dict]:
        if self.paper:
            return {}
        out: dict[str, dict] = {}
        for i in range(0, len(mints), 25):
            chunk = mints[i:i + 25]
            now = time.monotonic()
            self._dex_calls = [t for t in self._dex_calls if now - t < 60]
            if len(self._dex_calls) >= 250:
                await asyncio.sleep(2)
            try:
                data = await self._get(DEX + ",".join(chunk))
            except Exception as e:
                log.warning("dexscreener failed: %s", e)
                continue
            self._dex_calls.append(time.monotonic())
            _raw("dexscreener_pairs.json", data)
            by_mint: dict[str, list] = {}
            for p in data if isinstance(data, list) else []:
                addr = fields.pick(p, "baseToken.address")
                if addr:
                    by_mint.setdefault(addr, []).append(p)
            for mint, lst in by_mint.items():
                best = fields.dexscreener_pair(lst)
                if not best:
                    continue
                out[mint] = {
                    "price": fields.num(best, "priceUsd") or 0.0,
                    "liquidity_usd": fields.num(best, "liquidity.usd"),
                    "market_cap": fields.num(best, "marketCap") or fields.num(best, "fdv"),
                    "volume_m5": fields.num(best, "volume.m5"),
                    "volume_h1": fields.num(best, "volume.h1"),
                    "volume_h24": fields.num(best, "volume.h24"),
                    "change_m5": fields.num(best, "priceChange.m5"),
                    "change_h1": fields.num(best, "priceChange.h1"),
                    "change_h24": fields.num(best, "priceChange.h24"),
                    "buys_m5": fields.num(best, "txns.m5.buys"),
                    "sells_m5": fields.num(best, "txns.m5.sells"),
                    "buys_h1": fields.num(best, "txns.h1.buys"),
                    "sells_h1": fields.num(best, "txns.h1.sells"),
                    "pool": fields.pick(best, "pairAddress"),
                    "symbol": fields.pick(best, "baseToken.symbol"),
                    "name": fields.pick(best, "baseToken.name"),
                    "twitter": fields.pick(best, "info.socials.0.url"),
                    "pair_created_at": fields.num(best, "pairCreatedAt"),
                    "raw": best,
                }
        return out

    async def prices(self, mints: list[str]) -> dict[str, float]:
        if self.paper or not mints:
            return {}
        pairs = await self.pairs(mints)
        return {m: v["price"] for m, v in pairs.items() if v.get("price")}

    async def runners(self) -> list[str]:
        if self.paper:
            return []
        marks = ["$" for _ in range(1)]
        out = []
        for row in self.db.q("SELECT mint, symbol FROM coins"):
            v = self.db.scalar(
                "SELECT max(change_h24) FROM prices WHERE mint=?", (row["mint"],), 0) or 0
            if v >= self.cfg.get("runner_h24_pct", 300):
                out.append(row["symbol"] or "")
        return [s for s in out if s] or marks[:0]

    # ---------------------------------------------------------------- PumpPortal
    async def migrations(self):
        """Yield batches of Pool when the desk is live. Silent 120 s: reconnect 1/2/4..60 s."""
        if self.paper:
            return
        import websockets
        backoff = 1
        while True:
            try:
                async with websockets.connect(PUMPPORTAL, ping_interval=20) as ws:
                    await ws.send(json.dumps({"method": "subscribeMigration"}))
                    await ws.send(json.dumps({"method": "subscribeNewToken"}))
                    backoff = 1
                    batch: list[Pool] = []
                    while True:
                        try:
                            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=120))
                        except asyncio.TimeoutError:
                            break
                        _raw("pumpportal_last.json", msg)
                        mint = fields.pick(msg, "mint")
                        if not mint:
                            continue
                        if fields.pick(msg, "txType") == "create":
                            self.db.exec(
                                "INSERT OR IGNORE INTO coins (mint, name, symbol, created_at) "
                                "VALUES (?,?,?,?)",
                                (mint, fields.pick(msg, "name"), fields.pick(msg, "symbol"),
                                 datetime.now(timezone.utc).isoformat()))
                            continue
                        batch.append(Pool(mint=mint, name=fields.pick(msg, "name") or "",
                                          symbol=fields.pick(msg, "symbol") or "",
                                          pool=fields.pick(msg, "pool"),
                                          migrated_at=datetime.now(timezone.utc).isoformat()))
                        if len(batch) >= 10:
                            yield batch
                            batch = []
                    if batch:
                        yield batch
            except Exception as e:
                log.warning("pumpportal: %s, retry in %ss", e, backoff)
            await asyncio.sleep(backoff)
            backoff = min(60, backoff * 2)

    # ---------------------------------------------------------------- RPC
    async def rpc(self, method: str, params: list) -> dict:
        if self.paper:
            return {"jsonrpc": "2.0", "result": {}}
        body = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        data = await self._post_json(self.cfg.get("rpc_url"), body)
        _raw(f"rpc_{method}.json", data)
        return data

    async def _post_json(self, url: str, body: dict) -> dict:
        c = self.client or httpx.AsyncClient(timeout=25)
        try:
            r = await c.post(url, json=body)
        finally:
            if self.client is None:
                await c.aclose()
        r.raise_for_status()
        return r.json()

    async def mint_info(self, mint: str) -> dict:
        data = await self.rpc("getAccountInfo", [mint, {"encoding": "jsonParsed"}])
        return {
            "mint_authority": fields.pick(data, "result.value.data.parsed.info.mintAuthority"),
            "freeze_authority": fields.pick(data, "result.value.data.parsed.info.freezeAuthority"),
            "supply": fields.pick(data, "result.value.data.parsed.info.supply"),
            "decimals": fields.pick(data, "result.value.data.parsed.info.decimals"),
        }

    async def largest_accounts(self, mint: str) -> list[dict]:
        data = await self.rpc("getTokenLargestAccounts", [mint])
        return fields.pick(data, "result.value", []) or []

    async def token_balance(self, owner: str, mint: str) -> float | None:
        data = await self.rpc("getTokenAccountsByOwner",
                              [owner, {"mint": mint}, {"encoding": "jsonParsed"}])
        total = 0.0
        seen = False
        for acc in fields.pick(data, "result.value", []) or []:
            amt = fields.pick(acc, "account.data.parsed.info.tokenAmount.uiAmount")
            if amt is not None:
                total += float(amt)
                seen = True
        return total if seen else None

    async def get_program_accounts(self, mint: str, prog: str) -> list:
        data = await self.rpc("getProgramAccounts", [prog, {
            "encoding": "jsonParsed",
            "filters": [{"dataSize": 165}, {"memcmp": {"offset": 0, "bytes": mint}}],
        }])
        return fields.pick(data, "result", []) or []

    async def layer8(self, mint: str) -> dict | None:
        """Delegations plus the holder list. Token + Token-2022 (blocking proof for the owner)."""
        token = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        token2022 = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        accounts: list = []
        try:
            accounts += await self.get_program_accounts(mint, token)
            accounts += await self.get_program_accounts(mint, token2022)
        except Exception as e:
            log.warning("layer 8 refused: %s", e)
            return None
        worst = 0
        worst_delegate = None
        for acc in accounts:
            info = fields.pick(acc, "account.data.parsed.info") or {}
            delegate = info.get("delegate")
            if delegate:
                owners = 1
                if owners > worst:
                    worst = owners
                    worst_delegate = delegate
        return {"holders": len(accounts), "max_delegate_holders": worst,
                "worst_delegate": worst_delegate}

    # ---------------------------------------------------------------- RugCheck
    async def rug_report(self, mint: str) -> dict | None:
        if self.paper:
            return None
        try:
            data = await self._get(RUGCHECK + f"{mint}/report")
            _raw(f"rugcheck_{mint}.json", data)
            return data
        except Exception as e:
            log.warning("rugcheck report failed for %s: %s", mint, e)
            return None

    async def rug_graph(self, mint: str) -> dict | None:
        if self.paper:
            return None
        try:
            data = await self._get(RUGCHECK + f"{mint}/insiders/graph")
            _raw(f"rugcheck_graph_{mint}.json", data)
            return data
        except Exception as e:
            log.warning("rugcheck graph failed for %s: %s", mint, e)
            return None
