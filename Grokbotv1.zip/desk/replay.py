"""replay.py — 2 hours of migrations through the real bots, no network (STEP 15 tests 8, 11).

Every fixture goes through Scanner.consider, Analyst.audit, Brain.size and the Executor/Risk
settle path. The lane is a stub that writes PAPER fills, so the replay proves the decision
chain without a browser. It also probes the "never buy an open mint twice" rule and checks
that a kill, a red layer and a crash each produce their documented string.
"""

from __future__ import annotations

import logging

from desk import deskstate, fees, links

log = logging.getLogger("replay")


def fixture_coins() -> list[dict]:
    """One coin per rule from STEP 15 test 11, plus a clean winner that really trades."""
    return [
        {
            "id": "clear-winner", "symbol": "MOON",
            "pool": {"mint": "MoonMint111111111111111111111111111111111111",
                     "name": "Moon", "symbol": "MOON", "pool": "MoonPool", "age_min": 14,
                     "liquidity_usd": 42000, "top10_pct": 8.4, "h1_change_pct": 35,
                     "holders": 620, "holders_growth": 0.12, "volume_m5": 4000,
                     "volume_h1": 41000, "market_cap": 210000, "curve_min": 22},
            "snapshot": {"mint_authority": None, "freeze_authority": None, "dev_pct": 0.9,
                         "top10_pct": 8.4, "lp_locked_pct": 100, "age_min": 14,
                         "biggest_bundle": 1, "insider_pct": 3, "max_delegate_holders": 0,
                         "volume_h1": 41000, "unique_buys_1": 96, "unique_sells_1": 40,
                         "unique_buys_5m": 22, "unique_sells_5m": 9, "h1_change_pct": 35,
                         "curve_min": 22, "fresh_pct": 12, "holders": 620,
                         "social": 0.62, "liquidity_usd": 42000},
            "entry": 0.00042, "dip": 0.00035, "high": 0.00042, "peak": 0.00086,
        },
        {"id": "selling-off", "symbol": "TRAP",
         "pool": {"mint": "TrapMint111111111111111111111111111111111111",
                  "name": "Trap", "symbol": "TRAP", "pool": "TrapPool", "age_min": 18,
                  "liquidity_usd": 60000, "top10_pct": 12, "h1_change_pct": 20,
                  "disable_selling": True},
         "snapshot": None},
        {"id": "holders-leaving", "symbol": "FADE",
         "pool": {"mint": "FadeMint111111111111111111111111111111111111",
                  "name": "Fade", "symbol": "FADE", "pool": "FadePool", "age_min": 21,
                  "liquidity_usd": 55000, "top10_pct": 15, "h1_change_pct": 10,
                  "holders_growth": -0.04},
         "snapshot": None},
        {"id": "insiders-38", "symbol": "BUNDL",
         "pool": {"mint": "BundlMint111111111111111111111111111111111111",
                  "name": "Bundl", "symbol": "BUNDL", "pool": "BundlPool", "age_min": 25,
                  "liquidity_usd": 48000, "top10_pct": 11, "h1_change_pct": 40,
                  "volume_h1": 30000, "market_cap": 180000},
         "snapshot": {"mint_authority": None, "freeze_authority": None, "dev_pct": 1.2,
                      "top10_pct": 11, "lp_locked_pct": 100, "age_min": 25,
                      "biggest_bundle": 2, "insider_pct": 38, "max_delegate_holders": 0,
                      "volume_h1": 30000, "unique_buys_1": 70, "unique_sells_1": 30,
                      "unique_buys_5m": 12, "unique_sells_5m": 6, "h1_change_pct": 40,
                      "curve_min": 25, "fresh_pct": 20, "social": 0.5}},
        {"id": "dev-rugged", "symbol": "RUGX",
         "pool": {"mint": "RugxMint111111111111111111111111111111111111",
                  "name": "Rugx", "symbol": "RUGX", "pool": "RugxPool", "age_min": 30,
                  "liquidity_usd": 39000, "top10_pct": 9, "h1_change_pct": 15,
                  "volume_h1": 27000, "market_cap": 150000},
         "snapshot": {"mint_authority": None, "freeze_authority": None, "dev_pct": 2.0,
                      "creator_rugged": 2, "top10_pct": 9, "lp_locked_pct": 100,
                      "age_min": 30, "biggest_bundle": 1, "insider_pct": 2,
                      "max_delegate_holders": 0, "volume_h1": 27000,
                      "unique_buys_1": 60, "unique_sells_1": 20, "unique_buys_5m": 8,
                      "unique_sells_5m": 3, "h1_change_pct": 15, "curve_min": 30,
                      "fresh_pct": 18}},
        {"id": "fast-curve-fresh", "symbol": "SNIPE",
         "pool": {"mint": "SnipMint1111111111111111111111111111111111111",
                  "name": "Snipe", "symbol": "SNIPE", "pool": "SnipPool", "age_min": 11,
                  "liquidity_usd": 34000, "top10_pct": 14, "h1_change_pct": 55,
                  "volume_h1": 32000, "market_cap": 160000, "volume_m5": 9000},
         "snapshot": {"mint_authority": None, "freeze_authority": None, "dev_pct": 3.0,
                      "top10_pct": 14, "lp_locked_pct": 100, "age_min": 11,
                      "biggest_bundle": 2, "insider_pct": 6, "max_delegate_holders": 0,
                      "volume_h1": 32000, "unique_buys_1": 74, "unique_sells_1": 40,
                      "unique_buys_5m": 16, "unique_sells_5m": 8, "h1_change_pct": 55,
                      "curve_min": 4, "fresh_pct": 60}},
        {"id": "crash-41", "symbol": "DUMP",
         "pool": {"mint": "DumpMint111111111111111111111111111111111111",
                  "name": "Dump", "symbol": "DUMP", "pool": "DumpPool", "age_min": 16,
                  "liquidity_usd": 51000, "top10_pct": 10, "h1_change_pct": 30,
                  "volume_h1": 38000, "market_cap": 190000},
         "snapshot": {"mint_authority": None, "freeze_authority": None, "dev_pct": 1.0,
                      "top10_pct": 10, "lp_locked_pct": 100, "age_min": 16,
                      "biggest_bundle": 1, "insider_pct": 1, "max_delegate_holders": 0,
                      "volume_h1": 38000, "unique_buys_1": 90, "unique_sells_1": 30,
                      "unique_buys_5m": 18, "unique_sells_5m": 7, "h1_change_pct": 30,
                      "curve_min": 16, "fresh_pct": 15},
         "entry": 0.0012, "high": 0.0020, "crash_price": 0.00118},
        {"id": "thin-liq", "symbol": "THIN",
         "pool": {"mint": "ThinMint111111111111111111111111111111111111",
                  "name": "Thin", "symbol": "THIN", "pool": "ThinPool", "age_min": 15,
                  "liquidity_usd": 14200, "top10_pct": 10, "h1_change_pct": 10},
         "snapshot": None},
        {"id": "copycat", "symbol": "MOON2",
         "pool": {"mint": "Moon2Mint11111111111111111111111111111111111",
                  "name": "Moon2", "symbol": "MOON2", "pool": "Moon2Pool", "age_min": 15,
                  "liquidity_usd": 80000, "top10_pct": 10, "h1_change_pct": 30},
         "snapshot": None},
    ]


RUNNERS = ["MOON"]


class StubLane:
    """PAPER lane: fills at the price the desk read, never clicks."""

    def __init__(self):
        self.calls: list[tuple] = []

    async def buy(self, *, mint, usd, symbol, paper, owner):
        from desk.browser import LaneResult
        self.calls.append(("buy", mint, usd))
        return LaneResult("paper_done", "PAPER: stopped before the button",
                          {"screen": True, "api": True, "chain": "n/a"},
                          quote_text=f"${usd:.2f}", fill_usd=usd)

    async def sell(self, *, mint, pct, symbol, paper, owner, price):
        from desk.browser import LaneResult
        self.calls.append(("sell", mint, pct))
        return LaneResult("paper_done", "PAPER: sell tab only", {}, price=price)


def run_paper_replay(desk, verbose: bool = True) -> bool:
    import asyncio
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(_run(desk, verbose))
    raise RuntimeError("run_paper_replay must not be called from a running loop")


async def _run(desk, verbose: bool) -> bool:
    from desk.bots import brain as brain_mod
    from desk.bots import risk as risk_mod
    from desk.bots.executor import dip_state, take_profit
    from desk.bots.scanner import Pool

    desk.executor.lane = StubLane()
    cfg_b = desk.cfg.group("brain")
    cfg_r = desk.cfg.group("risk")
    cfg_e = desk.cfg.group("executor")
    bus_backup = desk.scanner.bus
    desk.scanner.bus = None          # the bus hop is covered by the API tests

    report: list[str] = []
    dup_created = None
    try:
        for fx in fixture_coins():
            pool = Pool(**fx["pool"])
            scan = await desk.scanner.consider(pool, RUNNERS)
            verdict, reason = scan["verdict"], scan["reason"]
            report.append(f"{fx['symbol']:<6} scanner: {verdict}"
                          f"{' · ' + reason if reason else ''}")
            # register the coin even when Scanner cuts it, so the audit screen has a row
            desk.db.exec(
                "INSERT OR REPLACE INTO coins (mint, name, symbol, pool, created_at) "
                "VALUES (?,?,?,?,?)",
                (pool.mint, pool.name, pool.symbol, pool.pool, "2026-11-23T21:51:00.000Z"))
            if verdict != "pass":
                continue

            snap = {**(fx["snapshot"] or {}), "symbol": pool.symbol}
            audit = desk.analyst.audit(pool.mint, snap)
            red = next((l for l in audit["layers"] if not l["pass"]), None)
            if red:
                report.append(f"{fx['symbol']:<6} analyst: layer {red['n']} {red['value']}")
                continue
            if not audit["passed"]:
                report.append(f"{fx['symbol']:<6} analyst: score {audit['score']} "
                              f"({audit['reason']})")
                continue
            report.append(f"{fx['symbol']:<6} analyst: 8/8 · score {audit['score']} · "
                          f"social {audit['socialPts']:+.0f}")

            cash = deskstate.free_cash(desk.db, desk.cfg)
            sized = brain_mod.size(cash, audit["score"], snap.get("liquidity_usd"),
                                   {"brain": cfg_b, "risk": cfg_r})
            report.append(f"{fx['symbol']:<6} brain: ${sized['sizeUsd']} "
                          f"({sized['pctOfCash']}% of cash, cap {sized['capHit']})")
            if sized["skip"]:
                continue

            if fx["id"] == "crash-41":
                dip, why = dip_state(fx["crash_price"], fx["high"], cfg_e, 30, 4)
            elif "entry" in fx:
                dip, why = dip_state(fx["dip"], fx["high"], cfg_e, 6, 12)
            else:
                dip, why = dip_state(None, None, cfg_e, None, None)
            report.append(f"{fx['symbol']:<6} dip: {dip}{' · ' + why if why else ''}")
            if dip != "buy" or "entry" not in fx:
                continue

            buy_price = fx.get("dip") or fx["entry"]
            res = await desk.executor.lane.buy(mint=pool.mint, usd=sized["sizeUsd"],
                                               symbol=pool.symbol, paper=True,
                                               owner="Executor")
            desk.db.exec(
                "INSERT INTO orders (ts, mint, side, usd, pct, bot, reason, status, quote_text,"
                " screen_ok, api_ok, chain_ok, fill_usd) VALUES "
                "(strftime('%Y-%m-%dT%H:%M:%fZ','now'),?,?,?,?,?,?,?,?,1,1,1,?)",
                (pool.mint, "buy", sized["sizeUsd"], None, "Executor", None, "paper_done",
                 res.quote_text, sized["sizeUsd"]))
            desk.db.exec("INSERT INTO prices (mint, ts, price, volume_m5, holders) "
                         "VALUES (?,strftime('%Y-%m-%dT%H:%M:%fZ','now'),?,NULL,?)",
                         (pool.mint, buy_price, snap.get("holders")))
            pid = deskstate.open_position(desk.db, desk.cfg, pool.mint, pool.symbol,
                                          {"fill_usd": sized["sizeUsd"], "price": buy_price},
                                          sized["sizeUsd"], True)
            report.append(f"{fx['symbol']:<6} executor: Bought ${sized['sizeUsd']} "
                          f"(PAPER, verified)")

            pos = dict(desk.db.one("SELECT * FROM positions WHERE id=?", (pid,)))
            # FOMO is the truth: a mint already open is never bought twice
            dup = deskstate.open_position(desk.db, desk.cfg, pool.mint, pool.symbol,
                                          {"fill_usd": 2.5, "price": buy_price}, 2.5, True)
            if dup is not None:
                dup_created = pool.symbol
            report.append(f"{fx['symbol']:<6} guard: second position on an open mint -> "
                          f"{'REFUSED' if dup is None else 'CREATED (bug)'}")

            if fx["id"] == "clear-winner":
                tp = take_profit(pos["entry_price"], fx["peak"], fx["peak"], False, False, cfg_e)
                report.append(f"MOON   take profit: {tp}")
                desk.db.exec(
                    "UPDATE positions SET tp_done=1, trail_active=1, peak_price=? WHERE id=?",
                    (fx["peak"], pos["id"]))
                drop = fx["peak"] * (1 - cfg_e["trail_pct"] / 100)
                rest = take_profit(pos["entry_price"], drop, fx["peak"], True, True, cfg_e)
                report.append(f"MOON   trail: {rest}")
                pos = dict(desk.db.one("SELECT * FROM positions WHERE id=?", (pos["id"],)))
            else:
                stop_price = pos["entry_price"] * (1 - cfg_r["stop_pct"] / 100) * 0.999
                exit_ = risk_mod.check(pos, stop_price, "", cfg_r)
                report.append(f"{fx['symbol']:<6} risk: "
                              f"{exit_['reason'] if exit_ else 'holding'}")

            if pos and not pos["closed_at"]:
                deskstate.close_position(desk.db, desk.cfg, pool.mint, pool.symbol,
                                         {"price": pos["entry_price"] * 0.749}, 100,
                                         "stop", True)
    finally:
        desk.scanner.bus = bus_backup

    report.append("fees: " + " · ".join(
        f"${v:.2f} -> ${fees.side_fee(v):.2f}" for v in (2, 10, 100, 500)))
    report.append("links: " + links.coin_url("MoonMint111111111111111111111111111111111111"))

    for line in report:
        if verbose:
            print(line)

    bought = desk.db.scalar("SELECT COUNT(*) FROM orders WHERE side='buy' AND "
                            "status='paper_done'", default=0)
    return dup_created is None and bought >= 1


if __name__ == "__main__":
    from desk.main import Desk, setup_logging
    setup_logging("WARNING")
    d = Desk(db_path=":memory:", selftest=True)
    raise SystemExit(0 if run_paper_replay(d) else 1)
