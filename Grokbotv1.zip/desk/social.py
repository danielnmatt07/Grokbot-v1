"""social.py — the 5th part of Analyst's score (Plan A webhook / B X plugin / C off).

The process cannot search X. Plan A POSTs to a webhook routine and reads social/{mint}.json
when it lands. Late past social_timeout_s: social = null for that coin, the buy does not wait.
Social never overrides a layer.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from datetime import datetime, timezone

log = logging.getLogger("social")


def value_from(raw: dict, cfg: dict) -> dict:
    """Pure: the documented formula, so the fake-ring test can drive it."""
    s = cfg["social"]
    u15 = raw.get("u15")
    u60 = raw.get("u60")
    big = raw.get("big")
    shill = raw.get("shill") or 0.0
    catalyst = bool(raw.get("catalyst"))
    coinx = raw.get("coinX") or {}
    smart = raw.get("smart") or 0

    if u15 is None and u60 is None:
        return {"social": None, "reason": "no data from X"}
    u15 = float(u15 or 0)
    u60 = float(u60 or 0)
    accel = (u15 * 4 / max(1.0, u60))
    v = min(u15 / 20.0, 1.0) * (0.5 if accel < 1 else 1.0)
    b = min(float(big or 0) / 3.0, 1.0)
    c = 1.0 if catalyst else 0.0
    x = 1.0 if (coinx.get("age_days") or 0) > 7 and (coinx.get("replies") or 0) > 0 else \
        (0.5 if coinx else 0.0)
    sm = min(float(smart) / 2.0, 1.0)
    total = max(0.0, min(1.0, 0.30 * v + 0.15 * b + 0.15 * c + 0.10 * x + 0.30 * sm - shill))
    return {"social": round(total, 3), "accel": round(accel, 2), "shill": round(float(shill), 2),
            "ring": float(shill) >= s["shill_cut"], "reason": None}


class Social:
    def __init__(self, cfg, db, webhook_url: str = "", webhook_token: str = "",
                 out_dir: str = "data/social", plan: str = "C"):
        self.cfg, self.db = cfg, db
        self.webhook_url, self.webhook_token = webhook_url, webhook_token
        self.out_dir, self.plan = out_dir, plan
        self.calls_this_hour: list[float] = []

    def _budget(self) -> bool:
        import time
        now = time.monotonic()
        self.calls_this_hour = [t for t in self.calls_this_hour if now - t < 3600]
        return len(self.calls_this_hour) < self.cfg.get("social_max_per_h", 20)

    def path(self, mint: str) -> str:
        return os.path.join(self.out_dir, f"{mint}.json")

    async def ask(self, mint: str, symbol: str, name: str, coinx: str | None,
                  leaders: list[str]) -> dict | None:
        if self.plan == "C":
            return None
        if not self._budget():
            log.info("social budget reached, %s gets null", mint)
            return None
        import time
        self.calls_this_hour.append(time.monotonic())
        if self.plan == "A" and self.webhook_url:
            import httpx
            try:
                async with httpx.AsyncClient(timeout=10) as c:
                    await c.post(self.webhook_url, headers={
                        "Authorization": f"Bearer {self.webhook_token}"},
                        json={"mint": mint, "symbol": symbol, "name": name,
                              "coinX": coinx, "leaders": leaders[:150]})
            except httpx.HTTPError as e:
                log.warning("social webhook failed: %s", e)
                return None
        timeout = self.cfg.get("social_timeout_s", 120)
        deadline = asyncio.get_running_loop().time() + timeout
        while asyncio.get_running_loop().time() < deadline:
            if os.path.exists(self.path(mint)):
                try:
                    with open(self.path(mint), encoding="utf-8") as f:
                        raw = json.load(f)
                except (OSError, ValueError):
                    await asyncio.sleep(2)
                    continue
                out = value_from(raw, {"social": self.cfg.group("social")})
                out["raw_path"] = self.path(mint)
                self._log(mint, out)
                return out
            await asyncio.sleep(2)
        log.info("social timed out for %s: null", mint)
        self._log(mint, {"social": None, "reason": "timeout"})
        return None

    def _log(self, mint: str, out: dict) -> None:  # pragma: no cover
        try:
            os.makedirs("logs", exist_ok=True)
            with open("logs/social.log", "a", encoding="utf-8") as f:
                f.write(json.dumps({"ts": datetime.now(timezone.utc).isoformat(),
                                    "mint": mint, "plan": self.plan, **out}) + "\n")
        except OSError:
            pass
