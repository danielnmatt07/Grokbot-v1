"""telegram.py — pushes and talking to the desk (STEP 11).

Owner lock: the first /start becomes owner_chat_id, everyone else is ignored. Long polling,
no webhook. PAPER pushes start with "PAPER · ". Every coin in any reply carries its coin_url.
"""

from __future__ import annotations

import logging
import os
from typing import Awaitable, Callable

import httpx

from desk import config as cfgmod
from desk import links

log = logging.getLogger("telegram")

API = "https://api.telegram.org/bot"


class Telegram:
    def __init__(self, cfg, db, token: str | None = None, client=None):
        self.cfg, self.db = cfg, db
        self.token = token or os.environ.get("TELEGRAM_BOT_TOKEN", "")
        self.client = client
        self.offset = 0
        self.handlers: dict[str, Callable[[str, str], Awaitable[str]]] = {}
        self.enabled = bool(self.token)

    def owner(self) -> str:
        return self.cfg.get("owner_chat_id") or ""

    # ---------------------------------------------------------------- send
    async def send(self, text: str, *, button_url: str | None = None,
                   button_text: str = "Open on FOMO", chat_id: str | None = None) -> bool:
        if not self.enabled:
            log.info("push (no telegram): %s", text.replace("\n", " · "))
            return False
        body = {"chat_id": chat_id or self.owner(), "text": text,
                "disable_web_page_preview": False}
        if button_url:
            body["reply_markup"] = {"inline_keyboard": [[
                {"text": button_text, "url": button_url}]]}
        c = self.client or httpx.AsyncClient(timeout=15)
        try:
            r = await c.post(f"{API}{self.token}/sendMessage", json=body)
            return r.status_code == 200
        finally:
            if self.client is None:
                await c.aclose()

    def prefix(self) -> str:
        return "PAPER · " if self.cfg.get("mode") == "PAPER" else ""

    async def push_bought(self, symbol: str, usd: float, mint: str) -> None:
        await self.send(f"{self.prefix()}Bought {symbol} · ${usd:,.2f} · Executor",
                        button_url=links.coin_url(mint))

    async def push_sold(self, symbol: str, pnl: float, pct: float, mint: str) -> None:
        await self.send(f"{self.prefix()}Sold {symbol} · {pnl:+,.2f} ({pct:+.1f}%)",
                        button_url=links.coin_url(mint))

    async def push_stopped(self, symbol: str, pnl: float, mint: str, reason: str) -> None:
        await self.send(f"{self.prefix()}Stopped {symbol} · {reason} · {pnl:+,.2f}",
                        button_url=links.coin_url(mint))

    async def push_unverified(self, symbol: str, mint: str) -> None:
        await self.send(f"{self.prefix()}Unverified: {symbol}, check FOMO",
                        button_url=links.coin_url(mint))

    async def push_logged_out(self) -> None:
        await self.send(f"{self.prefix()}FOMO logged out. Take control and log in",
                        button_url=links.SIGNUP_URL, button_text="Open FOMO")

    async def push_night_over(self, balance: float) -> None:
        await self.send(f"{self.prefix()}Night over · ${balance:,.2f}")

    # ---------------------------------------------------------------- commands
    def register(self, name: str, fn: Callable[[str, str], Awaitable[str]]) -> None:
        self.handlers[name] = fn

    async def run(self, stop_event) -> None:
        if not self.enabled:
            while not stop_event.is_set():
                import asyncio
                await asyncio.sleep(5)
            return
        import asyncio
        while not stop_event.is_set():
            try:
                await self._poll_once()
            except Exception as e:
                log.warning("telegram poll failed: %s", e)
                await asyncio.sleep(5)
            await asyncio.sleep(1)

    async def _poll_once(self) -> None:
        c = self.client or httpx.AsyncClient(timeout=40)
        try:
            r = await c.get(f"{API}{self.token}/getUpdates",
                            params={"timeout": 25, "offset": self.offset,
                                    "allowed_updates": '["message"]'})
        finally:
            if self.client is None:
                await c.aclose()
        if r.status_code != 200:
            return
        for upd in r.json().get("result", []):
            self.offset = upd["update_id"] + 1
            msg = upd.get("message") or {}
            text = (msg.get("text") or "").strip()
            chat = str((msg.get("chat") or {}).get("id") or "")
            if not text or not chat:
                continue
            await self._handle(chat, text)

    async def _handle(self, chat: str, text: str) -> None:
        owner = self.owner()
        if not owner:
            self.cfg.set("owner_chat_id", chat, who="telegram")
            await self.send("You are the owner of this desk. Type /status.", chat_id=chat)
            return
        if chat != owner:
            log.info("ignoring message from %s", chat)
            return

        low = text.lower().lstrip("/")
        cmd = low.split()[0] if low.split() else ""
        arg = text.split(None, 1)[1] if len(text.split(None, 1)) > 1 else ""

        # 'set stop to -20%' is not a /command
        parsed = cfgmod.parse_set_command(text)
        if parsed:
            reply = await self._set(parsed[0], parsed[1])
            await self.send(reply)
            return
        fn = self.handlers.get(cmd)
        if fn is None:
            await self.send(self.help_text())
            return
        reply = await fn(cmd, arg.strip())
        if reply:
            await self.send(reply)

    async def _set(self, key: str, raw: str) -> str:
        try:
            res = self.cfg.set(key, raw, who="owner")
        except ValueError as e:
            return str(e)
        spec = cfgmod.BY_KEY[key]
        return f"{spec.label}: {res['old']}{spec.unit} -> {res['new']}{spec.unit}"

    def help_text(self) -> str:
        return ("Commands:\n"
                "status · why X · sell X [25|50|100] · buy X · pause Scanner\n"
                "set stop to -20% · paper | live · withdraw $N · picks · invite · report\n"
                f"New to FOMO? {links.SIGNUP_URL}")
