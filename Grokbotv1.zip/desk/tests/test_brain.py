"""tests/test_brain.py — STEP 15 test 3. cash $100, score 80 -> $12; 79 -> $6; <$2 -> skip."""

from __future__ import annotations

from desk.bots.brain import size

CFG = {
    "brain": {"risk_per_trade_pct": 3, "full_size_score": 80, "below_full_pct": 50,
              "max_pool_pct": 2, "min_ticket_usd": 2, "max_ticket_usd": 50,
              "max_trades_night": 30},
    "risk": {"stop_pct": 25, "night_loss_stop_pct": 30},
}


def test_full_size_at_80():
    d = size(100, 80, 1_000_000, CFG)
    assert d["sizeUsd"] == 12.0, d
    assert d["pctOfCash"] == 12.0


def test_just_below_80_is_half():
    assert size(100, 79, 1_000_000, CFG)["sizeUsd"] == 6.0


def test_stop_never_costs_more_than_risk_per_trade():
    d = size(100, 95, 1_000_000, CFG)
    assert round(d["sizeUsd"] * 0.25, 4) == 3.0


def test_under_two_dollars_skips():
    d = size(12, 79, 80, CFG)          # pool cap = 2% of $80 = $1.60
    assert d["skip"] and d["reason"] == "under $2"


def test_pool_cap():
    # cash $100 at 3% risk and a 25% stop = $12, under the pool cap
    assert size(100, 80, 20_000, CFG)["sizeUsd"] == 12.0
    # the plan's example: a $20,000 pool caps the ticket at $400
    d2 = size(100000, 80, 20_000, CFG)
    assert d2["sizeUsd"] == 50.0, d2          # the $50 ticket cap binds first
    assert d2["capHit"] == "ticket"
    big = {**CFG, "brain": {**CFG["brain"], "max_ticket_usd": 100_000}}
    d3 = size(100000, 80, 20_000, big)
    assert d3["sizeUsd"] == 400.0, d3         # now 2% of the pool binds
    assert d3["capHit"] == "pool"


def test_ticket_cap():
    d = size(100000, 80, 10_000_000, CFG)
    assert d["sizeUsd"] == 50.0
    assert d["capHit"] == "ticket"


def test_shill_ring_halves():
    d = size(100, 80, 1_000_000, CFG, shill_ring=True)
    assert d["sizeUsd"] == 6.0


def test_night_loss_stop_and_trade_cap():
    assert size(100, 90, 1e6, CFG, night_loss_pct=30)["skip"] is True
    assert size(100, 90, 1e6, CFG, trades_tonight=30)["skip"] is True


def test_free_cash_is_the_ceiling():
    # risk size is 12% of free cash at the defaults, so it scales with the account
    assert size(100, 95, 1_000_000, CFG)["sizeUsd"] == 12.0
    assert size(30, 95, 1_000_000, CFG)["sizeUsd"] == 3.6
    # $4 free cash: 3% of it would be $0.48, under the $2 minimum, so skip instead of oversizing
    assert size(4, 95, 1_000_000, CFG)["skip"] is True


def test_a_tiny_account_skips_instead_of_oversizing():
    # $5 cash would allow a $0.60 ticket: under the $2 FOMO minimum, so skip
    d = size(5, 95, 1_000_000, CFG)
    assert d["skip"] is True and d["reason"] == "under $2"
