"""tests/test_browser.py — STEP 15 test 5, without a browser.

The lane's rules are plain functions, so the PAPER proof and the Withdraw refusal are testable
here. The real click-by-text proof needs the desk Chrome and is listed as unverified on
Windows until the owner runs `desk.ps1 verify`.
"""

from __future__ import annotations

import pytest

from desk import browser, links

MOON = "MoonMint111111111111111111111111111111111111"


def test_coin_page_is_the_links_url():
    assert browser.coin_page(MOON) == links.coin_url(MOON)


def test_allow_list_accepts_the_plan_controls():
    for text in ("Buy", "Sell", "Paste", "Max", "Trending", "Search", "$10", "$100",
                 "$500", "$1000", "10%", "25%", "50%", "100%"):
        assert browser.may_click(text, side="buy", symbol="MOON"), text


def test_allow_list_accepts_the_primary_buttons():
    assert browser.may_click("Buy MOON", side="buy", symbol="MOON")
    assert browser.may_click("Sell MOON", side="sell", symbol="MOON")


@pytest.mark.parametrize("text", [
    "Withdraw", "Deposit", "Deposit more", "Buy with Apple Pay", "Orders", "Perps", "Send",
    "Settings", "Export private key", "Swap settings", "Slippage", "Discover", "Thesis",
    "Confirm withdraw", "Review withdraw", "High network fee",
])
def test_never_clicks(text):
    assert browser.refuses(text) is True
    assert browser.may_click(text, side="buy", symbol="MOON") is False


def test_withdraw_is_refused_in_code():
    with pytest.raises(browser.LaneBlocked):
        browser.require_fomo_url("https://fomo.family/profile/x/withdraw")
    assert browser.page_allowed("https://fomo.family/profile/savi?source=share_link&r=savipww")


def test_a_box_to_tick_is_a_skip():
    # any checkbox label that matches the never list is a skip, not a click
    assert browser.refuses("I understand the network fee")


def test_amount_read_back_must_match_to_the_cent():
    assert browser.amount_matches("$2.50", 2.5)
    assert browser.amount_matches("2.50", 2.50)
    assert not browser.amount_matches("2.51", 2.50)
    assert not browser.amount_matches("", 2.5)


def test_quote_must_be_loaded():
    assert browser.quote_ready("You get 12,431 MOON")
    assert not browser.quote_ready("Loading…")
    assert not browser.quote_ready("")
    assert not browser.quote_ready("—")


def test_page_allow_list():
    assert browser.page_allowed(links.coin_url(MOON))
    assert browser.page_allowed("https://fomo.family/profile/savi?source=share_link&r=savipww")
    assert not browser.page_allowed("https://fomo.family/withdraw")
    assert not browser.page_allowed("https://example.com/coin")


def test_paper_buy_stops_before_the_button_without_page_objects():
    import asyncio
    lane = browser.Lane(cfg=_FakeCfg(), db=None)
    res = asyncio.run(lane.buy(mint=MOON, usd=2.0, symbol="MOON", paper=True, owner="Executor"))
    # no lesson and no pages: the lane refuses instead of guessing a selector
    assert res.status == "failed"
    assert "lane offline" in res.reason


def test_a_missing_lesson_blocks_the_night():
    lesson = browser.Lesson({})
    with pytest.raises(browser.LaneBlocked) as e:
        lesson.need("buy_tab", "amount_field")
    assert "fomo_web.md is missing" in str(e.value)


def test_cursor_colors_are_the_documented_ones():
    assert browser.BOTS == {"Scanner": "#64d2ff", "Analyst": "#ffd60a", "Brain": "#bf5af2",
                            "Executor": "#00d35a", "Risk": "#ff6b9a"}


def test_cursor_script_never_takes_clicks():
    js = browser.cursor_js()
    assert "pointer-events:none" in js
    assert "__deskMove" in js and "__deskDip" in js
    for color in browser.BOTS.values():
        assert color in js


class _FakeCfg:
    def group(self, name):
        return {"quote_timeout_s": 10, "verify_timeout_s": 30, "dip_pct": 15,
                "dip_window_min": 10, "dip_wait_min": 30, "crash_pct": 35, "tp_x": 2.0,
                "tp_sell_pct": 50, "trail_pct": 40, "recheck_liq_drop_pct": 20,
                "recheck_price_up_pct": 15}

    def get(self, key, default=None):
        return default
