"""tests/test_gate.py — STEP 15 test 2. score 69 rejects, 70 passes; one red layer rejects."""

from __future__ import annotations

from desk.bots.analyst import run_layers, score

CFG = {
    "analyst": {"max_dev_pct": 5, "analyst_max_top10_pct": 25, "min_lp_locked_pct": 99,
                "max_bundled": 5, "max_delegated_accounts": 10, "min_score": 70,
                "alive_volume_h1": 25000, "fast_curve_min": 10, "max_fresh_pct": 50,
                "organic_unique_h1": 80, "organic_buys_h1": 150, "bundled_penalty": 0.5,
                "flush_sell_ratio": 1.5, "chase_h1_pct": 200},
    "brain": {"full_size_score": 80},
    "social": {"social_weight": 0.5},
}

GREEN = {
    "mint_authority": None, "freeze_authority": None, "dev_pct": 1.0, "top10_pct": 10,
    "lp_locked_pct": 100, "age_min": 15, "biggest_bundle": 1, "insider_pct": 2,
    "max_delegate_holders": 0, "volume_h1": 25000, "unique_buys_1": 80,
    "unique_sells_1": 40, "unique_buys_5m": 20, "unique_sells_5m": 8, "h1_change_pct": 0,
    "curve_min": 20, "fresh_pct": 10,
}


def test_all_green_layers():
    layers = run_layers(GREEN, CFG["analyst"])
    assert len(layers) == 8 and all(l["pass"] for l in layers)


def test_each_red_layer_stops_the_rest():
    cases = {
        1: {"mint_authority": "9xQ"},
        2: {"freeze_authority": "9xQ"},
        3: {"dev_pct": 31},
        4: {"top10_pct": 58},
        5: {"lp_locked_pct": 40},
        6: {"age_min": 4},
        7: {"biggest_bundle": 14},
        8: {"max_delegate_holders": 41},
    }
    for n, override in cases.items():
        snap = {**GREEN, **override}
        layers = run_layers(snap, CFG["analyst"])
        assert len(layers) == n, f"layer {n} should stop the run, got {len(layers)}"
        assert layers[-1]["pass"] is False


def test_one_red_layer_rejects_whatever_social_says():
    snap = {**GREEN, "dev_pct": 31}
    layers = run_layers(snap, CFG["analyst"])
    green = len(layers) == 8 and all(l["pass"] for l in layers)
    assert not green
    # the desk only asks for social when 8 of 8 are green
    sc = score(snap, CFG, 1.0 if green else None)
    assert green is False


def test_no_data_is_never_a_pass():
    for key in ("dev_pct", "top10_pct", "lp_locked_pct", "age_min", "biggest_bundle",
                "max_delegate_holders"):
        snap = {**GREEN, key: None}
        layers = run_layers(snap, CFG["analyst"])
        assert layers[-1]["pass"] is False, f"missing {key} passed"
        assert "no data" in layers[-1]["value"]


def test_score_69_rejects_70_passes():
    high = score(GREEN, CFG, None)
    assert high["pass"] is True, high["score"]
    assert high["score"] >= 70

    weak = score({**GREEN, "volume_h1": 4000, "unique_buys_1": 12, "h1_change_pct": 195,
                  "unique_sells_5m": 30, "unique_buys_5m": 10}, CFG, None)
    assert weak["pass"] is False, weak["score"]
    assert weak["score"] < 70
    assert weak["reason"]


def test_min_score_boundary_is_inclusive():
    tight = {**CFG, "analyst": {**CFG["analyst"], "min_score": 100}}
    top = score(GREEN, tight, None)
    assert top["pass"] is False or top["score"] == 100
    loose = {**CFG, "analyst": {**CFG["analyst"], "min_score": 0}}
    assert score(GREEN, loose, None)["pass"] is True


def test_social_off_score_uses_4_parts_and_logs_it():
    s = score(GREEN, CFG, None)
    assert s["social"] is None
    assert s["score"] == round(100 * (s["alive"] + s["organic"] + s["flush"] + (1 - s["chase"])) / 4)
    from desk.bots.analyst import social_flag
    assert social_flag(CFG, None) == "social: off"


def test_social_weight_moves_the_score_no_more_than_its_share():
    a = score(GREEN, CFG, 0.0)["score"]
    b = score(GREEN, CFG, 1.0)["score"]
    assert b > a
    assert b - a <= round(100 * 0.5 / 4.5) + 1
