"""tests/test_links.py — STEP 15 test 1.

Every FOMO URL in the repo, the API responses, pushes, the Account tab and the Page must be
exactly what links.py returns. Also greps for a hand-built fomo.family URL.
"""

from __future__ import annotations

import pathlib
import re

import pytest

from desk import links

MOON = "MoonMint111111111111111111111111111111111111"
EXPECTED_COIN = (
    "https://fomo.family/coin?address=MoonMint111111111111111111111111111111111111"
    "&chainId=1399811149&r=savipww&source=share_link"
)
EXPECTED_PROFILE = "https://fomo.family/profile/savi?source=share_link&r=savipww"


def test_coin_url_exact():
    assert links.coin_url(MOON) == EXPECTED_COIN


def test_profile_url_exact_and_handle_cleanup():
    assert links.profile_url("savi") == EXPECTED_PROFILE
    assert links.profile_url("@savi") == EXPECTED_PROFILE


@pytest.mark.parametrize("chain,cid", [("solana", 1399811149), ("base", 8453), ("bnb", 56),
                                      ("robinhood", 4663)])
def test_chain_ids(chain, cid):
    assert f"chainId={cid}" in links.coin_url(MOON, chain)


def test_unknown_chain_falls_back_to_signup():
    assert links.coin_url(MOON, "dogechain") == links.SIGNUP_URL


def test_signup_url_is_the_referral():
    assert links.SIGNUP_URL == "https://fomo.family/r/savipww"


def test_no_other_module_builds_a_fomo_url():
    """Grep the package: fomo.family may only appear in links.py (prod-api is a host, not a link)."""
    root = pathlib.Path(__file__).resolve().parents[1]
    offenders = []
    for path in root.rglob("*.py"):
        if path.name == "links.py" or "tests" in path.parts:
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            if "prod-api.fomo.family" in line:
                continue          # the API base, never a link the owner clicks
            if "fomo.family" in line and "links." not in line and "SIGNUP_URL" not in line:
                offenders.append(f"{path.relative_to(root)}: {line.strip()}")
    assert not offenders, "hand-built FOMO URLs:\n" + "\n".join(offenders)


def test_no_shorteners_anywhere():
    root = pathlib.Path(__file__).resolve().parents[1]
    hits = []
    for path in list(root.rglob("*.py")) + list(root.rglob("*.js")) + \
            list(root.rglob("*.html")):
        if "tests" in path.parts:
            continue
        for i, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            # a real shortener URL always has a path after the host, e.g. t.co/abc
            if re.search(r"(t\.co|bit\.ly|tinyurl\.com|goo\.gl)/[A-Za-z0-9]", line):
                hits.append(f"{path.name}:{i}")
    assert not hits, f"shortener references: {hits}"


def test_app_js_contains_no_link_outside_links_py():
    app = (pathlib.Path(__file__).resolve().parents[1] / "web" / "app.js").read_text(
        encoding="utf-8")
    urls = set(re.findall(r"https://[A-Za-z0-9.\-/]+", app))
    assert urls <= {"https://fomo.family/r/savipww"}, urls


def test_browser_lane_refuses_a_hand_built_url():
    from desk import browser
    with pytest.raises(browser.LaneBlocked):
        browser.require_fomo_url("https://fomo.family/coin?address=" + MOON)
    with pytest.raises(browser.LaneBlocked):
        browser.require_fomo_url("https://fomo.family/coin?address=" + MOON +
                                 "&chainId=1399811149&source=share_link")
    browser.require_fomo_url(links.coin_url(MOON))     # does not raise
