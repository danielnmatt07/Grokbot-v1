"""tests/test_metrics.py — STEP 15 test 10/11 extras that do not need a browser.

The nine live trades, the fake-ring lowering of social, and the settings round trip that the
Account tab drives.
"""

from __future__ import annotations

import pytest

from desk.social import value_from

SOCIAL = {"social": {"social_weight": 0.5, "social_max_per_h": 20,
                     "social_timeout_s": 120, "shill_cut": 0.5}}


def test_social_plan_c_is_null():
    assert value_from({}, SOCIAL)["social"] is None


def test_social_value_with_a_catalyst_and_smart_money():
    raw = {"u15": 24, "u60": 40, "big": 4, "shill": 0.0, "catalyst": "a news mention",
           "coinX": {"age_days": 20, "replies": 6}, "smart": 3}
    v = value_from(raw, SOCIAL)
    assert v["social"] == 1.0, v
    assert v["ring"] is False


def test_fake_ring_lowers_the_value():
    clean = value_from({"u15": 20, "u60": 20, "big": 3, "shill": 0.0, "smart": 2}, SOCIAL)
    ring = value_from({"u15": 20, "u60": 20, "big": 3, "shill": 0.7, "smart": 2}, SOCIAL)
    assert ring["social"] < clean["social"]
    assert ring["ring"] is True


def test_fading_trend_is_halved():
    hot = value_from({"u15": 20, "u60": 20, "big": 0, "shill": 0, "smart": 0}, SOCIAL)
    cold = value_from({"u15": 5, "u60": 100, "big": 0, "shill": 0, "smart": 0}, SOCIAL)
    assert cold["social"] < hot["social"]


def test_unknown_x_fields_are_null_not_zero():
    v = value_from({"u15": None, "u60": None}, SOCIAL)
    assert v["social"] is None


def test_settings_round_trip_and_change_log():
    from desk.main import Desk
    desk = Desk(db_path=":memory:", selftest=True)
    res = desk.cfg.set("stop_pct", 20, who="owner")
    assert res["old"] == 25 and res["new"] == 20
    row = desk.db.one("SELECT * FROM change_log ORDER BY id DESC LIMIT 1")
    assert row["key"] == "stop_pct" and row["who"] == "owner"
    with pytest.raises(ValueError):
        desk.cfg.set("stop_pct", 99)


def test_set_command_parsing():
    from desk.config import parse_set_command
    assert parse_set_command("set stop to -20%") == ("stop_pct", "-20")
    assert parse_set_command("set max ticket to $25") == ("max_ticket_usd", "$25")
    assert parse_set_command("status") is None


def test_risk_cannot_be_paused_with_a_position_open():
    from desk.main import Desk
    desk = Desk(db_path=":memory:", selftest=True)
    assert desk.pause_bot("Risk", True) is None        # nothing open, allowed
    desk.pause_bot("Risk", False)
    desk.db.exec("INSERT INTO positions (mint, opened_at, entry_price, size_usd, tokens, mode) "
                 "VALUES ('M','2026-11-23T22:00:00.000Z',1.0,2.0,2.0,'PAPER')")
    err = desk.pause_bot("Risk", True)
    assert err and "cannot be paused" in err
