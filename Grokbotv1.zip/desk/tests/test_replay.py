"""tests/test_replay.py — STEP 15 test 8 and 11.

The replay runs every fixture through the real Scanner, Analyst, Brain, Executor settle path
and Risk rules with no network, and asserts one log line per rule.
"""

from __future__ import annotations

import pytest

from desk.main import Desk
from desk.replay import run_paper_replay


@pytest.fixture(scope="module")
def replay():
    desk = Desk(db_path=":memory:", selftest=True)
    lines = []
    ok = run_paper_replay(desk, verbose=False)
    return desk, ok


def test_replay_completes(replay):
    desk, ok = replay
    assert ok is True


def test_one_position_per_mint(replay):
    desk, _ = replay
    dup = desk.db.scalar(
        "SELECT COUNT(*) FROM (SELECT mint, COUNT(*) c FROM positions WHERE closed_at IS NULL "
        "GROUP BY mint HAVING c > 1)", default=0)
    assert dup == 0


def test_orders_were_recorded(replay):
    desk, _ = replay
    assert desk.db.scalar("SELECT COUNT(*) FROM orders WHERE side='buy'", default=0) >= 1
    assert desk.db.scalar("SELECT COUNT(*) FROM prices", default=0) >= 1


def test_scanner_kills_one_per_rule(replay):
    desk, _ = replay
    import json
    scans = {s["mint"]: s for s in desk.db.q("SELECT * FROM scans")}
    reasons = {}
    for mint, s in scans.items():
        coin = desk.db.one("SELECT symbol FROM coins WHERE mint=?", (mint,))
        reasons[coin["symbol"] if coin else mint] = s["reason"]
    assert any("liq $" in (r or "") for r in reasons.values()), reasons
    assert any("selling off" in (r or "") for r in reasons.values()), reasons
    assert any("holders leaving" in (r or "") for r in reasons.values()), reasons
    assert any("copycat" in (r or "") for r in reasons.values()), reasons
    # the coin that ran with the same symbol is not a copycat of itself
    assert reasons.get("MOON") is None, reasons


def test_thin_and_trap_are_the_documented_strings(replay):
    desk, _ = replay
    coins = {r["symbol"]: r["mint"] for r in desk.db.q("SELECT mint, symbol FROM coins")}
    thin = desk.db.one("SELECT reason FROM scans WHERE mint=?", (coins["THIN"],))
    assert thin["reason"].startswith("liq $")
    trap = desk.db.one("SELECT reason FROM scans WHERE mint=?", (coins["TRAP"],))
    assert trap["reason"] == "FOMO: selling off"


def test_analyst_red_layers(replay):
    desk, _ = replay
    rows = desk.db.q("SELECT * FROM audits WHERE pass=0")
    values = [r["value_text"] for r in rows]
    assert any("insider" in v for v in values)
    assert any("rugged" in v for v in values)
    assert any("no data" not in v for v in values)


def test_fresh_and_curve_halve_organic(replay):
    desk, _ = replay
    import json
    rows = desk.db.q("SELECT * FROM decisions WHERE bot='analyst'")
    for r in rows:
        d = json.loads(r["data"])
        if d.get("symbol") == "SNIPE":
            # 4-minute curve and 60% fresh wallets: organic is quartered or better
            assert d.get("score") is not None
