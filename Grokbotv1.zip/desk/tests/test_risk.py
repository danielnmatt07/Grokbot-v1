"""tests/test_risk.py — STEP 15 test 4.

-25.1% = stop; 2.0x = sell 50%; then 40% off the top = sell the rest; 3h at +4% = timeout;
a looser stop setting never moves an open stop down. Dip: waits at the high, waits while
sellers run, buys when buyers are back, skips "no dip".
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from desk.bots.executor import dip_state, high10, take_profit
from desk.bots.risk import check, stop_line, tighten

RISK = {"stop_pct": 25, "timeout_h": 3, "timeout_min_gain_pct": 5}
EXEC = {"dip_pct": 15, "dip_window_min": 10, "crash_pct": 35, "tp_x": 2.0,
        "tp_sell_pct": 50, "trail_pct": 40, "flush_sell_ratio": 1.5}


def pos(entry=1.0, opened="2026-11-23T22:00:00.000Z", stop=None):
    return {"entry_price": entry, "opened_at": opened, "stop_price": stop or entry * 0.75,
            "peak_price": entry, "tp_done": 0, "trail_active": 0, "mint": "M"}


def test_stop_at_25_1_percent():
    ex = check(pos(), 0.749, "", RISK)
    assert ex and ex["reason"] == "stop" and ex["pct"] == 100


def test_no_stop_at_24_percent():
    assert check(pos(), 0.76, "", RISK) is None


def test_take_profit_half_at_2x():
    tp = take_profit(1.0, 2.0, 2.0, False, False, EXEC)
    assert tp == (50, "take profit")


def test_trail_sells_the_rest():
    assert take_profit(1.0, 2.4, 2.0, True, True, EXEC) is None       # 2.4 is off the 2.0 peak? no
    assert take_profit(1.0, 1.19, 2.0, True, True, EXEC) == (100, "trail")
    assert take_profit(1.0, 1.3, 2.0, True, True, EXEC) is None


def test_timeout_dead_money():
    old = (datetime.now(timezone.utc) - timedelta(hours=3, minutes=1)) \
        .strftime("%Y-%m-%dT%H:%M:%S.000Z")
    ex = check(pos(opened=old), 1.04, "", RISK)
    assert ex and ex["reason"] == "dead money"


def test_timeout_does_not_fire_on_a_winner():
    old = (datetime.now(timezone.utc) - timedelta(hours=4)) \
        .strftime("%Y-%m-%dT%H:%M:%S.000Z")
    assert check(pos(opened=old), 1.12, "", RISK) is None


def test_stop_never_moves_down():
    tight = tighten(0.80, 1.0, {"stop_pct": 25})
    assert tight == 0.80                              # keeps the tighter stop
    looser = tighten(0.80, 1.0, {"stop_pct": 40})     # a looser setting
    assert looser == 0.80                             # never moves down to 0.60


def test_plan_b_fires_at_22_percent():
    # 23% under entry: inside plan A's 25% stop, but plan B fires early
    got = check(pos(), 0.77, "", RISK, lane_plan="B")
    assert got and got["reason"] == "stop"
    # the same price does not trip plan A
    assert check(pos(), 0.77, "", RISK, lane_plan="A") is None


def test_pulled_liquidity():
    ex = check(pos(), 1.0, "", RISK, liquidity_usd=10, liquidity_prev=1000)
    assert ex and ex["reason"] == "pulled"


def test_dev_dumping_and_fomo_warns():
    assert check(pos(), 1.0, "", RISK, creator_balance=100,
                 creator_balance_at_buy=300)["reason"] == "dev dumping"
    assert check(pos(), 1.0, "", RISK, disable_selling=True)["reason"] == "FOMO warns"


def test_no_price_after_12_polls():
    ex = check(pos(), None, "", RISK, misses=12)
    assert ex and ex["reason"] == "no price"


# ---------------------------------------------------------------- dip entry
def test_dip_waits_at_the_high():
    assert dip_state(1.00, 1.00, EXEC, 5, 10)[0] == "wait"


def test_dip_waits_while_sellers_run():
    assert dip_state(0.85, 1.00, EXEC, 30, 10)[0] == "wait"


def test_dip_buys_when_buyers_back():
    assert dip_state(0.85, 1.00, EXEC, 9, 12)[0] == "buy"


def test_crash_is_not_a_dip():
    kind, why = dip_state(0.59, 1.00, EXEC, 5, 5)
    assert kind == "crash" and "crash" in why


def test_high10_uses_the_last_ten_minutes_only():
    now = datetime.now(timezone.utc)
    series = [
        ((now - timedelta(minutes=30)).strftime("%Y-%m-%dT%H:%M:%S.000Z"), 5.0),
        ((now - timedelta(minutes=4)).strftime("%Y-%m-%dT%H:%M:%S.000Z"), 1.2),
        ((now - timedelta(minutes=1)).strftime("%Y-%m-%dT%H:%M:%S.000Z"), 1.1),
    ]
    assert high10(series, 10) == 1.2


def test_no_dip_arrives_is_a_skip_not_a_buy():
    # price stayed at the high for the whole window: the executor skips
    assert dip_state(1.00, 1.00, EXEC, 1, 1)[0] == "wait"
