"""tests/test_secrets.py — STEP 15 test 7, run offline.

The browser bundle, logs and the repo must not contain the FOMO token, the Telegram token, the
VAPID private key or APP_TOKEN. The API answers 200 with the token and 401 without.
"""

from __future__ import annotations

import os
import pathlib

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[1]
WEB = ROOT / "web"


def test_web_bundle_has_no_secret_literals():
    forbidden = ("TELEGRAM_BOT_TOKEN", "VAPID_PRIVATE", "prod-api.fomo.family",
                 "Bearer ey", "PRIVATE_KEY", "-----BEGIN")
    hits = []
    for path in WEB.rglob("*"):
        if path.suffix not in (".js", ".html", ".json", ".css") or path.name == "sw.js":
            continue
        text = path.read_text(encoding="utf-8")
        for f in forbidden:
            if f in text:
                hits.append(f"{path.name}: {f}")
    assert not hits, hits


def test_web_never_receives_any_secret_value():
    """The desk token reaches the phone only as #t=...; no secret is baked into the bundle."""
    for path in WEB.rglob("*"):
        if path.suffix not in (".js", ".html", ".json", ".css"):
            continue
        text = path.read_text(encoding="utf-8")
        assert "TELEGRAM_BOT_TOKEN" not in text
        assert "process.env" not in text
        assert "fomo_api" not in text


def test_token_is_only_in_localstorage_not_indexeddb():
    app = (WEB / "app.js").read_text(encoding="utf-8")
    assert "localStorage.setItem('desk_token'" in app
    assert "indexedDB" not in app


def test_no_secret_in_repo_files():
    bad = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix not in (".py", ".ps1", ".md", ".txt", ".json"):
            continue
        if "tests" in path.parts or path.name == "requirements.txt":
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for marker in ("bot123456:", "-----BEGIN PRIVATE KEY-----"):
            if marker in text:
                bad.append(str(path.relative_to(ROOT)))
    assert not bad


def test_api_requires_the_token(monkeypatch):
    fastapi = pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient
    from desk.main import Desk, create_app

    monkeypatch.setenv("APP_TOKEN", "test-token-abc123")
    desk = Desk(db_path=":memory:", selftest=True)
    client = TestClient(create_app(desk))
    assert client.get("/api/state").status_code == 401
    assert client.get("/api/state", headers={"Authorization": "Bearer wrong"}).status_code == 401
    r = client.get("/api/state", headers={"Authorization": "Bearer test-token-abc123"})
    assert r.status_code == 200
    assert "balance" in r.json()


def test_api_refuses_live_without_confirmation(monkeypatch):
    pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient
    from desk.main import Desk, create_app

    monkeypatch.setenv("APP_TOKEN", "t")
    desk = Desk(db_path=":memory:", selftest=True)
    client = TestClient(create_app(desk))
    h = {"Authorization": "Bearer t"}
    r = client.post("/api/mode", json={"mode": "LIVE"}, headers=h)
    assert r.status_code in (409, 422)
    r = client.post("/api/mode", json={"mode": "LIVE", "confirm": "LIVE"}, headers=h)
    assert r.status_code == 409          # no PAPER night yet


def test_settings_validation_reports_the_range(monkeypatch):
    pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient
    from desk.main import Desk, create_app

    monkeypatch.setenv("APP_TOKEN", "t")
    desk = Desk(db_path=":memory:", selftest=True)
    client = TestClient(create_app(desk))
    h = {"Authorization": "Bearer t"}
    r = client.post("/api/settings", json={"key": "stop_pct", "value": 400}, headers=h)
    assert r.status_code == 422
    assert "at most" in r.json()["detail"]
    r = client.post("/api/settings", json={"key": "stop_pct", "value": 20}, headers=h)
    assert r.status_code == 200 and r.json()["new"] == 20
