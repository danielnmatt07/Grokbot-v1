"""tests/test_verify.py — STEP 15 test 6.

A fake "Bought" screen with no swap in the API must end "unverified", screenshot the failure
and never click that order a second time.
"""

from __future__ import annotations

import asyncio

from desk.verify import Checks, verify_click


def test_screen_only_is_unverified():
    calls = {"second": 0}

    async def screen():
        return True

    async def api_missing():
        return False

    async def chain():
        return False

    async def on_unverified():
        calls["second"] += 1

    ch = asyncio.run(verify_click(screen_state=screen, api_lookup=api_missing,
                                  chain_lookup=chain, timeout_s=0.05,
                                  on_unverified=on_unverified))
    assert ch.ok() is False
    assert ch.screen is True and ch.api is False and ch.chain is False
    assert calls["second"] == 1


def test_chain_na_needs_two_checks():
    async def yes():
        return True

    ch = asyncio.run(verify_click(screen_state=yes, api_lookup=yes, chain_lookup=None,
                                  timeout_s=0.05))
    assert ch.ok() is True and ch.chain_na is True


def test_all_three_ok():
    async def yes():
        return True

    ch = asyncio.run(verify_click(screen_state=yes, api_lookup=yes, chain_lookup=yes,
                                  timeout_s=0.05))
    assert ch.ok() is True
    assert ch.as_dict() == {"screen": True, "api": True, "chain": True}


def test_a_late_api_read_still_verifies():
    state = {"n": 0}

    async def screen():
        return True

    async def api():
        state["n"] += 1
        return state["n"] >= 2

    async def chain():
        return True

    ch = asyncio.run(verify_click(screen_state=screen, api_lookup=api, chain_lookup=chain,
                                  timeout_s=2.0))
    assert ch.ok() is True


def test_checks_dataclass_defaults():
    c = Checks()
    assert c.ok() is False
