"""verify.py — screen + API + chain check after every click (STEP 9).

All three, or two if chain is n/a. Wait up to verify_timeout_s. Screen says done but api or
chain do not: status "unverified", screenshot to logs/fail/, push, never click that order
again. The position follows the API's numbers, not the screen's.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Awaitable, Callable

log = logging.getLogger("verify")


@dataclass
class Checks:
    screen: bool = False
    api: bool = False
    chain: bool = False
    chain_na: bool = False
    detail: dict = field(default_factory=dict)

    def ok(self) -> bool:
        if self.chain_na:
            return self.screen and self.api
        return self.screen and self.api and self.chain

    def as_dict(self) -> dict:
        d = {"screen": self.screen, "api": self.api,
             "chain": "n/a" if self.chain_na else self.chain}
        d.update(self.detail)
        return d


async def wait_for(fn: Callable[[], Awaitable[bool]], timeout_s: float, interval: float = 1.0) -> bool:
    import asyncio
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_s
    while loop.time() < deadline:
        if await fn():
            return True
        await asyncio.sleep(interval)
    return False


async def verify_click(*, screen_state: Callable[[], Awaitable[bool]],
                       api_lookup: Callable[[], Awaitable[bool]],
                       chain_lookup: Callable[[], Awaitable[bool]] | None,
                       timeout_s: float, on_unverified: Callable[[], Awaitable[None]] | None = None,
                       shoot: Callable[[], Awaitable[str | None]] | None = None) -> Checks:
    ch = Checks(chain_na=chain_lookup is None)
    ch.screen = await wait_for(screen_state, timeout_s)
    ch.api = await wait_for(api_lookup, timeout_s)
    if chain_lookup is not None:
        ch.chain = await wait_for(chain_lookup, timeout_s)
    if not ch.ok() and on_unverified:
        await on_unverified()
    if not ch.ok() and shoot:
        path = await shoot()
        os.makedirs("logs/fail", exist_ok=True)
        ch.detail["shot"] = path
    return ch
