/* app.js — plain JS, no framework, no build step.

Talks to /api/* with the APP_TOKEN from the URL fragment (#t=...) or localStorage.
Every screen has loading, empty and error states; the last good numbers are kept on error.
*/

(() => {
  'use strict';

  // ------------------------------------------------------------- token + modes
  const params = new URLSearchParams(location.hash.replace(/^#/, ''));
  let TOKEN = params.get('t') || localStorage.getItem('desk_token') || '';
  if (params.get('t')) {
    localStorage.setItem('desk_token', params.get('t'));
    history.replaceState(null, '', location.pathname);
  }
  let DATA_PATH = params.get('d') || localStorage.getItem('desk_dp') || '';
  if (params.get('d')) { localStorage.setItem('desk_dp', params.get('d')); }
  const FILE_MODE = !TOKEN && !!DATA_PATH;      // plan B: poll state files
  const POLL_MS = FILE_MODE ? 15000 : 1000;

  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));

  const state = {
    data: null, chart: null, activity: [], before: null, screenUrl: null,
    settings: null, specs: null, screenIndex: 0
  };
  // decisions are fetched separately from /api/state, so they are cached here; a re-render of
  // the bot cards (pause switch polling, tab switch) reuses them instead of dropping them
  const decisions = {};


  function money(v) {
    if (v == null || !isFinite(v)) return '$0.00';
    const n = Math.abs(v);
    if (n >= 1000) return '$' + v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return '$' + v.toFixed(2);
  }
  function signed(v, digits = 2, suffix = '') {
    if (v == null || !isFinite(v)) return '0' + suffix;
    const s = v > 0 ? '+' : v < 0 ? '−' : '';
    return s + Math.abs(v).toFixed(digits) + suffix;
  }
  function pct(v) { return signed(v, 2, '%'); }
  function time(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  }
  function ago(iso) {
    if (!iso) return '';
    const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
    if (s < 60) return Math.round(s) + 's ago';
    if (s < 3600) return Math.round(s / 60) + 'm ago';
    return Math.round(s / 3600) + 'h ago';
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // ------------------------------------------------------------- api
  let tokenRecovered = false;
  async function api(path, opts = {}) {
    if (FILE_MODE) return fileApi(path, opts);
    const send = (tok) => fetch('/api' + path, {
      ...opts,
      headers: { 'Authorization': 'Bearer ' + tok, 'Content-Type': 'application/json', ...(opts.headers || {}) }
    });
    let res = await send(TOKEN);
    // The published preview shell answers to the token "preview"; a phone that opened the
    // bare link (no #t=...) has an empty or stale token and would otherwise sit on a 401.
    // Retry once with it: the real desk rejects it, so this cannot unlock anything real.
    if (res.status === 401 && !tokenRecovered && TOKEN !== 'preview' && !FILE_MODE) {
      tokenRecovered = true;
      const probe = await send('preview');
      if (probe.ok) {
        TOKEN = 'preview';
        localStorage.setItem('desk_token', TOKEN);
        clearError();
        res = probe;
      }
    }
    if (res.status === 401) {
      showError(TOKEN ? 'Desk token rejected. Open the link from your desk again.'
                       : 'No desk token in this link');
      throw new Error('401');
    }
    if (!res.ok) {
      // carry the desk's own reason through, so a refused action can say why
      let err = new Error('HTTP ' + res.status);
      try { const body = await res.json(); if (body && body.detail) err.detail = body.detail; } catch (_) {}
      throw err;
    }
    return res.json();
  }

  async function fileApi(path, opts = {}) {
    const base = '/d/' + DATA_PATH;
    let file = null;
    if (path.startsWith('/state')) file = 'state.json';
    else if (path.startsWith('/chart')) file = 'chart.json';
    else if (path.startsWith('/activity')) file = 'activity.json';
    else if (path.startsWith('/coin/')) file = 'coin/' + path.split('/')[2] + '.json';
    else if (path.startsWith('/audit/')) file = 'coin/' + path.split('/')[2] + '.json';
    else if (path.startsWith('/screen.jpg')) return base + '/screen.jpg';
    else throw new Error('not available in file mode: ' + path);
    const r = await fetch(base + '/' + file, { cache: 'no-store' });
    if (r.status === 404) throw new Error('404');
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  // ------------------------------------------------------------- error strip
  let errorTimer = null;
  function showError(msg) {
    const bar = $('#errorbar');
    bar.hidden = false;
    const n = 5;
    let left = n;
    const paint = () => {
      bar.textContent = `${msg} · retrying in ${left}s · last update ${state.data ? time(state.data.ts) : '—'}`;
    };
    paint();
    clearInterval(errorTimer);
    errorTimer = setInterval(() => {
      left -= 1;
      if (left <= 0) { left = n; }
      paint();
    }, 1000);
  }
  function clearError() { $('#errorbar').hidden = true; clearInterval(errorTimer); }

  // ------------------------------------------------------------- navigation
  let currentTab = 'home';
  function go(tab) {
    currentTab = tab;
    $$('.screen').forEach(s => s.classList.toggle('is-on', s.dataset.screen === tab));
    $$('.tabbar button').forEach(b => b.classList.toggle('is-on', b.dataset.goto === tab));
    if (tab === 'home') {
      if (state.data) renderBots(state.data.bots || [], $('#botCarousel'), true);
      requestAnimationFrame(drawMain);
    }
    if (tab === 'bots') loadBots();
    if (tab === 'activity') loadActivity(true);
    if (tab === 'account') loadAccount();
    window.scrollTo({ top: 0 });
  }
  // one delegated handler for every [data-goto]; binding per element plus the tab-bar loop
  // double-fired go(), which loaded Activity twice and appended every row twice
  $$('.tabbar button').forEach(b => b.classList.toggle('is-on', b.dataset.goto === 'home'));
  document.addEventListener('click', e => {
    const nav = e.target.closest('[data-goto]');
    if (nav && nav.dataset.goto) { go(nav.dataset.goto); return; }
    const back = e.target.closest('[data-back]');
    if (back) go(currentTab === 'coin' || currentTab === 'audit' ? 'activity' : 'home');
  });

  // ------------------------------------------------------------- home
  let lastBalance = null;
  let homeActivitySig = '';
  function roll(text) {
    const el = $('#balance');
    if (el.textContent === text) return;
    el.classList.remove('roll');
    el.innerHTML = text.split('').map(c => `<span>${esc(c)}</span>`).join('');
    void el.offsetWidth;
    el.classList.add('roll');
  }

  function renderState(d) {
    state.data = d;
    clearError();
    const start = d.night_start_cash || d.balance;
    const todayPct = start ? ((d.balance - start) / start) * 100 : 0;
    if (lastBalance !== d.balance) {
      roll(money(d.balance));
      lastBalance = d.balance;
    }
    $('#todayPct').textContent = pct(todayPct);
    $('#todayPct').className = 'delta ' + (todayPct > 0 ? 'pos' : todayPct < 0 ? 'neg' : '');
    $('#todayUsd').textContent = signed(d.balance - start, 2).replace('−', '$−').replace('+', '$+') + ' today';
    const mult = start ? d.balance / start : 1;
    $('#multiplier').textContent = mult.toFixed(2) + '×';
    $('#paperBadge').hidden = d.mode !== 'PAPER';
    $('#acctCash').textContent = money(d.balance);
    const live = d.mode === 'LIVE';
    $$('#modeSeg button').forEach(b => b.classList.toggle('is-on', (b.dataset.mode === 'LIVE') === live));
    // only the Home tab owns the carousel; rebuilding it while another screen is open would
    // draw into hidden canvases (and used to throw, which blanked the Bots tab)
    if (currentTab === 'home') renderBots(d.bots || [], $('#botCarousel'), true);
    if (currentTab === 'bots') updateBotSwitches(d.bots || []);
    $('#botsRunning').textContent = (d.bots || []).filter(b => !b.paused).length;
    $('#lanePill').textContent = d.lane || 'Idle';
    if (d.lane_color) $('#lanePill').style.color = d.lane_color;
    const lo = d.last_order;
    if (lo) {
      $('#lastOrder').querySelector('.lo-text').textContent =
        `${lo.side === 'sell' ? 'Sold' : 'Bought'} ${lo.symbol || ''} · ${money(lo.usd || 0)} · ${lo.status}`;
      $('#lastChecks').innerHTML = ['screen', 'api', 'chain'].map(k => {
        const v = lo.checks ? lo.checks[k] : null;
        const cls = v === true ? 'ok' : v === false ? 'bad' : '';
        return `<span class="check ${cls}" title="${k}">${k[0].toUpperCase()}</span>`;
      }).join('');
    } else {
      $('#lastOrder').querySelector('.lo-text').textContent = 'No orders yet tonight';
      $('#lastChecks').innerHTML = '';
    }
    if (d.activity) {
      state.activity = d.activity;
      // the poll runs every second; re-rendering identical rows would swap the buttons under
      // the user's finger and make a tap miss, so only repaint when the rows actually change
      const sig = JSON.stringify(d.activity.slice(0, 5));
      if (sig !== homeActivitySig) {
        homeActivitySig = sig;
        renderActivity($('#homeActivity'), d.activity.slice(0, 5), false);
      }
    }
  }

  function botCard(b, carousel) {
    const color = b.color;
    const killed = b.killed;
    let body = '';
    if (b.name === 'Scanner') {
      body = `<div class="bot-big">${b.count}<span style="font-size:13px;color:var(--secondary);font-weight:500"> ${esc(b.unit || 'pools')}</span></div>
        <div class="bot-main ${killed ? 'strike' : ''}">${esc(killed ? (b.reason || 'killed') : (b.line || 'Watching PumpSwap'))}</div>
        <div class="bot-foot">${esc(killed ? (b.foot || 'cut') : (b.foot || 'feed live'))}</div>`;
    } else if (b.name === 'Analyst') {
      const strips = (b.layers || []).map(l =>
        `<i class="strip ${l === 1 ? 'ok' : l === 0 ? 'bad' : 'grey'}"></i>`).join('');
      body = `<div class="ring-wrap">
          <canvas class="ring" id="ring-${carousel ? 'c' : 'f'}"></canvas>
          <div><div class="bot-big" style="font-size:19px">${esc(b.line || '8 layers')}</div>
          <div class="bot-main" style="flex:none">${esc(b.foot || '')}</div></div></div>
        <div class="strips">${strips || '<i class="strip grey"></i>'.repeat(8)}</div>`;
    } else if (b.name === 'Brain') {
      body = `<div class="bot-big">${esc(b.line || '—')}</div>
        <div class="bot-main">${esc(b.foot || '')}</div>
        <div class="bar"><i style="width:${Math.min(100, b.bar || 0)}%;background:${color}"></i></div>`;
    } else if (b.name === 'Executor') {
      body = `<div class="bot-big">${b.count}<span style="font-size:13px;color:var(--secondary);font-weight:500"> ${esc(b.unit || 'trades')}</span></div>
        <div class="bot-main">${esc(b.line || 'Waiting for a dip')}</div>
        <div class="bar"><i style="width:${Math.min(100, b.bar || 0)}%;background:${color}"></i></div>
        <div class="bot-foot">${esc(b.foot || '')}</div>`;
    } else {
      body = `<div class="bot-big">${esc(b.line || 'Guarding')}</div>
        <div class="pills">
          <span class="pill red">stop −${b.stop || 25}%</span>
          <span class="pill green">trail ${b.trail || 40}%</span>
        </div>`;
    }
    if (carousel) {
      return `<article class="bot-card ${killed ? 'killed' : ''}">
        <div class="bot-head"><i class="bot-dot" style="background:${color}"></i>
          <span class="bot-name">${esc(b.name)}</span>
          <span class="bot-count">${esc(b.countLabel || '')}</span></div>
        ${body}</article>`;
    }
    const rows = (b.decisions || decisions[b.name] || []).slice(0, 20);
    const db = rows.map(d =>
      `<div class="decision"><b>${esc(d.head)}</b><span>${esc(d.text)}</span>
        <span class="t">${esc(time(d.ts))}</span></div>`).join('');
    const locked = b.name === 'Risk' && b.locked;
    return `<article class="bot-full">
      <div class="bot-full-head"><i class="bot-dot" style="background:${color}"></i>
        <span class="bot-name">${esc(b.name)}</span>
        <span class="bot-count">${esc(b.countLabel || '')}</span>
        <button class="switch ${b.paused ? '' : 'on'}" data-bot="${esc(b.name)}"
          ${locked ? 'disabled' : ''} aria-label="Pause ${esc(b.name)}"></button></div>
      <div style="margin-top:10px">${body}</div>
      <div class="decisions">${db || `<div class="decision empty-row"><span>No decisions yet</span></div>`}</div>
    </article>`;
  }

  function renderBots(bots, host, carousel) {
    if (!host) return;
    host.innerHTML = bots.map(b => botCard(b, carousel)).join('');
    if (carousel) {
      const a = bots.find(b => b.name === 'Analyst');
      const ring = document.getElementById('ring-c');
      if (a && ring) Desk.ring(ring, a.score || 0, a.score >= 70 ? '#00d35a' : '#ff9f0a');
    }
    host.querySelectorAll('.switch').forEach(sw => {
      sw.addEventListener('click', async () => {
        if (sw.disabled) return;
        const name = sw.dataset.bot;
        const on = sw.classList.contains('on');
        try {
          await api(`/bots/${encodeURIComponent(name.toLowerCase())}/${on ? 'pause' : 'resume'}`, { method: 'POST' });
          sw.classList.toggle('on');
          // keep the cached state in step so the next poll does not flip the switch back
          const b = (state.data && (state.data.bots || []).find(x => x.name === name));
          if (b) b.paused = on;
        } catch (e) {
          toast(e && e.detail ? e.detail : 'Could not reach the desk');
        }
      });
    });
  }

  function renderActivity(host, rows, full) {
    if (!host) return;
    if (!rows.length) { host.innerHTML = `<div class="empty">Nothing yet tonight</div>`; return; }
    host.innerHTML = rows.map(r => {
      const kind = r.kind || '';
      const pos = /^[+]/.test(r.value || '');
      const neg = /^-|^−/.test(r.value || '');
      const valCls = pos ? 'pos' : neg ? 'neg' : 'muted';
      const icon = ['bought', 'sold', 'stopped', 'rejected'].includes(kind) ? '✓' : '·';
      return `<button class="row" data-act="${esc(kind)}" data-mint="${esc(r.mint || '')}">
        <span class="coin-badge">${esc(icon)}</span>
        <span class="row-main"><span class="row-title">${esc(r.title)}</span>
          <span class="row-sub">${esc(r.subtitle)}</span></span>
        <span class="row-value ${valCls}">${esc(r.value)}</span></button>`;
    }).join('');
    host.querySelectorAll('.row').forEach(row => {
      row.addEventListener('click', () => {
        const mint = row.dataset.mint;
        if (!mint) return;
        if (row.dataset.act === 'rejected') openAudit(mint);
        else openCoin(mint);
      });
    });
  }

  async function loadHome() {
    if (!state.data && !FILE_MODE) {
      $('#homeActivity').innerHTML = '<div class="skel" style="height:58px"></div>';
    }
    try {
      const d = await api('/state');
      renderState(d);
      await loadChart();
      await tickScreen();
    } catch (e) {
      showError('Desk offline' + (e && e.message ? ' (' + e.message + ')' : ''));
    }
  }

  // ------------------------------------------------------------- chart
  let currentRange = 'LIVE';
  function drawMain() {
    const c = $('#mainChart');
    if (!c || !state.chart) return;
    const points = state.chart.points || [];
    const marks = (state.chart.marks || []).map(m => ({
      index: m.index, text: m.text, color: m.color || '#0a84ff'
    }));
    Desk.line(c, points, { startValue: state.chart.start, marks });
  }
  async function loadChart() {
    try {
      state.chart = await api('/chart?range=' + currentRange);
      if (currentTab === 'home') drawMain();
    } catch (e) { /* keep the last chart */ }
  }
  $('#ranges').addEventListener('click', e => {
    const b = e.target.closest('.range');
    if (!b) return;
    $$('#ranges .range').forEach(r => r.classList.toggle('is-on', r === b));
    currentRange = b.dataset.range;
    loadChart();
  });
  window.addEventListener('resize', () => { drawMain(); });

  // ------------------------------------------------------------- live screen
  const screenImg = new Image();
  let screenLoaded = false;
  let lastFrameAt = 0;
  screenImg.onload = () => {
    screenLoaded = true;
    lastFrameAt = Date.now();
    const canvas = $('#screenCanvas');
    Desk.drawFrame(canvas, screenImg);
    $('#screenEmpty').style.display = 'none';
    const fresh = Date.now() - lastFrameAt < 5000;
    const pill = $('#livePill');
    pill.classList.toggle('stale', !fresh);
    pill.innerHTML = fresh ? '<i></i>Live · Bot\'s computer'
      : '<i></i>Last frame ' + new Date(lastFrameAt).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  };
  function tickScreen() {
    // double buffered: the Image loads off-screen, the canvas swaps only on load
    const base = FILE_MODE ? '/d/' + DATA_PATH + '/screen.jpg' : '/api/screen.jpg';
    const src = base + '?i=' + Date.now();
    if (!FILE_MODE) {
      fetch(base + '?i=' + Date.now(), { headers: { 'Authorization': 'Bearer ' + TOKEN }, cache: 'no-store' })
        .then(r => (r.ok ? r.blob() : null))
        .then(b => { if (b) screenImg.src = URL.createObjectURL(b); })
        .catch(() => {});
    } else {
      screenImg.src = src;
    }
  }
  $('#expandScreen').addEventListener('click', () => {
    const fs = $('#fullscreen');
    fs.hidden = false;
    const c = $('#fsCanvas');
    if (screenLoaded) Desk.drawFrame(c, screenImg);
    const mint = state.data && state.data.screen_mint;
    const a = $('#fsOpen');
    if (mint && state.data.coin_links && state.data.coin_links[mint]) a.href = state.data.coin_links[mint];
    else a.style.display = 'none';
  });
  $('#fsClose').addEventListener('click', () => { $('#fullscreen').hidden = true; });

  // ------------------------------------------------------------- activity tab
  async function loadActivity(reset) {
    const host = $('#activityList');
    if (reset) { state.activity = []; state.before = null; }
    try {
      const q = state.before ? '?before=' + encodeURIComponent(state.before) : '';
      const d = await api('/activity' + q);
      const rows = d.rows || d || [];
      state.activity = state.activity.concat(rows);
      if (rows.length) state.before = rows[rows.length - 1].ts;
      renderActivity(host, state.activity, true);
      $('#activityFoot').innerHTML = rows.length >= 30
        ? '<button id="moreBtn">Load more</button>' : '';
      const more = $('#moreBtn');
      if (more) more.addEventListener('click', () => loadActivity(false));
    } catch (e) {
      showError('Desk offline');
      if (!state.activity.length) host.innerHTML = '<div class="empty">Nothing yet tonight</div>';
    }
  }

  // keep the switches and counts fresh without rebuilding the cards (that would drop the
  // decision lists that load after the first paint)
  function updateBotSwitches(bots) {
    const cards = $$('#botsList .bot-full');
    if (cards.length !== bots.length) { renderBots(bots, $('#botsList'), false); return; }
    bots.forEach((b, i) => {
      const card = cards[i];
      const sw = card.querySelector('.switch');
      if (!sw) return;
      // Risk is refused while a position is open: the switch is disabled, never silently flipped
      const locked = b.name === 'Risk' && !!b.locked;
      if (sw.disabled !== locked) sw.disabled = locked;
      if (!locked) sw.classList.toggle('on', !b.paused);
    });
  }

  async function loadBots() {
    try {
      const d = await api('/state');
      renderState(d);
      const bots = d.bots || [];
      renderBots(bots, $('#botsList'), false);
      // fetch each bot's history and paint it into its own card; failures never blank the list
      bots.forEach(b => fetchDecisions(b.name));
    } catch (e) {
      console.error('loadBots failed', e);
      showError('Desk offline' + (e && e.message ? ' (' + e.message + ')' : ''));
      const host = $('#botsList');
      if (host && !host.children.length) {
        host.innerHTML = '<div class="empty">Could not load the bots. Retrying every second.</div>';
      }
    }
  }

  async function fetchDecisions(name) {
    try {
      const dec = await api(`/bots/${encodeURIComponent(name.toLowerCase())}/decisions`);
      const rows = (dec.rows || []).slice(0, 20);
      decisions[name] = rows;
      if (currentTab !== 'bots') return;
      const card = $$('#botsList .bot-full').find(c =>
        c.querySelector('.bot-name') && c.querySelector('.bot-name').textContent === name);
      if (!card) return;
      const box = card.querySelector('.decisions');
      if (box) {
        box.innerHTML = rows.length ? rows.map(decisionRowText).join('')
          : '<div class="decision empty-row"><span>No decisions yet</span></div>';
      }
    } catch (e) { /* leave whatever the card already shows */ }
  }

  function decisionRowText(r) {
    return `<div class="decision"><b>${esc(r.head)}</b><span>${esc(r.text)}</span>
      <span class="t">${esc(time(r.ts))}</span></div>`;
  }

  // ------------------------------------------------------------- coin + audit
  async function openCoin(mint) {
    go('coin');
    const host = $('#coinBody');
    host.innerHTML = '<div class="skel" style="height:220px"></div>';
    try {
      const d = await api('/coin/' + mint);
      host.innerHTML = coinHtml(d);
      wireCoin(d);
    } catch (e) {
      host.innerHTML = '<div class="empty">Could not load this coin.</div>';
    }
  }

  function coinHtml(d) {
    const c = d.coin || d;
    const pos = d.position;
    const since = pos && pos.entry_price ? ((d.price - pos.entry_price) / pos.entry_price) * 100 : null;
    const shield = c.layers_passed != null
      ? `<span class="shield ${c.layers_passed === 8 ? '' : 'bad'}">${c.layers_passed}/8</span>` : '';
    return `
      <div class="coin-head">
        <div><div class="coin-name">${esc(c.name || c.symbol || 'Coin')}</div>
          <div class="coin-meta">${esc((c.symbol || '') + ' · Solana · ' + (c.age_text || ''))}</div></div>
        ${shield}
      </div>
      <div class="coin-price">${priceText(d.price)}</div>
      ${since != null ? `<div class="coin-since ${since >= 0 ? 'pos' : 'neg'}">${since >= 0 ? '▲' : '▼'} ${Math.abs(since).toFixed(1)}% since entry</div>` : ''}
      <canvas class="candles" id="coinCandles"></canvas>
      <div class="stats">
        <div class="stat"><div class="stat-k">Market cap</div><div class="stat-v">${shortMoney(c.market_cap)}</div></div>
        <div class="stat"><div class="stat-k">Liquidity</div><div class="stat-v">${shortMoney(c.liquidity_usd)}</div></div>
        <div class="stat"><div class="stat-k">Holders</div><div class="stat-v">${c.holders != null ? Number(c.holders).toLocaleString() : '—'}</div></div>
      </div>
      ${pos ? `<div class="pos-card">
        <div class="pos-row"><span>Your position · ${money(pos.size_usd)} in · ${esc(pos.owner || 'Executor')}</span>
          <b class="${(pos.pnl_pct || 0) >= 0 ? 'pos' : 'neg'}">${pct(pos.pnl_pct || 0)}</b></div>
        <div class="pos-row"><span>Peak</span><b>${priceText(pos.peak_price)}</b></div>
        <div class="pos-row"><span>Stop</span><b>${priceText(pos.stop_price)}</b></div>
      </div>` : ''}
      <div class="btn-row">
        <a class="btn secondary" href="${esc(d.link || '#')}" target="_blank" rel="noopener">Open on FOMO</a>
        <button class="btn danger" id="sellNow" ${pos ? '' : 'disabled'}>Sell now</button>
      </div>`;
  }

  function priceText(p) {
    if (p == null || !isFinite(p)) return '—';
    if (p >= 1) return '$' + p.toFixed(2);
    if (p >= 0.01) return '$' + p.toFixed(4);
    return '$' + p.toPrecision(4);
  }
  function shortMoney(v) {
    if (v == null || !isFinite(v)) return '—';
    if (v >= 1e6) return '$' + (v / 1e6).toFixed(2) + 'M';
    if (v >= 1e3) return '$' + (v / 1e3).toFixed(1) + 'K';
    return '$' + v.toFixed(0);
  }

  function wireCoin(d) {
    const cv = $('#coinCandles');
    if (cv) Desk.candles(cv, d.candles || [], { exitLine: d.position ? d.position.stop_price : null });
    const sell = $('#sellNow');
    if (sell) sell.addEventListener('click', () => sellSheet(d.coin ? d.coin.mint : '', d.coin ? d.coin.symbol : ''));
  }

  let sheetMint = null;
  function sellSheet(mint, symbol) {
    sheetMint = mint;
    openSheet(`<div class="sheet-title">Sell ${esc(symbol || '')} · Executor clicks it, verified</div>
      ${[25, 50, 100].map(p => `<button class="sheet-opt" data-pct="${p}"><span>${p}%</span>
        <span style="color:var(--secondary)">${p === 100 ? 'All' : ''}</span></button>`).join('')}`);
    $$('#sheetBody .sheet-opt').forEach(b => b.addEventListener('click', () => {
      const p = Number(b.dataset.pct);
      openSheet(`<div class="sheet-title">Confirm</div>
        <div style="font-size:20px;font-weight:600;padding:8px 4px 18px">Sell ${p}% of ${esc(symbol || '')} now?</div>
        <div class="btn-row"><button class="btn secondary" id="sheetCancel">Cancel</button>
          <button class="btn danger" id="sheetGo">Confirm sell</button></div>`);
      $('#sheetCancel').addEventListener('click', closeSheet);
      $('#sheetGo').addEventListener('click', async () => {
        try {
          await api('/sell/' + mint, { method: 'POST', body: JSON.stringify({ pct: p, confirm: true }) });
          closeSheet();
          toast('Sell queued · Executor is on it');
        } catch (e) { toast('Could not queue the sell'); }
      });
    }));
  }

  // ------------------------------------------------------------- audit
  async function openAudit(mint) {
    go('audit');
    const host = $('#auditBody');
    host.innerHTML = '<div class="skel" style="height:180px"></div>';
    try {
      const d = await api('/audit/' + mint);
      const layers = d.layers || [];
      host.innerHTML = `
        <div class="coin-head"><div><div class="coin-name">${esc(d.symbol || d.mint.slice(0, 6))}</div>
          <div class="coin-meta">${esc(d.symbol || '')} · Solana · Audit</div></div>
          ${d.score != null ? `<span class="shield ${d.score >= 70 ? '' : 'bad'}">${Math.round(d.score)}</span>` : ''}</div>
        <div class="audit-discs">
          ${layers.map((l, i) => `
            <div class="disc ${l.pass === true ? 'ok' : l.pass === false && !l.not_checked ? 'bad' : 'grey'}">
              <span class="disc-n">${l.pass === true ? '✓' : l.pass === false && !l.not_checked ? '✕' : l.n}</span>
              <span class="disc-main"><span class="disc-name">${esc(l.name)}</span>
                <span class="disc-val">${esc(l.value || 'not checked')}</span></span>
            </div>
            ${i < layers.length - 1 && !l.not_checked ? '<div class="beam"></div>' : ''}`).join('')}
        </div>
        <div class="social-row">${esc(d.social_text || 'Social: off')}</div>`;
    } catch (e) {
      host.innerHTML = '<div class="empty">No audit for this coin.</div>';
    }
  }

  // ------------------------------------------------------------- account
  async function loadAccount() {
    try {
      const d = await api('/account');
      state.specs = d.specs; state.settings = d.settings;
      if (d.profile_url) $('#profileLink').href = d.profile_url;
      $('#acctCash').textContent = money(d.cash);
      renderSettings(d);
    } catch (e) { showError('Desk offline'); }
  }

  function renderSettings(d) {
    const host = $('#settingsGroups');
    const groups = {};
    (d.specs || []).forEach(s => { (groups[s.group] = groups[s.group] || []).push(s); });
    host.innerHTML = Object.entries(groups).map(([g, specs]) => `
      <h2 class="group-title">${esc(g)}</h2>
      <div class="card">${specs.map(s => {
        const val = d.settings[s.key];
        if (s.kind === 'bool') {
          return `<div class="setting"><div class="setting-main"><div class="setting-label">${esc(s.label)}</div></div>
            <button class="switch ${val ? 'on' : ''}" data-set="${esc(s.key)}"></button></div>`;
        }
        if (s.kind === 'enum') {
          return `<div class="setting"><div class="setting-main"><div class="setting-label">${esc(s.label)}</div>
            <div class="setting-range">${esc(s.choices.join(' / '))}</div></div>
            <span class="pill">${esc(val)}</span></div>`;
        }
        const input = s.kind === 'str'
          ? `<input type="text" data-set="${esc(s.key)}" value="${esc(val)}" style="width:150px">`
          : `<input type="number" data-set="${esc(s.key)}" value="${esc(val)}" step="any" inputmode="decimal">`;
        const slider = (s.kind === 'num' || s.kind === 'int') && s.min != null
          ? `<input type="range" data-range-for="${esc(s.key)}" min="${s.min}" max="${s.max}"
              step="${s.kind === 'int' ? 1 : 'any'}" value="${esc(val)}">` : '';
        return `<div class="setting"><div class="setting-main"><div class="setting-label">${esc(s.label)}${s.unit ? ' (' + esc(s.unit) + ')' : ''}</div>
          <div class="setting-range">${s.min != null ? esc(s.min) + ' – ' + esc(s.max) : ''}</div>${slider}</div>
          ${input}</div>`;
      }).join('')}</div>`).join('');

    host.querySelectorAll('input[type=range]').forEach(r => {
      r.addEventListener('input', () => {
        const key = r.dataset.rangeFor;
        const box = host.querySelector(`input[type=number][data-set="${key}"]`);
        if (box) box.value = r.value;
      });
      r.addEventListener('change', () => save(r.dataset.rangeFor, r.value));
    });
    host.querySelectorAll('input[type=number], input[type=text]').forEach(box => {
      box.addEventListener('change', () => save(box.dataset.set, box.value));
    });
    host.querySelectorAll('.switch[data-set]').forEach(sw => {
      sw.addEventListener('click', () => {
        const key = sw.dataset.set;
        save(key, !sw.classList.contains('on'));
        sw.classList.toggle('on');
      });
    });
  }

  async function save(key, value) {
    try {
      const r = await api('/settings', { method: 'POST', body: JSON.stringify({ key, value }) });
      toast(`${r.label || key} saved`);
    } catch (e) {
      let msg = 'Could not save that setting';
      if (e && e.detail) msg = e.detail;
      toast(msg);
      loadAccount();
    }
  }

  $('#modeSeg').addEventListener('click', async e => {
    const b = e.target.closest('button');
    if (!b) return;
    const mode = b.dataset.mode;
    if (mode === 'LIVE') {
      openSheet(`<div class="sheet-title">Switching to LIVE</div>
        <div style="padding:4px 4px 14px;font-size:13px;color:var(--secondary)">LIVE presses the real button. Needs one full PAPER night and every acceptance test passed.</div>
        <input id="liveConfirm" placeholder="Type LIVE" autocapitalize="characters"
          style="width:100%;min-height:46px;border-radius:12px;border:0;background:#2c2c2e;padding:0 12px;font-size:16px">
        <div class="btn-row" style="margin-top:12px"><button class="btn secondary" id="modeCancel">Cancel</button>
          <button class="btn danger" id="modeGo">Switch to LIVE</button></div>`);
      $('#modeCancel').addEventListener('click', closeSheet);
      $('#modeGo').addEventListener('click', async () => {
        const typed = $('#liveConfirm').value.trim();
        try {
          await api('/mode', { method: 'POST', body: JSON.stringify({ mode, confirm: typed }) });
          closeSheet(); toast('LIVE enabled'); loadHome();
        } catch (err) { toast('Refused: ' + (err.detail || 'check the confirm text')); }
      });
    } else {
      try { await api('/mode', { method: 'POST', body: JSON.stringify({ mode }) }); toast('PAPER mode'); }
      catch (err) { toast('Could not switch'); }
    }
  });

  $('#inviteBtn').addEventListener('click', async () => {
    const url = (state.data && state.data.signup_url) || 'https://fomo.family/r/savipww';
    if (navigator.share) {
      try { await navigator.share({ title: 'FOMO', url }); return; } catch (e) { /* fall through */ }
    }
    await copy(url); toast('Link copied');
  });
  $('#watchBtn').addEventListener('click', () => {
    const url = state.data && state.data.preview_url;
    if (url) window.open(url, '_blank'); else toast('Preview link comes from the desk');
  });
  $('#testPush').addEventListener('click', async () => {
    try { await api('/push', { method: 'POST', body: JSON.stringify({ test: true }) }); toast('Test push sent'); }
    catch (e) { toast('Push not sent'); }
  });
  $('#enablePush').addEventListener('click', async () => {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return toast('Web push not available here');
    try {
      const reg = await navigator.serviceWorker.register('sw.js');
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') return toast('Notifications not allowed');
      const key = state.data && state.data.vapid_public;
      if (!key) return toast('Pushes go through Telegram');
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlB64(key) });
      await api('/push', { method: 'POST', body: JSON.stringify(sub) });
      toast('Notifications on');
    } catch (e) { toast('Could not enable notifications'); }
  });

  function urlB64(s) {
    const pad = s + '='.repeat((4 - (s.length % 4)) % 4);
    const raw = atob(pad.replace(/-/g, '+').replace(/_/g, '/'));
    return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
  }
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); }
    catch (e) { const t = document.createElement('textarea'); t.value = text; document.body.append(t); t.select(); document.execCommand('copy'); t.remove(); }
  }

  // ------------------------------------------------------------- search
  $('#searchBtn').addEventListener('click', () => {
    $('#searchOverlay').hidden = false;
    $('#searchInput').focus();
    $('#searchResults').innerHTML = '';
  });
  $('#searchClose').addEventListener('click', () => { $('#searchOverlay').hidden = true; });
  $('#titleBtn').addEventListener('click', () => {
    $('#searchOverlay').hidden = false;
    $('#searchInput').focus();
  });
  // the header avatar is labelled "Account" but had no handler at all, so tapping it did
  // nothing; point it at the Account tab it names
  $('#avatar').addEventListener('click', () => go('account'));
  let searchTimer = null;
  $('#searchInput').addEventListener('input', e => {
    clearTimeout(searchTimer);
    const q = e.target.value.trim();
    if (q.length < 2) { $('#searchResults').innerHTML = ''; return; }
    searchTimer = setTimeout(async () => {
      try {
        const d = await api('/search?q=' + encodeURIComponent(q));
        const rows = d.rows || [];
        $('#searchResults').innerHTML = rows.length ? rows.map(r =>
          `<button class="row" data-mint="${esc(r.mint)}"><span class="coin-badge">${esc((r.symbol || '?').slice(0, 3))}</span>
            <span class="row-main"><span class="row-title">${esc(r.name || r.symbol)}</span>
            <span class="row-sub">${esc(r.symbol || '')} · ${esc(r.mint.slice(0, 8))}…</span></span></button>`).join('')
          : '<div class="empty">No match yet tonight</div>';
        $$('#searchResults .row').forEach(b => b.addEventListener('click', () => {
          $('#searchOverlay').hidden = true; openCoin(b.dataset.mint);
        }));
      } catch (err) { $('#searchResults').innerHTML = '<div class="empty">Search unavailable</div>'; }
    }, 220);
  });
  $('#searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') e.preventDefault(); });

  // ------------------------------------------------------------- sheets
  function openSheet(html) {
    $('#sheetBody').innerHTML = html;
    $('#scrim').hidden = false;
    $('#sheet').hidden = false;
  }
  function closeSheet() { $('#sheet').hidden = true; $('#scrim').hidden = true; }
  $('#scrim').addEventListener('click', closeSheet);
  let toastTimer = null;
  function toast(msg) {
    let el = $('#toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'toast';
      // pointer-events:none — the toast is informational only. It used to stay in the layout
      // at opacity 0 with pointer-events auto, so an invisible pill over the tab bar kept
      // swallowing taps long after the message had faded.
      el.style.cssText = 'position:fixed;left:50%;bottom:calc(84px + env(safe-area-inset-bottom));transform:translateX(-50%);background:#2c2c2e;color:#fff;padding:10px 16px;border-radius:999px;font-size:13px;z-index:70;transition:opacity 200ms;max-width:86vw;text-align:center;pointer-events:none';
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.style.opacity = '1';
    el.style.visibility = 'visible';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.style.opacity = '0'; el.style.visibility = 'hidden'; }, 2200);
  }

  // ------------------------------------------------------------- loop
  let tick = 0;
  async function loop() {
    await loadHome();
    if (currentTab === 'home') {
      tick += 1;
      if (tick % 15 === 0) loadChart();
    }
    if (FILE_MODE) tickScreen();
    setTimeout(loop, FILE_MODE ? POLL_MS : 1000);
  }

  function boot() {
    go('home');
    if (!TOKEN && !DATA_PATH) {
      // no token in the link: still try once. The published preview shell accepts the
      // literal "preview" token (api() retries with it); the real desk does not, so on the
      // laptop this just shows "No desk token in this link" as before.
      showError('No desk token in this link');
      $('#balance').textContent = '$0.00';
      loop();
      return;
    }
    loop();
  }
  document.addEventListener('DOMContentLoaded', boot);
  if (document.readyState !== 'loading') boot();

  window.__desk = { state, api, go };   // for the preview harness only
})();
