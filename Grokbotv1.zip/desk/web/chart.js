/* chart.js — hand-drawn canvas charts. DPR aware, no libraries. */

const Desk = (() => {
  const dpr = () => Math.min(window.devicePixelRatio || 1, 3);

  function fit(canvas) {
    const r = canvas.getBoundingClientRect();
    const d = dpr();
    const w = Math.max(1, Math.round(r.width * d));
    const h = Math.max(1, Math.round(r.height * d));
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w; canvas.height = h;
    }
    const ctx = canvas.getContext('2d');
    ctx.setTransform(d, 0, 0, d, 0, 0);
    return { ctx, w: r.width, h: r.height };
  }

  const COLORS = {
    green: '#00d35a', red: '#ff453a', blue: '#0a84ff', orange: '#ff9f0a',
    sep: 'rgba(84,84,88,0.55)', secondary: 'rgba(235,235,245,0.6)',
    tertiary: 'rgba(235,235,245,0.3)', white: '#fff'
  };

  function niceRange(min, max) {
    if (!isFinite(min) || !isFinite(max)) return [0, 1];
    if (max - min < 1e-9) { const p = Math.abs(max) * 0.05 || 1; return [min - p, max + p]; }
    const pad = (max - min) * 0.14;
    return [min - pad, max + pad];
  }

  /* ---- Home balance line, with marks. series: [{ts,value}], marks: [{index,text,color}] */
  function line(canvas, series, opts = {}) {
    const { ctx, w, h } = fit(canvas);
    ctx.clearRect(0, 0, w, h);
    const padL = 2, padR = 2, padT = 26, padB = 6;
    const vals = series.map(p => p.value);
    const [lo, hi] = niceRange(Math.min(...vals), Math.max(...vals));
    const X = i => padL + (series.length <= 1 ? 0 : (i / (series.length - 1)) * (w - padL - padR));
    const Y = v => padT + (1 - (v - lo) / (hi - lo)) * (h - padT - padB);

    if (series.length > 1) {
      const grad = ctx.createLinearGradient(0, padT, 0, h);
      grad.addColorStop(0, 'rgba(0,211,90,0.22)');
      grad.addColorStop(1, 'rgba(0,211,90,0)');
      ctx.beginPath();
      ctx.moveTo(X(0), h - padB);
      series.forEach((p, i) => ctx.lineTo(X(i), Y(p.value)));
      ctx.lineTo(X(series.length - 1), h - padB);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();

      ctx.beginPath();
      series.forEach((p, i) => (i ? ctx.lineTo : ctx.moveTo).call(ctx, X(i), Y(p.value)));
      ctx.strokeStyle = COLORS.green;
      ctx.lineWidth = 2;
      ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      ctx.stroke();

      const last = series[series.length - 1];
      ctx.beginPath();
      ctx.arc(X(series.length - 1), Y(last.value), 3, 0, Math.PI * 2);
      ctx.fillStyle = COLORS.green;
      ctx.fill();
    }

    // dashed start line
    if (opts.startValue != null && isFinite(opts.startValue)) {
      const y = Y(opts.startValue);
      if (y > padT - 1 && y < h - padB + 1) {
        ctx.save();
        ctx.setLineDash([3, 4]);
        ctx.strokeStyle = COLORS.tertiary;
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
        ctx.restore();
      }
    }

    // marks: a later mark moves up a row, never overlaps
    const marks = (opts.marks || []).slice(-8);
    ctx.font = '600 10px -apple-system, system-ui, sans-serif';
    ctx.textBaseline = 'middle';
    const placed = [];   // {x1,x2,row}
    marks.forEach(m => {
      const x = X(Math.min(Math.max(m.index, 0), series.length - 1));
      const tw = ctx.measureText(m.text).width;
      const w = tw + 10;
      let bx = Math.min(Math.max(x - w / 2, 1), w0() - w - 1);
      let row = 0;
      const hits = (r) => placed.some(p => p.row === r && bx < p.x2 + 4 && bx + w + 4 > p.x1);
      while (hits(row) && row < 4) row++;
      placed.push({ x1: bx, x2: bx + w, row });
      const y = 9 + row * 14;
      ctx.fillStyle = m.color;
      ctx.globalAlpha = 0.18;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(bx, y - 7.5, w, 15, 7.5);
      else ctx.rect(bx, y - 7.5, w, 15);
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.fillStyle = m.color;
      ctx.fillText(m.text, bx + 5, y + 0.5);
    });

    function w0() { return w; }
  }

  /* ---- coin candles from 1m prices */
  function candles(canvas, points, opts = {}) {
    const { ctx, w, h } = fit(canvas);
    ctx.clearRect(0, 0, w, h);
    if (!points.length) return;
    const padT = 8, padB = 14;
    const prices = points.map(p => p.price);
    const [lo, hi] = niceRange(Math.min(...prices), Math.max(...prices));
    const Y = v => padT + (1 - (v - lo) / (hi - lo)) * (h - padT - padB);
    const n = points.length;
    const slot = w / n;
    const bw = Math.max(1.5, Math.min(9, slot * 0.62));

    points.forEach((p, i) => {
      const x = i * slot + slot / 2;
      const o = p.open ?? p.price, c = p.price, hiP = p.high ?? p.price, loP = p.low ?? p.price;
      const up = c >= o;
      ctx.strokeStyle = up ? COLORS.green : COLORS.red;
      ctx.fillStyle = up ? COLORS.green : COLORS.red;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x, Y(hiP)); ctx.lineTo(x, Y(loP)); ctx.stroke();
      const top = Y(Math.max(o, c)), bot = Y(Math.min(o, c));
      const hh = Math.max(1, bot - top);
      ctx.globalAlpha = up ? 0.95 : 0.95;
      ctx.fillRect(x - bw / 2, top, bw, hh);
      ctx.globalAlpha = 1;
    });

    if (opts.exitLine != null && isFinite(opts.exitLine)) {
      const y = Y(opts.exitLine);
      // outside the visible range the line and its label would be clipped at the canvas edge
      if (y > padT + 10 && y < h - padB - 2) {
        ctx.save();
        ctx.setLineDash([4, 4]);
        ctx.strokeStyle = COLORS.orange;
        ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
        ctx.restore();
        ctx.font = '600 10px -apple-system, system-ui, sans-serif';
        ctx.fillStyle = COLORS.orange;
        ctx.textBaseline = 'bottom';
        ctx.fillText('exit', 4, y - 2);
      }
    }
    ctx.strokeStyle = COLORS.sep;
    ctx.lineWidth = 0.5;
    ctx.beginPath(); ctx.moveTo(0, h - padB + 0.5); ctx.lineTo(w, h - padB + 0.5); ctx.stroke();
  }

  /* ---- score ring 0-100 */
  function ring(canvas, value, color = COLORS.green) {
    const { ctx, w, h } = fit(canvas);
    ctx.clearRect(0, 0, w, h);
    // the Home carousel can be display:none while another tab is open, which reports a
    // zero (or sub-pixel) box; a negative arc radius would throw and abort the caller.
    if (w < 10 || h < 10) return;
    const cx = w / 2, cy = h / 2, r = Math.max(0, Math.min(w, h) / 2 - 4);
    if (r <= 0) return;
    ctx.lineWidth = 5; ctx.lineCap = 'round';
    ctx.strokeStyle = '#2c2c2e';
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = color;
    ctx.beginPath();
    ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + (Math.PI * 2 * Math.max(0, Math.min(100, value)) / 100));
    ctx.stroke();
    ctx.fillStyle = '#fff';
    ctx.font = '700 15px -apple-system, system-ui, sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(String(Math.round(value)), cx, cy + 0.5);
  }

  function drawFrame(canvas, img) {
    const d = dpr();
    const r = canvas.getBoundingClientRect();
    canvas.width = Math.round(r.width * d);
    canvas.height = Math.round(r.height * d);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  }

  return { line, candles, ring, drawFrame, COLORS };
})();
