# Grok Bot desk — specification of record

This file preserves the 7-part build prompt. Where the local Windows host cannot provide
something (a Vault, an Auto Review approval layer, computer-use routines, X search), the
deviation is listed in `docs/WINDOWS.md` under "Deviations", not silently dropped.

Working directory: `desk/`. One always-on Python 3.12 asyncio process. SQLite (WAL).
Frontend: plain HTML/CSS/JS, no build step, charts by hand on `<canvas>`.

## STEP 1 · FOMO account (blocking)
Ask whether the user has an FOMO account. If not, send `https://fomo.family/r/savipww` and wait.
Either way ask for the FOMO username, save as `settings.fomo_handle`. No code before this.

## STEP 2 · Chrome, login, cursor rules (blocking)
Dedicated Chrome, window maximised, >= 1440px wide, profile `desk/chrome` (persists),
remote debugging bound to `127.0.0.1` only, port 9222. Never expose the port.
FOMO web refuses narrow windows. The owner logs in personally (code typed by the owner).
Logged out later (login screen, or 401 twice): no new buys, push "FOMO logged out. Take control
and log in", resume after one proven API 200.

CURSOR RULES (enforced in browser.py, not only in a prompt)
- Pages: coin pages, the search box, own profile (read only). Nothing else.
- Clickable: search, Paste, a result row, a Trending row, Buy tab, Sell tab, amount field,
  presets $10/$100/$500/$1000 and 10%/25%/50%/100%, Max (Sell only), and "Buy {symbol}" /
  "Sell {symbol}".
- Never: Withdraw, Deposit, Deposit more, Buy with Apple Pay, Orders, Perps, Send, settings,
  any export or key screen, the Swap settings gear, /discover, a Thesis post, any checkbox.
- Before every Buy click: read the amount field back; it must equal Brain's size to the cent and
  the quote line must be loaded. Wrong: clear, retype once. Still wrong: abort "amount mismatch".
- Limits in code: max_ticket_usd, max_trades_night, night_loss_stop_pct.
- Withdraw only on owner command; the owner presses Confirm and does 2FA.

## STEP 3 · Raw samples, FOMO API, layer 8
Unofficial read API, base `https://prod-api.fomo.family`, `Authorization: Bearer <session>`.
Token is read from the desk Chrome's own requests over CDP, lives ~60 min, re-read 5 min before
`exp` and on any 401 once. Never printed, logged, stored in the db/app/push.
- `GET /v2/users/userHandle/{handle}` -> userId + solana address
- `GET /v2/users/{id}/swaps` (25/page) · `GET /v2/users/{id}/balances`
- `GET /v2/leaderboard/{24h|7d|30d}` (150 traders)
- `POST /proxy/filterTokens` (`"<mint>:1399811149"`, max 20)
- `POST /proxy/tokenDetails` · `GET /hodlers/top?tokens=[...]` · `POST /proxy/tokenWarnings`
Max 1 call per 1.2 s overall; 429 doubles the gap to max 20 s; 1 priority queue
(VERIFY/Risk > Executor > Analyst > Scanner); queue > 40 calls: Scanner's holders read skips.
Side of a swap: its side key; else into USDC/USDT/SOL/WETH = sell, out = buy.
Save one raw response per source under `logs/raw/`; show a field->key table. Missing = null.
Layer 8 proof: `getProgramAccounts` on Token and Token-2022 filtered by mint, jsonParsed,
1 graduated mint via `settings.rpc_url`. Fail = stop, ask for a new rpc_url.

## STEP 4 · Stack, files, hosting
Plan A (default on Windows): the process serves `web/` and `/api` over HTTPS/LAN with APP_TOKEN.
Plan B: publish static state files under a secret `/d/{DATA_PATH}/`, poll instead of SSE.
Plan C: a private Page rebuilt by a routine.

## STEP 5 · Data model
coins, scans, audits, scores, orders, positions, activity, prices, balance, settings,
rugs, change_log, heartbeats, push_subs (columns exactly as specified in the prompt).
prices writers: Scanner 60 s (waiting room), Risk 5 s (open positions), api.py 60 s (rest).

## STEP 6 · Bots
5 modules, talk only through bus.py and db. Nothing is bought unless all five say yes, in order.
FOMO is the truth, the db is a copy: on every start and after a crash read `/balances`; adopt
mints held on FOMO but not open (push), close rows gone on FOMO ("not found on FOMO", push).
Before every buy: `/balances` again; mint already held -> no buy.

## STEP 7 · Links (non-negotiable)
```python
CHAIN_ID = {"solana": 1399811149, "robinhood": 4663, "base": 8453, "bnb": 56}
SIGNUP_URL = "https://fomo.family/r/savipww"
def coin_url(address, chain="solana"): ...   # coin?address=..&chainId=..&r=savipww&source=share_link
def profile_url(handle): ...                # profile/{h}?source=share_link&r=savipww
```
Every FOMO URL the desk produces goes through these. Never shortened, wrapped or rebuilt.

## STEP 8 · API
All calls need `APP_TOKEN` (else 401). `GET /api/state`, `/api/chart`, `/api/activity`,
`/api/coin/{mint}`, `/api/audit/{mint}`, `/api/bots/{name}/decisions`, `/api/screen.jpg`
(no-store), `/api/orders`, `/api/account`, `POST /api/settings`, `/api/bots/{name}/pause|resume`,
`/api/mode` (LIVE needs `{"confirm":"LIVE"}`), `/api/sell/{mint}`, `/api/push`, `GET /api/stream`.

## STEP 9 · Browser lane + VERIFY
`fomo_web.md` is the source of every selector; nothing is guessed. Plan A: Playwright
`connect_over_cdp` to STEP 2 Chrome, one tab "desk", one click lane with a lock, Risk sells jump
the queue, click by visible text at the element's centre. One cursor per bot in its colour with
its name, gliding 300 ms, dipping on click, never covering a button. Frames: 1 s JPEG 1280/q60 to
`data/screen.jpg`, keep 300; no frames while a login or withdraw form is open ("Paused · private").
VERIFY after every click: screen end state + `/swaps` page 1 new swap of this mint, right side,
$ within 3% + RPC token balance moved. Wait 30 s. Screen done but api/chain not: "unverified",
screenshot to `logs/fail/`, push, never click that order again. Position follows the API.

## STEP 10 · The app
Black iOS, no neon/glow/gradients on cards, SF Pro, tabular-nums, palette and sizes as specified.
Tabs Home · Bots · Activity · Account, safe areas, 44px targets, DPR-aware canvas, loading/empty/
error states, PAPER badge, odometer, LIVE screen card, bot cards, Audit discs, Coin screen with
sell sheet, Account settings, pushes.

## STEP 11 · Telegram and commands
First `/start` becomes owner_chat_id. Long polling. PAPER pushes prefixed "PAPER · ".
Commands: status, why X, sell X [25|50|100], buy X, pause Scanner, set stop to -20%,
paper|live (live needs typing LIVE), withdraw $N (stops at Review withdraw, owner confirms),
picks, invite, report. Every coin in a reply carries its coin_url.

## STEP 12 · Settings (defaults)
scanner: min_liquidity_usd 20000, max_top10_pct 25, max_h1_change_pct 200, poll_s 60,
min_pool_age_min 10, max_wait_min 60, runner_h24_pct 300, min_holders_growth_pct 0
analyst: max_dev_pct 5, max_top10_pct 25, min_lp_locked_pct 99, max_bundled 5,
max_delegated_accounts 10, retries 3, min_score 70, alive_volume_h1 25000, fast_curve_min 10,
max_fresh_pct 50, organic_unique_h1 80, organic_buys_h1 150, bundled_penalty 0.5,
flush_sell_ratio 1.5, chase_h1_pct 200
social: social_weight 0.5, social_max_per_h 20, social_timeout_s 120, shill_cut 0.5
brain: risk_per_trade_pct 3, full_size_score 80, below_full_pct 50, max_pool_pct 2,
min_ticket_usd 2, max_ticket_usd 50, max_trades_night 30
executor: dip_pct 15, dip_window_min 10, dip_wait_min 30, crash_pct 35, tp_x 2.0, tp_sell_pct 50,
trail_pct 40, recheck_liq_drop_pct 20, recheck_price_up_pct 15, quote_timeout_s 10,
verify_timeout_s 30
risk: poll_s 5, stop_pct 25, timeout_h 3, timeout_min_gain_pct 5, night_loss_stop_pct 30
desk: mode PAPER, paper_start_cash 36, night_start 22:00, lock_time 06:30, report_time 08:00,
notifier telegram, fomo_handle, withdraw_address, rpc_url https://api.mainnet-beta.solana.com,
push_rejects false, fee_pct 0.45
Out of range = refuse and say the range. Every change goes to change_log.

## STEP 13 · PAPER then LIVE
PAPER: lane opens the coin, types the amount, waits for the quote and reads it, never presses the
primary button. Sells: open coin + Sell tab only; fill at the DexScreener price that fired it
minus fees. Every push and screen says PAPER.
fees.py per side: <$5 -> $0.10; $5..$47.50 -> 2%; $47.50..$190 -> $0.95; >$190 -> fee_pct.
LIVE: same pipeline, presses the button; needs a full PAPER night, STEP 15 passed, owner types LIVE.
At lock_time: no new buys, Executor sells everything 100%, push "Night over · $N".

## STEP 14 · Routines
desk-health hourly, night-start daily, night-report daily, copy-picks (later chapter),
weekly-review every 7 nights (proposes at most 3 setting changes; the owner approves in the app).
Report what one PAPER night cost after the first one; warn under 20% weekly usage.

## STEP 15 · Acceptance
1 test_links · 2 test_gate · 3 test_brain · 4 test_risk · 5 test_browser (PAPER, 3 coins, $2,
quote read, withdraw refused in code) · 6 test_verify (fake Bought, no swap -> unverified, no
2nd click) · 7 secrets grep · 8 test_replay (2 h migrations, kill Chrome and the process, recovery,
no double order) · 9 LIVE gate ($2 buy + 100% sell, 3 checks, phone locked) · 10 screenshots at
390px, every empty and error state · 11 test_metrics (one fake coin per rule with its log line).
Done = all 11 pass + app on the iPhone + first PAPER push.

## Bot 1 · Scanner
Owns every coin that graduates off the pumpfun curve onto PumpSwap. One PumpPortal websocket for
the desk (`subscribeMigration` + `subscribeNewToken`). Waiting room with migratedAt, creator +
creator balance now, curve_min. Every 60 s: one batched DexScreener read (price, volume.m5 to
db.prices) and one filterTokens call per 20 mints for holders; holders_growth = now / 10 min
ago - 1. Kill on first hit: liq < 20,000; top10 > 25% (pool/curve excluded); h1 > +200%;
copycat of a today runner (h24 >= 300%); tokenWarnings disableSelling/disableBuying ("we could
never get out"); any warning text; holders_growth < 0% at pass time. Pass at age >= 10 min with
no kill, once per mint; drop after 60 min. log-only: liq_mcap, accel. Never judges quality, never
passes a coin DexScreener doesn't know, never twice a night. Websocket silent 120 s: reconnect
1/2/4..60 s. DexScreener 429: wait 30 s. Stay under 250 req/min.

## Bot 2 · Analyst
8 layers in order, stop at first red, rest grey "not checked", no data is never a pass:
1 mint authority revoked 2 freeze authority revoked 3 dev holds < 5% and never sold, plus
creator's other mints found in db.rugs -> "dev rugged N before" 4 top 10 < 25% 5 LP burned or
locked >= 99% and liquidity not down > 50% since Scanner 6 pool age >= 10 min 7 bundles: biggest
funding group < 5 and insiderNetworks < 15% 8 delegations: no delegate over 10 holder accounts
(getProgramAccounts Token + Token-2022 by mint).
SCORE: alive = clamp(vol.h1/25000), organic = clamp(uniqueBuys1/80) x0.5 if uniqueSells1 >
uniqueBuys1, x0.5 if 3+ bundled, x0.5 if curve_min < 10, x0.5 if fresh_pct >= 50 (share of top 20
holder owners with < 10 signatures); flush 1/0.5/0 (no tokenDetails: txns); chase =
clamp(h1/200); social from social.py or null; core = alive+organic+flush+(1-chase);
score = round(100*(core + w*social)/(4+w)); social_pts = score - round(100*core/4); pass at 70.
Holders saved. Emit each layer live. Never re-asks a rejected mint tonight.

## Social (social.py)
Asks Grok Bot / a webhook routine to search X (u15, u60, big, shill ring, catalyst, coinX) into
`social/{mint}.json`; smart = FOMO holders in the 30d top 150.
v = min(u15/20,1) x0.5 if accel<1; b = min(big/3,1); c = catalyst?1:0; x = 1 / 0.5;
s = min(smart/2,1); social = clamp(0.30v+0.15b+0.15c+0.10x+0.30s - shill, 0, 1).
shill >= 0.5: half size + push. Timeout 120 s: null, the buy does not wait.
Never overrides a layer. Plans A webhook, B X plugin, C off (w = 0, "Social: off").

## Bot 3 · Brain
risk size = cash x 3% / 25% = 12% of cash; score >= 80 full, else 50%; shill ring -> half again;
cap 2% of pool liquidity; cap max_ticket_usd; under $2 skip; round to cents; max_trades_night and
night loss stop also skip. Money in an open position or in an order waiting for its dip is not
free cash. Never resizes after Executor took it.

## Bot 4 · Executor
Re-check before the click: liquidity down > 20% skip; price up > 15% skip; free cash < size skip;
tokenWarnings skip; creator balance lower skip "dev sold while we waited".
Dip entry: wait up to 30 min; high10 = top price of last 10 min; buy at <= high10 x 0.85 with
uniqueSells5m <= 1.5 x uniqueBuys5m; deeper than 35% = "crash" skip; no dip = skip.
Buy: coin_url, contract check, Buy tab, type size, quote, read back, click "Buy {symbol}", VERIFY.
Position from the API. Take profit: 2.0x -> sell 50% once; then trail 40% off peak -> sell 100%.
One order at a time, never a 2nd buy on an open position, never averages down, never re-clicks
unverified, never builds a FOMO URL by hand.

## Bot 5 · Risk
Poll one DexScreener call every 5 s for all open mints (feeds Executor's take profit). Order:
stop at -25% -> sell 100%; time: open >= 3 h and < +5% -> "dead money"; pulled: liquidity -> 0 or
-80% in one poll -> sell now; dev: creator balance -50% -> "dev dumping"; fomo: disableSelling ->
push at once, login warnings -> sell "FOMO warns"; night loss stop -> tell Brain. Sells jump the
lane. Stop only ever tightens. No price for 12 polls -> sell "no price". Sell fails twice: push
"Sell X by hand now", retry every 10 s.
