/**
 * worker.js — Dynamic Worker entry point.
 *
 * This is a *preview shell*: it serves desk/web/ and answers the same /api shapes as the
 * Python desk (desk/api.py) from clearly labelled fixture data. The real desk runs on the
 * owner's Windows machine (desk/Desk.ps1). Nothing here trades, and nothing here is fake-
 * labelled as real: every response carries "fixture": true.
 */

const APP_TOKEN = 'preview';

const COINS = [
  {
    mint: 'MoonMint111111111111111111111111111111111111', name: 'Moon', symbol: 'MOON',
    pool: 'MoonPool', created_at: '2026-11-23T21:51:00.000Z', migrated_at: '2026-11-23T21:58:00.000Z',
    curve_min: 22, holders: 620, liquidity_usd: 42000, market_cap: 210000, price: 0.00052,
    entry: 0.00035, layers: [1,1,1,1,1,1,1,1], score: 92, social: 0.62,
    audit: [
      ['Mint authority', 'Revoked'], ['Freeze authority', 'Revoked'],
      ['Dev wallet', '0.9% · sold 0'], ['Top 10', '8.4%'],
      ['Liquidity', '100% burned'], ['Pool age', '14m'],
      ['Bundles', '1 bundled · insiders 3%'], ['Delegations', 'None'],
    ],
  },
  {
    mint: 'SnipMint1111111111111111111111111111111111111', name: 'Snipe', symbol: 'SNIPE',
    pool: 'SnipPool', created_at: '2026-11-23T22:30:00.000Z', migrated_at: '2026-11-23T22:34:00.000Z',
    curve_min: 4, holders: 310, liquidity_usd: 34000, market_cap: 160000, price: 0.00091,
    entry: null, layers: [1,1,1,1,1,1,1,1], score: 74, social: null,
    audit: [
      ['Mint authority', 'Revoked'], ['Freeze authority', 'Revoked'],
      ['Dev wallet', '3.0% · sold 0'], ['Top 10', '14%'],
      ['Liquidity', '100% burned'], ['Pool age', '11m'],
      ['Bundles', '2 bundled · insiders 6%'], ['Delegations', 'None'],
    ],
  },
  {
    mint: 'BundlMint111111111111111111111111111111111111', name: 'Bundl', symbol: 'BUNDL',
    pool: 'BundlPool', created_at: '2026-11-23T22:00:00.000Z', migrated_at: '2026-11-23T22:02:00.000Z',
    curve_min: 25, holders: 140, liquidity_usd: 48000, market_cap: 180000, price: 0.00031,
    entry: null, layers: [1,1,1,1,1,1,0,-1], score: null, social: null,
    audit: [
      ['Mint authority', 'Revoked'], ['Freeze authority', 'Revoked'],
      ['Dev wallet', '1.2% · sold 0'], ['Top 10', '11%'],
      ['Liquidity', '100% burned'], ['Pool age', '25m'],
      ['Bundles', 'insiders hold 38%'], ['Delegations', null],
    ],
    red: 7,
  },
  {
    mint: 'ThinMint111111111111111111111111111111111111', name: 'Thin', symbol: 'THIN',
    pool: 'ThinPool', created_at: '2026-11-23T22:40:00.000Z', migrated_at: '2026-11-23T22:44:00.000Z',
    curve_min: null, holders: 60, liquidity_usd: 14200, market_cap: 90000, price: 0.00012,
    entry: null, layers: [], score: null, social: null, audit: [], red: 1,
    kill: 'liq $14.2K',
  },
];

const ACTIVITY = [
  { ts: '2026-11-23T23:14:00.000Z', kind: 'bought', mint: COINS[0].mint, bot: 'Executor',
    title: 'Bought MOON', subtitle: 'Executor · 23:14', value: '$4.32' },
  { ts: '2026-11-23T23:09:00.000Z', kind: 'rejected', mint: COINS[3].mint, bot: 'Scanner',
    title: 'Killed THIN', subtitle: 'Scanner · liq $14.2K', value: 'Cut' },
  { ts: '2026-11-23T23:02:00.000Z', kind: 'rejected', mint: COINS[2].mint, bot: 'Analyst',
    title: 'Rejected BUNDL', subtitle: 'Analyst · layer 7: insiders hold 38%', value: 'Skipped' },
  { ts: '2026-11-23T22:55:00.000Z', kind: 'stopped', mint: COINS[1].mint, bot: 'Risk',
    title: 'Stopped DUMP', subtitle: 'Risk · -25% stop', value: '-1.08' },
  { ts: '2026-11-23T22:41:00.000Z', kind: 'sold', mint: COINS[0].mint, bot: 'Executor',
    title: 'Sold MOON', subtitle: 'Executor · take profit 50%', value: '+2.61' },
];

const BALANCE = [
  { ts: '2026-11-23T22:00:00.000Z', value: 36.0 },
  { ts: '2026-11-23T22:20:00.000Z', value: 36.0 },
  { ts: '2026-11-23T22:41:00.000Z', value: 38.61 },
  { ts: '2026-11-23T22:55:00.000Z', value: 37.53 },
  { ts: '2026-11-23T23:14:00.000Z', value: 37.53 },
];

const DECISIONS = {
  scanner: [
    ['THIN', 'kill · liq $14.2K'], ['MOON2', 'kill · copycat of MOON'],
    ['FADE', 'kill · holders leaving -4% in 10m'], ['TRAP', 'kill · FOMO: selling off'],
    ['MOON', 'pass · in the room'],
  ],
  analyst: [
    ['BUNDL', 'layer 7: insiders hold 38%'], ['RUGX', 'layer 3: dev rugged 2 before'],
    ['MOON', '92 · pass'], ['SNIPE', '74 · pass'],
  ],
  brain: [['MOON', '$4.32 · none'], ['SNIPE', '$2.09 · none']],
  executor: [['MOON', 'bought · verified'], ['MOON', 'sold · take profit 50%']],
  risk: [['DUMP', 'stop 100%'], ['MOON', 'holding']],
};

// fixture histories are longer than 20 on purpose: the UI must show only the latest 20
const HISTORY = 26;

function decideRows(key, now) {
  const base = DECISIONS[key] || [];
  const out = [];
  for (let i = 0; i < HISTORY; i += 1) {
    const [head, text] = base[i % base.length];
    out.push({
      ts: new Date(now - (i + 1) * 4 * 60 * 1000).toISOString(),
      head: i < base.length ? head : `${head}${Math.floor(i / base.length) + 1}`,
      text, mint: COINS[i % COINS.length].mint,
    });
  }
  return out;
}

function bots(now) {
  const beat = new Date(now - 3000).toISOString();
  const mk = (name, color, extra = {}) => ({ name, color, paused: PAUSED.has(name), beat: 3, down: false, ...extra });
  return [
    mk('Scanner', '#64d2ff', { count: 5, unit: 'pools', countLabel: '4 killed',
      line: 'liq $14.2K', foot: 'min age 10m', killed: true, reason: 'liq $14.2K' }),
    mk('Analyst', '#ffd60a', { count: 2, unit: 'taken apart', countLabel: '8 layers',
      layers: [1, 1, 1, 1, 1, 1, 0, -1], score: 92, line: '8/8', foot: 'Social +4' }),
    mk('Brain', '#bf5af2', { count: 2, unit: 'sizing', countLabel: '',
      line: '$4.32', foot: '80+ = full size', bar: 30 }),
    mk('Executor', '#00d35a', { count: 2, unit: 'trades', countLabel: '1 open',
      line: 'MOON · holding', foot: 'max 50$ · 30 a night', bar: 6 }),
    mk('Risk', '#ff6b9a', { count: 1, unit: 'guarding', countLabel: 'guarding',
      line: 'Guarding', stop: 25, trail: 40, locked: true, foot: '-1.08' }),
  ];
}

// preview-only pause state, so the switches behave like the real desk for the length of a
// browser session. The Python desk keeps its authoritative in-memory set in desk/main.py.
const PAUSED = new Set();

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'authorization,content-type',
  'access-control-allow-methods': 'GET,POST,OPTIONS',
  'cache-control': 'no-store',
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status, headers: { 'content-type': 'application/json; charset=utf-8', ...CORS },
  });
}

function authed(req) {
  const h = req.headers.get('authorization') || '';
  return h === `Bearer ${APP_TOKEN}`;
}

function state(now) {
  return {
    ts: new Date(now).toISOString(),
    fixture: true,
    balance: 37.53,
    night_start_cash: 36.0,
    mode: 'PAPER',
    positions: [{
      mint: COINS[0].mint, opened_at: '2026-11-23T23:14:00.000Z', entry_price: 0.00035,
      size_usd: 4.32, tokens: 12343, peak_price: 0.00086, stop_price: 0.0002625,
      tp_done: 0, trail_active: 0,
    }],
    bots: bots(now),
    lane: 'Executor · buying',
    lane_color: '#00d35a',
    screen_mint: COINS[0].mint,
    signup_url: 'https://fomo.family/r/savipww',
    profile_url: 'https://fomo.family/profile/mr_tycoon?source=share_link&r=savipww',
    coin_links: { [COINS[0].mint]: 'https://fomo.family/coin?address=' + COINS[0].mint + '&chainId=1399811149&r=savipww&source=share_link' },
    last_order: {
      side: 'buy', usd: 4.32, status: 'verified', symbol: 'MOON',
      checks: { screen: true, api: true, chain: true }, ts: '2026-11-23T23:14:00.000Z',
    },
    activity: ACTIVITY.slice(0, 5),
  };
}

function chart(range) {
  const marks = [
    { index: 2, text: 'Bought $4.32', color: '#0a84ff' },
    { index: 3, text: '+$2.61', color: '#00d35a' },
    { index: 4, text: '-25% · -$1.08', color: '#ff453a' },
  ];
  return { range, points: BALANCE, start: 36.0, marks };
}

function coinPayload(mint) {
  const c = COINS.find(x => x.mint === mint);
  if (!c) return null;
  const candles = [];
  for (let i = 0; i < 60; i++) {
    const base = c.price * (0.72 + i / 90);
    const wobble = Math.sin(i / 3) * c.price * 0.05;
    candles.push({ ts: `2026-11-23T22:${String(i).padStart(2, '0')}`, open: base, price: base + wobble,
      high: base + Math.abs(wobble) + c.price * 0.02, low: base - Math.abs(wobble) - c.price * 0.02 });
  }
  const isHeld = c.entry != null;
  return {
    fixture: true,
    coin: { ...c, age_text: '1h 16m old', layers_passed: c.audit.length },
    price: c.price,
    link: 'https://fomo.family/coin?address=' + c.mint + '&chainId=1399811149&r=savipww&source=share_link',
    candles,
    position: isHeld ? {
      mint: c.mint, entry_price: c.entry, size_usd: 4.32, peak_price: 0.00086,
      stop_price: c.entry * 0.75, owner: 'Executor',
      pnl_pct: (c.price / c.entry - 1) * 100,
    } : null,
    score: c.score,
  };
}

function auditPayload(mint) {
  const c = COINS.find(x => x.mint === mint);
  if (!c) return null;
  if (!c.audit.length) {
    return { fixture: true, mint, symbol: c.symbol, layers: [], score: null,
      social_text: 'Social: off', kill: c.kill };
  }
  const layers = c.audit.map(([name, value], i) => {
    const n = i + 1;
    const passed = c.red ? n < c.red : (value != null && value !== undefined);
    const notChecked = c.red ? n > c.red : false;
    return { n, name, pass: notChecked ? null : passed, value: notChecked ? 'not checked' : (value || 'no data'),
      not_checked: notChecked };
  });
  return {
    fixture: true, mint, symbol: c.symbol, layers, score: c.score,
    social_text: c.social == null ? 'Social: off'
      : `Social +${Math.round(c.score - 88)} · weight 0.5`,
  };
}

function account() {
  const specs = [
    { key: 'min_liquidity_usd', group: 'scanner', label: 'Minimum liquidity', kind: 'num', default: 20000, min: 1000, max: 5000000, unit: '$', choices: [] },
    { key: 'max_top10_pct', group: 'scanner', label: 'Max top 10', kind: 'num', default: 25, min: 1, max: 100, unit: '%', choices: [] },
    { key: 'poll_s', group: 'scanner', label: 'Poll every', kind: 'int', default: 60, min: 10, max: 600, unit: 's', choices: [] },
    { key: 'min_pool_age_min', group: 'scanner', label: 'Min pool age', kind: 'num', default: 10, min: 1, max: 240, unit: 'min', choices: [] },
    { key: 'min_score', group: 'analyst', label: 'Min score', kind: 'num', default: 70, min: 0, max: 100, unit: '', choices: [] },
    { key: 'max_bundled', group: 'analyst', label: 'Max bundled wallets', kind: 'num', default: 5, min: 0, max: 100, unit: '', choices: [] },
    { key: 'social_weight', group: 'social', label: 'Social weight', kind: 'num', default: 0.5, min: 0, max: 3, unit: '', choices: [] },
    { key: 'risk_per_trade_pct', group: 'brain', label: 'Risk per trade', kind: 'num', default: 3, min: 0.1, max: 20, unit: '%', choices: [] },
    { key: 'max_ticket_usd', group: 'brain', label: 'Max ticket', kind: 'num', default: 50, min: 2, max: 100000, unit: '$', choices: [] },
    { key: 'max_trades_night', group: 'brain', label: 'Max trades a night', kind: 'int', default: 30, min: 1, max: 500, unit: '', choices: [] },
    { key: 'dip_pct', group: 'executor', label: 'Dip entry', kind: 'num', default: 15, min: 1, max: 90, unit: '%', choices: [] },
    { key: 'tp_x', group: 'executor', label: 'Take profit at', kind: 'num', default: 2.0, min: 1.1, max: 20, unit: '×', choices: [] },
    { key: 'trail_pct', group: 'executor', label: 'Trail from peak', kind: 'num', default: 40, min: 5, max: 90, unit: '%', choices: [] },
    { key: 'stop_pct', group: 'risk', label: 'Stop', kind: 'num', default: 25, min: 1, max: 95, unit: '%', choices: [] },
    { key: 'night_loss_stop_pct', group: 'risk', label: 'Night loss stop', kind: 'num', default: 30, min: 1, max: 100, unit: '%', choices: [] },
    { key: 'mode', group: 'desk', label: 'Mode', kind: 'enum', default: 'PAPER', min: null, max: null, unit: '', choices: ['PAPER', 'LIVE'] },
    { key: 'fomo_handle', group: 'desk', label: 'FOMO username', kind: 'str', default: 'mr_tycoon', min: null, max: null, unit: '', choices: [] },
    { key: 'push_rejects', group: 'desk', label: 'Push rejects', kind: 'bool', default: false, min: null, max: null, unit: '', choices: [] },
  ];
  const settings = {};
  for (const s of specs) settings[s.key] = s.default;
  return {
    fixture: true, cash: 37.53, mode: 'PAPER', settings, specs,
    profile_url: 'https://fomo.family/profile/mr_tycoon?source=share_link&r=savipww',
    signup_url: 'https://fomo.family/r/savipww',
  };
}

// A tiny 320x180 "screen" so the Live card has something honest to show in the preview.
function screenSvg(now) {
  const t = new Date(now).toISOString().slice(11, 19);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720" viewBox="0 0 1280 720">
  <rect width="1280" height="720" fill="#0b0b0c"/>
  <rect y="0" width="1280" height="64" fill="#131315"/>
  <circle cx="46" cy="32" r="16" fill="#2c2c2e"/>
  <text x="80" y="39" font-family="-apple-system,system-ui" font-size="20" fill="#ebebf5">MOON · Buy</text>
  <rect x="40" y="110" width="1200" height="300" rx="18" fill="#1c1c1e"/>
  <text x="80" y="180" font-family="-apple-system,system-ui" font-size="34" fill="#fff">$4.32</text>
  <text x="80" y="222" font-family="-apple-system,system-ui" font-size="18" fill="#8e8e93">You get ~12,343 MOON</text>
  <text x="80" y="262" font-family="-apple-system,system-ui" font-size="16" fill="#64d2ff">Quote loaded</text>
  <rect x="40" y="450" width="580" height="86" rx="18" fill="#2c2c2e"/>
  <text x="300" y="502" font-family="-apple-system,system-ui" font-size="24" fill="#fff" text-anchor="middle">Buy MOON</text>
  <rect x="660" y="450" width="580" height="86" rx="18" fill="#2c2c2e"/>
  <text x="950" y="502" font-family="-apple-system,system-ui" font-size="24" fill="#fff" text-anchor="middle">Sell MOON</text>
  <text x="40" y="600" font-family="ui-monospace,monospace" font-size="15" fill="#8e8e93">PREVIEW FRAME · ${t} · not a real FOMO page</text>
  <circle cx="1230" cy="600" r="6" fill="#ff453a"/>
</svg>`;
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

    if (path.startsWith('/api/')) {
      if (!authed(request)) return json({ detail: 'unauthorized' }, 401);
      const now = Date.now();
      switch (true) {
        case path === '/api/state': return json(state(now));
        case path === '/api/chart': return json(chart(url.searchParams.get('range') || 'LIVE'));
        case path === '/api/activity': return json({ rows: ACTIVITY });
        case path === '/api/orders':
          return json({ rows: [{ id: 2, ts: '2026-11-23T23:14:00.000Z', mint: COINS[0].mint,
            side: 'buy', usd: 4.32, status: 'verified',
            checks: { screen: true, api: true, chain: true } }] });
        case path.startsWith('/api/coin/'): {
          const p = coinPayload(path.split('/')[3]);
          return p ? json(p) : json({ detail: 'no such coin tonight' }, 404);
        }
        case path.startsWith('/api/audit/'): {
          const p = auditPayload(path.split('/')[3]);
          return p ? json(p) : json({ detail: 'no audit' }, 404);
        }
        case path.startsWith('/api/bots/') && path.endsWith('/decisions'): {
          const name = path.split('/')[3];
          return json({ rows: decideRows(name, now).slice(0, 20) });
        }
        case path.startsWith('/api/bots/') && (path.endsWith('/pause') || path.endsWith('/resume')): {
          const raw = path.split('/')[3];
          const name = raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
          const known = ['Scanner', 'Analyst', 'Brain', 'Executor', 'Risk'];
          if (!known.includes(name)) return json({ detail: 'unknown bot' }, 404);
          const wantPaused = path.endsWith('/pause');
          // same rule as desk/main.py: Risk may not be paused while a position is open
          const held = (state(now).positions || []).length > 0;
          if (name === 'Risk' && wantPaused && held) {
            return json({ detail: 'Risk cannot be paused while a position is open' }, 409);
          }
          if (wantPaused) PAUSED.add(name); else PAUSED.delete(name);
          return json({ bot: name, paused: PAUSED.has(name), fixture: true });
        }
        case path === '/api/account': return json(account());
        case path === '/api/search': {
          const q = (url.searchParams.get('q') || '').toLowerCase();
          const rows = COINS.filter(c => (c.name + c.symbol + c.mint).toLowerCase().includes(q))
            .map(c => ({ mint: c.mint, name: c.name, symbol: c.symbol }));
          return json({ rows });
        }
        case path === '/api/screen.jpg':
          return new Response(screenSvg(now), {
            headers: { 'content-type': 'image/svg+xml; charset=utf-8', ...CORS },
          });
        case path === '/api/health':
          return json({ ok: true, mode: 'PAPER', fixture: true, ts: new Date(now).toISOString(),
            beats: { scanner: 3, analyst: 2, brain: 2, executor: 1, risk: 1 } });
        case path === '/api/push': return json({ sent: false, reason: 'preview' });
        case path === '/api/settings': {
          const body = await request.json().catch(() => ({}));
          return json({ key: body.key, old: body.value, new: body.value, label: 'preview' });
        }
        case path === '/api/mode':
          return json({ detail: 'LIVE is disabled in the preview' }, 409);
        case path === '/api/stream':
          return new Response('event: ping\ndata: {"kind":"ping"}\n\n', {
            headers: { 'content-type': 'text/event-stream', ...CORS },
          });
        default: return json({ detail: 'not found' }, 404);
      }
    }

    // static: desk/web is served by the assets binding
    const file = path === '/' ? '/index.html' : path;
    return env.ASSETS.fetch(new Request(new URL(file, url), request));
  },
};
